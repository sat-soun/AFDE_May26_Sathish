"""
Central configuration using Pydantic BaseSettings.
All env vars are loaded from .env; override via environment at runtime.
"""

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


ROOT_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ROOT_DIR / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── OpenAI ──────────────────────────────────────────────────────────────
    openai_api_key: str

    # ── Models ──────────────────────────────────────────────────────────────
    llm_model: str = "gpt-4o-mini"
    embedding_model: str = "text-embedding-3-small"
    llm_temperature: float = 0.0
    llm_max_tokens: int = 2048

    # ── Vector store ────────────────────────────────────────────────────────
    vectorstore_provider: str = "chroma"          # chroma | faiss
    vectorstore_path: Path = ROOT_DIR / "data" / "vectorstore"
    vectorstore_collection: str = "insurance_claims"

    # ── Ingestion ────────────────────────────────────────────────────────────
    raw_data_dir: Path = ROOT_DIR / "data" / "raw"
    processed_data_dir: Path = ROOT_DIR / "data" / "processed"

    # Retrieval top-k
    retrieval_top_k: int = 5

    # ── Agent behaviour ──────────────────────────────────────────────────────
    # Maximum LangGraph recursion depth (supervisor re-routing limit)
    graph_recursion_limit: int = 25

    # Fraud score threshold above which a claim is flagged HIGH risk
    fraud_high_risk_threshold: float = 0.7
    fraud_medium_risk_threshold: float = 0.4


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()
