"""
Central configuration using Pydantic BaseSettings.
All env vars are loaded from .env; override via environment at runtime.

LLM / Embedding authentication
───────────────────────────────
Set LLM_API_KEY and LLM_BASE_URL to point at any OpenAI-compatible endpoint:

  Provider              LLM_BASE_URL
  ─────────────────     ──────────────────────────────────────────────────
  OpenAI (default)      https://api.openai.com/v1
  Azure OpenAI          https://<resource>.openai.azure.com/
  Ollama (local)        http://localhost:11434/v1
  LM Studio             http://localhost:1234/v1
  vLLM                  http://localhost:8080/v1
  AWS Bedrock gateway   https://<bedrock-gateway-url>/v1
  Anthropic proxy       https://api.anthropic.com/v1  (needs compat layer)

The same base-URL convention applies to EMBEDDING_BASE_URL for embedding
models served at a different endpoint.
"""

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


ROOT_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ROOT_DIR / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── LLM authentication ────────────────────────────────────────────────────
    llm_api_key: str                                # LLM_API_KEY
    llm_base_url: str = "https://api.openai.com/v1" # LLM_BASE_URL

    # ── Embedding authentication ──────────────────────────────────────────────
    # Defaults to the same key/URL as the LLM; override if your embedding
    # endpoint differs (e.g. Azure uses a separate deployment URL).
    embedding_api_key: Optional[str] = None         # EMBEDDING_API_KEY
    embedding_base_url: Optional[str] = None        # EMBEDDING_BASE_URL

    # ── Models ────────────────────────────────────────────────────────────────
    llm_model: str = "gpt-4o-mini"
    embedding_model: str = "text-embedding-3-small"
    llm_temperature: float = 0.0
    llm_max_tokens: int = 2048

    # ── Vector store ──────────────────────────────────────────────────────────
    vectorstore_provider: str = "chroma"            # chroma | faiss
    vectorstore_path: Path = ROOT_DIR / "data" / "vectorstore"
    vectorstore_collection: str = "insurance_claims"

    # ── Ingestion ─────────────────────────────────────────────────────────────
    raw_data_dir: Path = ROOT_DIR / "data" / "raw"
    processed_data_dir: Path = ROOT_DIR / "data" / "processed"
    retrieval_top_k: int = 5

    # ── Agent behaviour ───────────────────────────────────────────────────────
    graph_recursion_limit: int = 25
    fraud_high_risk_threshold: float = 0.7
    fraud_medium_risk_threshold: float = 0.4

    # ── Derived helpers (read-only properties) ────────────────────────────────

    @property
    def effective_embedding_api_key(self) -> str:
        """Embedding key falls back to the LLM key if not explicitly set."""
        return self.embedding_api_key or self.llm_api_key

    @property
    def effective_embedding_base_url(self) -> str:
        """Embedding base URL falls back to the LLM base URL if not set."""
        return self.embedding_base_url or self.llm_base_url

    @field_validator("llm_base_url", "embedding_base_url", mode="before")
    @classmethod
    def _strip_trailing_slash(cls, v: Optional[str]) -> Optional[str]:
        """Normalise URLs — LangChain appends paths so trailing slashes cause double slashes."""
        return v.rstrip("/") if v else v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()
