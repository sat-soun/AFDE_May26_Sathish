import { useState, useRef, useCallback } from 'react'
import { chatStream } from '../api/client.js'

/**
 * Agent names in pipeline order (excluding supervisor/finalize).
 */
export const PIPELINE_AGENTS = [
  'claims_retrieval',
  'fraud_analysis',
  'policy_validation',
  'risk_scoring',
]

const AGENT_LABELS = {
  supervisor:        'Supervisor',
  claims_retrieval:  'Claims Retrieval',
  fraud_analysis:    'Fraud Analysis',
  policy_validation: 'Policy Validation',
  risk_scoring:      'Risk Scoring',
  finalize:          'Finalising',
}

/** Return a fresh per-message state object */
function newMessageState(id, query) {
  return {
    id,
    role: 'assistant',
    query,
    status: 'streaming',          // streaming | done | error | blocked
    agentStatuses: Object.fromEntries(
      PIPELINE_AGENTS.map(a => [a, 'pending'])
    ),                            // pending | active | done
    activeAgent: null,
    nextAgent: null,
    agentData: {},                // node → raw data payload
    finalAnswer: '',
    retrievedCount: 0,
    fraudResult: null,
    policyResult: null,
    riskScore: null,
    // Guardrail state
    inputGuardrail: null,         // { passed, blocked, violations }
    outputGuardrail: null,
    answerRedacted: false,
    error: null,
  }
}

export function useChat() {
  const [messages, setMessages] = useState([])
  const [isStreaming, setIsStreaming] = useState(false)
  const abortRef = useRef(null)

  /** Patch a message by id */
  const patchMessage = useCallback((id, updater) => {
    setMessages(prev =>
      prev.map(m => (m.id === id ? { ...m, ...updater(m) } : m))
    )
  }, [])

  const sendQuery = useCallback(async (query) => {
    if (isStreaming) return

    const userMsg = { id: Date.now(), role: 'user', content: query }
    const asstId  = Date.now() + 1
    const asstMsg = newMessageState(asstId, query)

    setMessages(prev => [...prev, userMsg, asstMsg])
    setIsStreaming(true)

    const controller = new AbortController()
    abortRef.current = controller

    try {
      await chatStream(
        query,
        (event) => {
          switch (event.type) {

            case 'guardrail': {
              const key = event.stage === 'input' ? 'inputGuardrail' : 'outputGuardrail'
              patchMessage(asstId, () => ({
                [key]: {
                  passed:     event.passed,
                  blocked:    event.blocked,
                  violations: event.violations ?? [],
                },
                // If input is blocked, mark the message status
                ...(event.stage === 'input' && event.blocked
                  ? { status: 'blocked', error: event.violations?.[0]?.message }
                  : {}),
              }))
              break
            }

            case 'routing': {
              const next = event.next_agent
              patchMessage(asstId, m => ({
                nextAgent:   next,
                activeAgent: next === 'FINISH' ? null : next,
                agentStatuses: next && next !== 'FINISH'
                  ? { ...m.agentStatuses, [next]: 'active' }
                  : m.agentStatuses,
              }))
              break
            }

            case 'agent_update': {
              const node = event.node
              const data = event.data ?? {}
              patchMessage(asstId, m => ({
                agentStatuses: { ...m.agentStatuses, [node]: 'done' },
                agentData:     { ...m.agentData, [node]: data },
                retrievedCount: data.retrieved_claims_count ?? m.retrievedCount,
                fraudResult:   data.fraud_result  ?? m.fraudResult,
                policyResult:  data.policy_result ?? m.policyResult,
                riskScore:     data.risk_score    ?? m.riskScore,
              }))
              break
            }

            case 'final_answer':
              patchMessage(asstId, () => ({
                finalAnswer:    event.answer ?? '',
                answerRedacted: event.redacted ?? false,
              }))
              break

            case 'done':
              patchMessage(asstId, m => ({
                status:      'done',
                activeAgent: null,
                agentStatuses: Object.fromEntries(
                  PIPELINE_AGENTS.map(a => [
                    a,
                    m.agentStatuses[a] === 'pending' ? 'pending' : 'done',
                  ])
                ),
              }))
              break

            case 'error':
              patchMessage(asstId, () => ({
                status:      'error',
                error:       event.message ?? 'Unknown error',
                activeAgent: null,
              }))
              break
          }
        },
        controller.signal,
      )
    } catch (err) {
      if (err.name !== 'AbortError') {
        patchMessage(asstId, () => ({
          status:      'error',
          error:       err.message ?? 'Request failed',
          activeAgent: null,
        }))
      }
    } finally {
      setIsStreaming(false)
      abortRef.current = null
    }
  }, [isStreaming, patchMessage])

  const stopStreaming = useCallback(() => {
    abortRef.current?.abort()
  }, [])

  const clearChat = useCallback(() => {
    if (isStreaming) abortRef.current?.abort()
    setMessages([])
  }, [isStreaming])

  return {
    messages,
    isStreaming,
    sendQuery,
    stopStreaming,
    clearChat,
    AGENT_LABELS,
  }
}
