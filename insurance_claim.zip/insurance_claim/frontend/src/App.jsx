/**
 * App — root layout: Sidebar + Chat area.
 */
import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import Sidebar from './components/Sidebar.jsx'
import ChatWindow from './components/ChatWindow.jsx'
import InputBar from './components/InputBar.jsx'
import { useChat } from './hooks/useChat.js'

export default function App() {
  const { messages, isStreaming, sendQuery, stopStreaming, clearChat } = useChat()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  return (
    <div className="flex h-screen bg-canvas overflow-hidden">
      {/* Sidebar */}
      {sidebarOpen && (
        <Sidebar onClear={clearChat} isStreaming={isStreaming} />
      )}

      {/* Main area */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Top bar */}
        <header className="flex items-center gap-3 px-4 py-3 border-b border-border bg-surface flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(o => !o)}
            className="w-8 h-8 rounded-md flex items-center justify-center text-muted
                       hover:text-primary hover:bg-overlay transition-colors"
            title={sidebarOpen ? 'Hide sidebar' : 'Show sidebar'}
          >
            {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </button>

          <div className="flex-1 min-w-0">
            <h1 className="text-primary text-sm font-semibold">Insurance Claims Intelligence</h1>
            <p className="text-muted text-xs">Multi-agent fraud detection & risk analysis</p>
          </div>

          {isStreaming && (
            <div className="flex items-center gap-2 text-accent text-xs">
              <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              Agents running…
            </div>
          )}
        </header>

        {/* Messages */}
        <ChatWindow messages={messages} />

        {/* Input */}
        <InputBar
          onSend={sendQuery}
          onStop={stopStreaming}
          isStreaming={isStreaming}
        />
      </div>
    </div>
  )
}
