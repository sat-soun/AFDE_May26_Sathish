/**
 * InputBar — query input with send / stop controls.
 */
import { useState, useEffect, useRef } from 'react'
import { Send, Square } from 'lucide-react'

export default function InputBar({ onSend, onStop, isStreaming }) {
  const [value, setValue] = useState('')
  const textareaRef = useRef(null)

  // Listen for suggestion clicks from ChatWindow's EmptyState
  useEffect(() => {
    function handleSuggestion(e) {
      setValue(e.detail)
      textareaRef.current?.focus()
    }
    window.addEventListener('suggestion', handleSuggestion)
    return () => window.removeEventListener('suggestion', handleSuggestion)
  }, [])

  // Auto-resize textarea
  useEffect(() => {
    const ta = textareaRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'
  }, [value])

  function handleSubmit() {
    const q = value.trim()
    if (!q || isStreaming) return
    onSend(q)
    setValue('')
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div className="border-t border-border bg-canvas px-4 py-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-end gap-3 bg-surface border border-border rounded-xl px-4 py-3
                        focus-within:border-accent/50 transition-colors">
          <textarea
            ref={textareaRef}
            rows={1}
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about insurance claims, fraud patterns, risk scores…"
            disabled={isStreaming && !value}
            className="flex-1 bg-transparent text-primary text-sm placeholder-muted resize-none
                       outline-none leading-relaxed min-h-[24px] max-h-[160px]
                       disabled:opacity-50"
          />

          {isStreaming ? (
            <button
              onClick={onStop}
              className="flex-shrink-0 w-9 h-9 rounded-lg bg-red/10 border border-red/30
                         flex items-center justify-center text-red
                         hover:bg-red/20 transition-all"
              title="Stop generation"
            >
              <Square size={14} fill="currentColor" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!value.trim()}
              className="flex-shrink-0 w-9 h-9 rounded-lg bg-accent/10 border border-accent/30
                         flex items-center justify-center text-accent
                         hover:bg-accent/20 transition-all
                         disabled:opacity-30 disabled:cursor-not-allowed"
              title="Send (Enter)"
            >
              <Send size={14} />
            </button>
          )}
        </div>
        <p className="text-muted text-xs mt-2 text-center">
          Press <kbd className="px-1 py-0.5 bg-overlay border border-border rounded text-xs font-mono">Enter</kbd> to send ·
          <kbd className="px-1 py-0.5 bg-overlay border border-border rounded text-xs font-mono ml-1">Shift+Enter</kbd> for new line
        </p>
      </div>
    </div>
  )
}
