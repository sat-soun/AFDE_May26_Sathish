/**
 * Sidebar — agent pipeline legend, ingest controls, and chat actions.
 */
import { useState } from 'react'
import {
  Shield, Search, ShieldAlert, FileCheck, BarChart3,
  Trash2, Upload, RefreshCw, CheckCircle2, AlertCircle, ChevronRight,
} from 'lucide-react'
import { ingestDefault, ingestFile, healthCheck } from '../api/client.js'

const AGENTS = [
  { key: 'supervisor',        label: 'Supervisor',        icon: Shield,      color: 'text-accent',  desc: 'Orchestrates the pipeline' },
  { key: 'claims_retrieval',  label: 'Claims Retrieval',  icon: Search,      color: 'text-accent',  desc: 'Semantic vector search' },
  { key: 'fraud_analysis',    label: 'Fraud Analysis',    icon: ShieldAlert,  color: 'text-red',     desc: 'Detects fraud signals' },
  { key: 'policy_validation', label: 'Policy Validation', icon: FileCheck,    color: 'text-yellow',  desc: 'Validates coverage & terms' },
  { key: 'risk_scoring',      label: 'Risk Scoring',       icon: BarChart3,    color: 'text-purple',  desc: 'Synthesises final risk score' },
]

function Section({ title, children }) {
  return (
    <div className="mb-6">
      <p className="text-xs text-muted uppercase tracking-wider font-semibold mb-2 px-2">{title}</p>
      {children}
    </div>
  )
}

function StatusPill({ status }) {
  if (!status) return null
  const styles = {
    success: 'bg-green/10 text-green border-green/30',
    error:   'bg-red/10 text-red border-red/30',
    loading: 'bg-accent/10 text-accent border-accent/30',
  }
  const labels = { success: 'Done', error: 'Failed', loading: '…' }
  return (
    <span className={`text-xs border rounded-full px-2 py-0.5 ${styles[status]}`}>
      {labels[status]}
    </span>
  )
}

export default function Sidebar({ onClear, isStreaming }) {
  const [ingestStatus, setIngestStatus] = useState(null)   // null | loading | success | error
  const [ingestMsg, setIngestMsg]       = useState('')
  const [apiStatus, setApiStatus]       = useState(null)

  async function handleIngestDefault() {
    setIngestStatus('loading')
    setIngestMsg('')
    try {
      const res = await ingestDefault()
      setIngestStatus('success')
      setIngestMsg(res.message)
    } catch (e) {
      setIngestStatus('error')
      setIngestMsg(e.message)
    }
  }

  async function handleFileUpload(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setIngestStatus('loading')
    setIngestMsg('')
    try {
      const res = await ingestFile(file)
      setIngestStatus('success')
      setIngestMsg(res.message)
    } catch (err) {
      setIngestStatus('error')
      setIngestMsg(err.message)
    }
    e.target.value = ''
  }

  async function handleHealthCheck() {
    setApiStatus('loading')
    try {
      await healthCheck()
      setApiStatus('success')
    } catch {
      setApiStatus('error')
    }
    setTimeout(() => setApiStatus(null), 3000)
  }

  return (
    <aside className="w-64 flex-shrink-0 bg-surface border-r border-border flex flex-col overflow-y-auto">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-accent/10 border border-accent/20 flex items-center justify-center">
          <Shield size={16} className="text-accent" />
        </div>
        <div>
          <p className="text-primary text-sm font-semibold leading-tight">Claims Intel</p>
          <p className="text-muted text-xs">Multi-Agent AI</p>
        </div>
      </div>

      <div className="flex-1 px-3 py-4 overflow-y-auto">

        {/* Agent pipeline */}
        <Section title="Agent Pipeline">
          <div className="space-y-0.5">
            {AGENTS.map((agent) => {
              const Icon = agent.icon
              return (
                <div
                  key={agent.key}
                  className="flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-overlay transition-colors group"
                >
                  <Icon size={14} className={agent.color} />
                  <div className="flex-1 min-w-0">
                    <p className="text-primary text-xs font-medium truncate">{agent.label}</p>
                    <p className="text-muted text-xs truncate">{agent.desc}</p>
                  </div>
                  <ChevronRight size={12} className="text-border opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              )
            })}
          </div>
        </Section>

        {/* Data Ingestion */}
        <Section title="Data Ingestion">
          <div className="space-y-2">
            <button
              onClick={handleIngestDefault}
              disabled={ingestStatus === 'loading'}
              className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-md
                         bg-overlay border border-border text-xs text-primary
                         hover:border-accent/40 hover:bg-overlay/80 transition-all
                         disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="flex items-center gap-2">
                <RefreshCw size={13} className={ingestStatus === 'loading' ? 'animate-spin text-accent' : 'text-muted'} />
                <span>Ingest data/raw/</span>
              </div>
              <StatusPill status={ingestStatus} />
            </button>

            <label className="w-full flex items-center gap-2 px-3 py-2 rounded-md
                              bg-overlay border border-border text-xs text-primary
                              hover:border-accent/40 hover:bg-overlay/80 transition-all cursor-pointer">
              <Upload size={13} className="text-muted" />
              <span>Upload CSV</span>
              <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
            </label>

            {ingestMsg && (
              <p className={`text-xs px-1 ${ingestStatus === 'error' ? 'text-red' : 'text-green'}`}>
                {ingestMsg}
              </p>
            )}
          </div>
        </Section>

        {/* Actions */}
        <Section title="Actions">
          <div className="space-y-1">
            <button
              onClick={handleHealthCheck}
              className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-md
                         bg-overlay border border-border text-xs text-primary
                         hover:border-accent/40 transition-all"
            >
              <div className="flex items-center gap-2">
                {apiStatus === 'success'
                  ? <CheckCircle2 size={13} className="text-green" />
                  : apiStatus === 'error'
                  ? <AlertCircle size={13} className="text-red" />
                  : <div className={`w-2 h-2 rounded-full ${apiStatus === 'loading' ? 'bg-accent animate-pulse' : 'bg-muted'}`} />
                }
                <span>Check API health</span>
              </div>
            </button>

            <button
              onClick={onClear}
              disabled={isStreaming}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md
                         bg-overlay border border-border text-xs text-muted
                         hover:text-red hover:border-red/30 transition-all
                         disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Trash2 size={13} />
              <span>Clear conversation</span>
            </button>
          </div>
        </Section>
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-border">
        <p className="text-muted text-xs">Powered by LangGraph + GPT-4o</p>
      </div>
    </aside>
  )
}
