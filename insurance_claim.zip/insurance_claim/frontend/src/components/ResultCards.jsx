/**
 * ResultCards — structured display panels for fraud / policy / risk results.
 */
import { ShieldAlert, FileCheck, BarChart3, AlertTriangle, CheckCircle2, XCircle, Info } from 'lucide-react'

// ── Shared primitives ─────────────────────────────────────────────────────────

function Card({ icon: Icon, title, color, children }) {
  return (
    <div className={`rounded-lg border ${color.border} bg-surface p-4 text-sm animate-fade-in`}>
      <div className="flex items-center gap-2 mb-3">
        <Icon size={15} className={color.icon} />
        <span className={`font-semibold text-xs uppercase tracking-wider ${color.icon}`}>{title}</span>
      </div>
      {children}
    </div>
  )
}

function Badge({ label, variant = 'default' }) {
  const styles = {
    default:  'bg-overlay text-muted border-border',
    green:    'bg-green/10 text-green border-green/30',
    yellow:   'bg-yellow/10 text-yellow border-yellow/30',
    red:      'bg-red/10 text-red border-red/30',
    purple:   'bg-purple/10 text-purple border-purple/30',
    blue:     'bg-accent/10 text-accent border-accent/30',
  }
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs border font-medium ${styles[variant]}`}>
      {label}
    </span>
  )
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between items-start gap-2 py-1.5 border-b border-border/40 last:border-0">
      <span className="text-muted text-xs">{label}</span>
      <span className="text-primary text-xs font-medium text-right">{String(value ?? '—')}</span>
    </div>
  )
}

// ── Severity → variant ────────────────────────────────────────────────────────
function severityVariant(s) {
  const m = { HIGH: 'red', MEDIUM: 'yellow', LOW: 'blue', CRITICAL: 'red' }
  return m[String(s).toUpperCase()] ?? 'default'
}

function verdictVariant(v) {
  const m = { PASS: 'green', FAIL: 'red', NEEDS_REVIEW: 'yellow' }
  return m[String(v).toUpperCase()] ?? 'default'
}

function tierVariant(t) {
  const m = { LOW: 'green', MEDIUM: 'yellow', HIGH: 'red', CRITICAL: 'red' }
  return m[String(t).toUpperCase()] ?? 'default'
}

// ── FraudCard ─────────────────────────────────────────────────────────────────
function FraudCard({ data }) {
  if (!data) return null
  const signals = data.signals ?? []
  return (
    <Card icon={ShieldAlert} title="Fraud Analysis" color={{ border: 'border-red/20', icon: 'text-red' }}>
      <div className="flex items-center gap-2 mb-3">
        <span className="text-primary font-semibold text-lg">{data.total_signals ?? 0}</span>
        <span className="text-muted text-xs">signal{(data.total_signals ?? 0) !== 1 ? 's' : ''} detected</span>
        {data.highest_severity && (
          <Badge label={`${data.highest_severity} severity`} variant={severityVariant(data.highest_severity)} />
        )}
      </div>

      {data.analysis_summary && (
        <p className="text-muted text-xs mb-3 leading-relaxed">{data.analysis_summary}</p>
      )}

      {signals.length > 0 && (
        <div className="space-y-2">
          {signals.map((sig, i) => (
            <div key={i} className="bg-overlay rounded-md p-2.5 border border-border/40">
              <div className="flex items-center justify-between mb-1">
                <span className="text-primary text-xs font-medium">{sig.signal_type}</span>
                <Badge label={sig.severity} variant={severityVariant(sig.severity)} />
              </div>
              <p className="text-muted text-xs">{sig.description}</p>
              {sig.confidence !== undefined && (
                <div className="flex items-center gap-1.5 mt-1.5">
                  <div className="flex-1 h-1 bg-border rounded-full overflow-hidden">
                    <div
                      className="h-full bg-red rounded-full"
                      style={{ width: `${Math.round(sig.confidence * 100)}%` }}
                    />
                  </div>
                  <span className="text-muted text-xs">{Math.round(sig.confidence * 100)}%</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {signals.length === 0 && data.total_signals === 0 && (
        <div className="flex items-center gap-2 text-green text-xs">
          <CheckCircle2 size={13} /> No fraud signals detected
        </div>
      )}
    </Card>
  )
}

// ── PolicyCard ────────────────────────────────────────────────────────────────
function PolicyCard({ data }) {
  if (!data) return null
  const checks = data.checks ?? []
  const verdict = data.overall_verdict ?? 'NEEDS_REVIEW'
  return (
    <Card icon={FileCheck} title="Policy Validation" color={{ border: 'border-yellow/20', icon: 'text-yellow' }}>
      <div className="flex items-center gap-2 mb-3">
        <Badge label={verdict.replace('_', ' ')} variant={verdictVariant(verdict)} />
        {data.claim_id && <span className="text-muted text-xs">Claim {data.claim_id}</span>}
      </div>

      {data.summary && (
        <p className="text-muted text-xs mb-3 leading-relaxed">{data.summary}</p>
      )}

      {checks.length > 0 && (
        <div className="space-y-1.5">
          {checks.map((chk, i) => (
            <div key={i} className="flex items-start gap-2 py-1.5 border-b border-border/40 last:border-0">
              {chk.verdict === 'PASS'
                ? <CheckCircle2 size={13} className="text-green mt-0.5 flex-shrink-0" />
                : chk.verdict === 'FAIL'
                ? <XCircle size={13} className="text-red mt-0.5 flex-shrink-0" />
                : <Info size={13} className="text-yellow mt-0.5 flex-shrink-0" />
              }
              <div>
                <span className="text-primary text-xs font-medium">{chk.check_name}</span>
                {chk.rationale && <p className="text-muted text-xs mt-0.5">{chk.rationale}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}

// ── RiskCard ──────────────────────────────────────────────────────────────────
function RiskCard({ data }) {
  if (!data) return null
  const prob = data.fraud_probability ?? 0
  const pct  = Math.round(prob * 100)
  const tier = data.risk_tier ?? 'LOW'
  const actions = data.recommended_actions ?? []

  const barColor = {
    LOW: 'bg-green', MEDIUM: 'bg-yellow', HIGH: 'bg-orange', CRITICAL: 'bg-red'
  }[tier] ?? 'bg-accent'

  return (
    <Card icon={BarChart3} title="Risk Score" color={{ border: 'border-purple/20', icon: 'text-purple' }}>
      {/* Probability bar */}
      <div className="mb-4">
        <div className="flex justify-between items-baseline mb-1.5">
          <span className="text-muted text-xs">Fraud Probability</span>
          <span className="text-primary font-bold text-lg">{pct}%</span>
        </div>
        <div className="h-2 bg-overlay rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all ${barColor}`} style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="space-y-0">
        <Row label="Risk Tier"    value={tier} />
        <Row label="Priority"     value={`${data.investigation_priority ?? '—'} / 10`} />
        {data.claim_id && <Row label="Claim ID" value={data.claim_id} />}
      </div>

      {data.score_rationale && (
        <p className="text-muted text-xs mt-3 leading-relaxed border-t border-border/40 pt-3">
          {data.score_rationale}
        </p>
      )}

      {actions.length > 0 && (
        <div className="mt-3 border-t border-border/40 pt-3">
          <p className="text-muted text-xs mb-2 uppercase tracking-wider">Recommended Actions</p>
          <ul className="space-y-1">
            {actions.map((a, i) => (
              <li key={i} className="flex items-start gap-1.5 text-xs text-primary">
                <AlertTriangle size={11} className="text-yellow mt-0.5 flex-shrink-0" />
                {a}
              </li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  )
}

// ── Main export ───────────────────────────────────────────────────────────────
export default function ResultCards({ fraudResult, policyResult, riskScore }) {
  const hasAny = fraudResult || policyResult || riskScore
  if (!hasAny) return null

  return (
    <div className="grid grid-cols-1 gap-3 mt-4">
      <FraudCard  data={fraudResult}  />
      <PolicyCard data={policyResult} />
      <RiskCard   data={riskScore}    />
    </div>
  )
}
