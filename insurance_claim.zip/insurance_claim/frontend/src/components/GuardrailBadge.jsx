/**
 * GuardrailBadge — compact summary of input/output guardrail results shown
 * inside each assistant message bubble.
 */
import { useState } from 'react'
import { ShieldCheck, ShieldAlert, ShieldX, ChevronDown, ChevronUp } from 'lucide-react'

const SEVERITY_COLOR = {
  LOW:      'text-accent',
  MEDIUM:   'text-yellow',
  HIGH:     'text-orange',
  CRITICAL: 'text-red',
}

const ACTION_LABEL = {
  block:  'BLOCKED',
  redact: 'REDACTED',
  warn:   'WARN',
}

const ACTION_COLOR = {
  block:  'text-red',
  redact: 'text-yellow',
  warn:   'text-muted',
}

function StageIcon({ passed, blocked }) {
  if (blocked)        return <ShieldX    size={13} className="text-red"   />
  if (!passed)        return <ShieldAlert size={13} className="text-yellow"/>
  return               <ShieldCheck  size={13} className="text-green" />
}

function StageLabel({ stage, passed, blocked, violationCount }) {
  const label  = stage === 'input' ? 'Input Guard' : 'Output Guard'
  const status = blocked
    ? 'Blocked'
    : violationCount > 0
    ? `${violationCount} warning${violationCount > 1 ? 's' : ''}`
    : 'Passed'
  const color  = blocked ? 'text-red' : violationCount > 0 ? 'text-yellow' : 'text-green'

  return (
    <span className="flex items-center gap-1">
      <StageIcon passed={passed} blocked={blocked} />
      <span className="text-muted text-xs">{label}:</span>
      <span className={`text-xs font-medium ${color}`}>{status}</span>
    </span>
  )
}

function ViolationRow({ v }) {
  return (
    <div className="flex items-start gap-2 py-1.5 border-b border-border/30 last:border-0">
      <span className={`text-xs font-mono font-bold flex-shrink-0 ${ACTION_COLOR[v.action] ?? 'text-muted'}`}>
        {ACTION_LABEL[v.action] ?? v.action.toUpperCase()}
      </span>
      <div>
        <span className={`text-xs font-medium ${SEVERITY_COLOR[v.severity] ?? 'text-muted'}`}>
          [{v.severity}]
        </span>
        {' '}
        <span className="text-xs text-primary">{v.message}</span>
        {v.detail && (
          <p className="text-xs text-muted mt-0.5 font-mono">{v.detail}</p>
        )}
      </div>
    </div>
  )
}

export default function GuardrailBadge({ inputGuardrail, outputGuardrail, answerRedacted }) {
  const [expanded, setExpanded] = useState(false)

  const guards = [
    inputGuardrail  && { stage: 'input',  ...inputGuardrail  },
    outputGuardrail && { stage: 'output', ...outputGuardrail },
  ].filter(Boolean)

  if (guards.length === 0) return null

  const anyBlocked   = guards.some(g => g.blocked)
  const totalViolations = guards.reduce((n, g) => n + (g.violations?.length ?? 0), 0)
  const hasIssues    = anyBlocked || totalViolations > 0

  return (
    <div className={`mt-2 rounded-md border text-xs
      ${anyBlocked
        ? 'border-red/30 bg-red/5'
        : hasIssues
        ? 'border-yellow/30 bg-yellow/5'
        : 'border-green/20 bg-green/5'
      }`}
    >
      {/* Summary row */}
      <button
        className="w-full flex items-center justify-between px-3 py-2 text-left"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex items-center gap-3">
          {guards.map(g => (
            <StageLabel
              key={g.stage}
              stage={g.stage}
              passed={g.passed}
              blocked={g.blocked}
              violationCount={g.violations?.length ?? 0}
            />
          ))}
          {answerRedacted && (
            <span className="text-yellow text-xs flex items-center gap-0.5">
              · PII redacted from answer
            </span>
          )}
        </div>
        {totalViolations > 0 && (
          expanded
            ? <ChevronUp size={12} className="text-muted flex-shrink-0" />
            : <ChevronDown size={12} className="text-muted flex-shrink-0" />
        )}
      </button>

      {/* Expanded violation detail */}
      {expanded && totalViolations > 0 && (
        <div className="px-3 pb-2 border-t border-border/30">
          {guards.map(g =>
            (g.violations ?? []).map((v, i) => (
              <ViolationRow key={`${g.stage}-${i}`} v={v} />
            ))
          )}
        </div>
      )}
    </div>
  )
}
