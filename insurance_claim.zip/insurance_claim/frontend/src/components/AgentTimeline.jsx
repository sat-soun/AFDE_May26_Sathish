/**
 * AgentTimeline — shows the 4-step agent pipeline with real-time status.
 */
import { CheckCircle2, Circle, Loader2, AlertCircle, Search, ShieldAlert, FileCheck, BarChart3 } from 'lucide-react'
import { PIPELINE_AGENTS } from '../hooks/useChat.js'

const AGENT_META = {
  claims_retrieval:  { label: 'Claims Retrieval',  icon: Search,      color: 'text-accent' },
  fraud_analysis:    { label: 'Fraud Analysis',    icon: ShieldAlert,  color: 'text-red' },
  policy_validation: { label: 'Policy Validation', icon: FileCheck,    color: 'text-yellow' },
  risk_scoring:      { label: 'Risk Scoring',       icon: BarChart3,    color: 'text-purple' },
}

function StatusIcon({ status, color }) {
  if (status === 'done')    return <CheckCircle2 size={16} className="text-green flex-shrink-0" />
  if (status === 'active')  return <Loader2 size={16} className={`${color} flex-shrink-0 animate-spin`} />
  if (status === 'error')   return <AlertCircle size={16} className="text-red flex-shrink-0" />
  return <Circle size={16} className="text-border flex-shrink-0" />
}

export default function AgentTimeline({ agentStatuses = {}, agentData = {}, retrievedCount = 0 }) {
  return (
    <div className="flex flex-col gap-1 mt-3 mb-2">
      {PIPELINE_AGENTS.map((agent, idx) => {
        const meta   = AGENT_META[agent]
        const status = agentStatuses[agent] ?? 'pending'
        const Icon   = meta.icon
        const isLast = idx === PIPELINE_AGENTS.length - 1

        // Build a short data hint
        let hint = ''
        if (status === 'done') {
          if (agent === 'claims_retrieval') {
            hint = retrievedCount ? `${retrievedCount} claim${retrievedCount !== 1 ? 's' : ''} retrieved` : 'done'
          } else if (agent === 'fraud_analysis') {
            const fr = agentData[agent]?.fraud_result
            hint = fr ? `${fr.total_signals ?? 0} signal(s) · ${fr.highest_severity ?? 'N/A'}` : 'done'
          } else if (agent === 'policy_validation') {
            const pv = agentData[agent]?.policy_result
            hint = pv ? `Verdict: ${pv.overall_verdict ?? 'N/A'}` : 'done'
          } else if (agent === 'risk_scoring') {
            const rs = agentData[agent]?.risk_score
            hint = rs
              ? `${(rs.fraud_probability * 100).toFixed(0)}% fraud · ${rs.risk_tier} tier`
              : 'done'
          }
        }

        return (
          <div key={agent} className="flex items-start gap-2">
            {/* Vertical connector */}
            <div className="flex flex-col items-center" style={{ width: 16 }}>
              <StatusIcon status={status} color={meta.color} />
              {!isLast && (
                <div className={`w-px flex-1 mt-1 ${status === 'done' ? 'bg-green/40' : 'bg-border/40'}`}
                     style={{ minHeight: 12 }} />
              )}
            </div>

            {/* Label + hint */}
            <div className="pb-2">
              <div className="flex items-center gap-1.5">
                <Icon size={12} className={`${status === 'active' ? meta.color : status === 'done' ? 'text-muted' : 'text-border'}`} />
                <span className={`text-xs font-medium ${
                  status === 'active' ? 'text-primary' :
                  status === 'done'   ? 'text-muted'   : 'text-border'
                }`}>
                  {meta.label}
                </span>
                {status === 'active' && (
                  <span className="flex gap-0.5 ml-1">
                    <span className="typing-dot w-1 h-1 bg-accent rounded-full inline-block" />
                    <span className="typing-dot w-1 h-1 bg-accent rounded-full inline-block" />
                    <span className="typing-dot w-1 h-1 bg-accent rounded-full inline-block" />
                  </span>
                )}
              </div>
              {hint && (
                <p className="text-xs text-muted ml-3.5 mt-0.5">{hint}</p>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
