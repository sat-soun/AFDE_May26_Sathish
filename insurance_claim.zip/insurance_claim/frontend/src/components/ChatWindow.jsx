/**
 * ChatWindow — scrollable message list with auto-scroll-to-bottom.
 */
import { useEffect, useRef } from 'react'
import { Shield } from 'lucide-react'
import MessageBubble from './MessageBubble.jsx'

function EmptyState() {
  const suggestions = [
    'Show me high-value auto claims with possible fraud signals',
    'Find claims with duplicate submissions in the last 6 months',
    'Which claims have policy coverage issues and high risk scores?',
    'Analyse claimant history for repeat offenders',
  ]

  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      <div className="w-16 h-16 rounded-2xl bg-surface border border-border flex items-center justify-center mb-6">
        <Shield size={28} className="text-accent" />
      </div>
      <h2 className="text-primary font-semibold text-xl mb-2">Insurance Claims Intelligence</h2>
      <p className="text-muted text-sm max-w-sm mb-8 leading-relaxed">
        Ask anything about your claims. The multi-agent pipeline will retrieve, analyse
        fraud signals, validate policies, and score risk — all in real time.
      </p>
      <div className="w-full max-w-lg grid grid-cols-1 gap-2">
        {suggestions.map((s, i) => (
          <button
            key={i}
            className="text-left px-4 py-3 rounded-lg bg-surface border border-border
                       text-muted text-sm hover:border-accent/40 hover:text-primary
                       hover:bg-overlay transition-all duration-150"
            onClick={() => {
              // Dispatch a custom event the InputBar / App can listen to
              window.dispatchEvent(new CustomEvent('suggestion', { detail: s }))
            }}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  )
}

export default function ChatWindow({ messages }) {
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  if (messages.length === 0) {
    return <EmptyState />
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6">
      <div className="max-w-3xl mx-auto space-y-6">
        {messages.map(msg => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  )
}
