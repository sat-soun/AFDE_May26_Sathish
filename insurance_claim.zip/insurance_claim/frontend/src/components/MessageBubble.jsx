/**
 * MessageBubble — renders a single message (user or assistant).
 */
import ReactMarkdown from 'react-markdown'
import { AlertCircle, User, Bot, ShieldX } from 'lucide-react'
import AgentTimeline  from './AgentTimeline.jsx'
import ResultCards    from './ResultCards.jsx'
import GuardrailBadge from './GuardrailBadge.jsx'

// ── User message ──────────────────────────────────────────────────────────────
function UserBubble({ content }) {
  return (
    <div className="flex justify-end gap-3 animate-slide-up">
      <div className="max-w-[80%] bg-accent/10 border border-accent/20 rounded-2xl rounded-tr-sm px-4 py-3">
        <p className="text-primary text-sm leading-relaxed">{content}</p>
      </div>
      <div className="w-8 h-8 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center flex-shrink-0 mt-0.5">
        <User size={14} className="text-accent" />
      </div>
    </div>
  )
}

// ── Typing indicator ──────────────────────────────────────────────────────────
function TypingIndicator() {
  return (
    <span className="flex gap-1 items-center h-4">
      <span className="typing-dot w-1.5 h-1.5 bg-muted rounded-full" />
      <span className="typing-dot w-1.5 h-1.5 bg-muted rounded-full" />
      <span className="typing-dot w-1.5 h-1.5 bg-muted rounded-full" />
    </span>
  )
}

// ── Blocked message ───────────────────────────────────────────────────────────
function BlockedBubble({ error, inputGuardrail }) {
  return (
    <div className="bg-red/5 border border-red/20 rounded-2xl rounded-tl-sm px-4 py-3">
      <div className="flex items-start gap-2 text-red text-sm">
        <ShieldX size={16} className="flex-shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold mb-1">Query blocked by guardrail</p>
          <p className="text-red/80 text-xs">{error}</p>
        </div>
      </div>
      {inputGuardrail && (
        <GuardrailBadge inputGuardrail={inputGuardrail} answerRedacted={false} />
      )}
    </div>
  )
}

// ── Assistant message ─────────────────────────────────────────────────────────
function AssistantBubble({ msg }) {
  const {
    status, agentStatuses, agentData, activeAgent,
    finalAnswer, retrievedCount,
    fraudResult, policyResult, riskScore,
    inputGuardrail, outputGuardrail, answerRedacted,
    error,
  } = msg

  const isStreaming = status === 'streaming'
  const isError     = status === 'error'
  const isBlocked   = status === 'blocked'

  if (isBlocked) {
    return (
      <div className="flex gap-3 animate-slide-up">
        <div className="w-8 h-8 rounded-full bg-surface border border-border flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot size={14} className="text-red" />
        </div>
        <div className="flex-1 max-w-[90%]">
          <BlockedBubble error={error} inputGuardrail={inputGuardrail} />
        </div>
      </div>
    )
  }

  return (
    <div className="flex gap-3 animate-slide-up">
      {/* Avatar */}
      <div className="w-8 h-8 rounded-full bg-surface border border-border flex items-center justify-center flex-shrink-0 mt-0.5">
        <Bot size={14} className="text-accent" />
      </div>

      {/* Bubble */}
      <div className="flex-1 max-w-[90%]">
        <div className="bg-surface border border-border rounded-2xl rounded-tl-sm px-4 py-3">

          {/* Agent pipeline progress */}
          {(isStreaming || Object.values(agentStatuses).some(s => s !== 'pending')) && (
            <AgentTimeline
              agentStatuses={agentStatuses}
              agentData={agentData}
              retrievedCount={retrievedCount}
            />
          )}

          {/* Error state */}
          {isError && (
            <div className="flex items-start gap-2 text-red text-sm mt-2">
              <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
              <span>{error || 'An error occurred. Please try again.'}</span>
            </div>
          )}

          {/* Final answer */}
          {finalAnswer ? (
            <div className="prose-dark text-sm mt-2 border-t border-border/40 pt-3">
              <ReactMarkdown>{finalAnswer}</ReactMarkdown>
            </div>
          ) : isStreaming && !activeAgent && !isError ? (
            <div className="mt-2">
              <TypingIndicator />
            </div>
          ) : null}

          {/* Guardrail badge */}
          <GuardrailBadge
            inputGuardrail={inputGuardrail}
            outputGuardrail={outputGuardrail}
            answerRedacted={answerRedacted}
          />
        </div>

        {/* Structured result cards */}
        <ResultCards
          fraudResult={fraudResult}
          policyResult={policyResult}
          riskScore={riskScore}
        />
      </div>
    </div>
  )
}

// ── Main export ───────────────────────────────────────────────────────────────
export default function MessageBubble({ message }) {
  if (message.role === 'user') {
    return <UserBubble content={message.content} />
  }
  return <AssistantBubble msg={message} />
}
