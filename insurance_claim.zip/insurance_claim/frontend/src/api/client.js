/**
 * API client for the Insurance Claims Intelligence backend.
 * All functions target /api/* which Vite proxies to http://localhost:8000.
 */

const BASE = '/api'

/** POST /api/chat — blocking full-pipeline call */
export async function chat(query) {
  const res = await fetch(`${BASE}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Chat request failed')
  }
  return res.json()
}

/**
 * POST /api/chat/stream — SSE streaming pipeline.
 *
 * @param {string} query
 * @param {(event: object) => void} onEvent  - called for each SSE event
 * @param {AbortSignal} [signal]             - optional cancellation
 */
export async function chatStream(query, onEvent, signal) {
  const res = await fetch(`${BASE}/chat/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
    signal,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Stream request failed')
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() ?? ''   // keep incomplete line

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const event = JSON.parse(line.slice(6))
          onEvent(event)
        } catch {
          // skip malformed lines
        }
      }
    }
  }
}

/** POST /api/agents/claims-retrieval */
export async function agentClaimsRetrieval(query) {
  const res = await fetch(`${BASE}/agents/claims-retrieval`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** POST /api/agents/fraud-analysis */
export async function agentFraudAnalysis(query, claims = []) {
  const res = await fetch(`${BASE}/agents/fraud-analysis`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, claims }),
  })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** POST /api/agents/policy-validation */
export async function agentPolicyValidation(query, claims = []) {
  const res = await fetch(`${BASE}/agents/policy-validation`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, claims }),
  })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** POST /api/agents/risk-scoring */
export async function agentRiskScoring(query, claims = [], fraudResult = null, policyResult = null) {
  const res = await fetch(`${BASE}/agents/risk-scoring`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, claims, fraud_result: fraudResult, policy_result: policyResult }),
  })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** POST /api/ingest/default — ingest all CSVs in data/raw/ */
export async function ingestDefault() {
  const res = await fetch(`${BASE}/ingest/default`, { method: 'POST' })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** POST /api/ingest — upload and ingest a CSV file */
export async function ingestFile(file) {
  const form = new FormData()
  form.append('file', file)
  const res = await fetch(`${BASE}/ingest`, { method: 'POST', body: form })
  if (!res.ok) throw new Error((await res.json()).detail)
  return res.json()
}

/** GET /api/health */
export async function healthCheck() {
  const res = await fetch(`${BASE}/health`)
  if (!res.ok) throw new Error('API is unreachable')
  return res.json()
}
