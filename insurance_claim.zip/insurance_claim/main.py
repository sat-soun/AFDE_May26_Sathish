"""
Entry point for the Insurance Claims Intelligence Multi-Agent System.

Usage
──────
  # 1. Ingest data (run once, or whenever the CSV changes)
  python main.py ingest --csv data/raw/claims.csv

  # 2. Ask a question
  python main.py query "Show me high-value auto claims with possible fraud signals"

  # 3. Interactive mode
  python main.py interactive
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


# ── CLI handlers ──────────────────────────────────────────────────────────────

def cmd_ingest(args: argparse.Namespace) -> None:
    """Run the CSV → chunk → embed → persist pipeline."""
    from src.ingestion.embedder import run_ingestion_pipeline

    csv_path = Path(args.csv)
    if not csv_path.exists():
        logger.error("CSV file not found: %s", csv_path)
        sys.exit(1)

    logger.info("Starting ingestion pipeline for: %s", csv_path)
    run_ingestion_pipeline(csv_path, max_chars=args.max_chars)
    logger.info("Ingestion complete. Vector store is ready.")


def cmd_query(args: argparse.Namespace) -> None:
    """Run a single query through the multi-agent graph."""
    from langchain_core.messages import HumanMessage
    from src.graph.builder import get_graph

    graph = get_graph()
    initial_state = {
        "messages": [HumanMessage(content=args.query)],
        "query": args.query,
        "next_agent": "",
        "retrieved_claims": [],
        "fraud_result": None,
        "policy_result": None,
        "risk_score": None,
        "agent_outputs": [],
        "final_answer": None,
        "error": None,
    }

    logger.info("Running query: %s", args.query)
    result = graph.invoke(initial_state)

    print("\n" + "═" * 70)
    print("FINAL ANSWER")
    print("═" * 70)
    print(result.get("final_answer", "No answer generated."))
    print("═" * 70 + "\n")

    if args.verbose:
        print("Agent outputs:")
        print(json.dumps(result.get("agent_outputs", []), indent=2, default=str))


def cmd_interactive(_args: argparse.Namespace) -> None:
    """Interactive REPL loop."""
    from langchain_core.messages import HumanMessage
    from src.graph.builder import get_graph

    graph = get_graph()
    print("Insurance Claims Intelligence Assistant")
    print("Type 'exit' or 'quit' to stop.\n")

    while True:
        try:
            query = input("Query > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if query.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        if not query:
            continue

        initial_state = {
            "messages": [HumanMessage(content=query)],
            "query": query,
            "next_agent": "",
            "retrieved_claims": [],
            "fraud_result": None,
            "policy_result": None,
            "risk_score": None,
            "agent_outputs": [],
            "final_answer": None,
            "error": None,
        }

        result = graph.invoke(initial_state)
        print("\n" + result.get("final_answer", "No answer generated.") + "\n")


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Insurance Claims Multi-Agent Intelligence System"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ingest
    p_ingest = subparsers.add_parser("ingest", help="Ingest CSV data into vector store")
    p_ingest.add_argument("--csv", required=True, help="Path to raw claims CSV file")
    p_ingest.add_argument("--max-chars", type=int, default=1500, help="Chunking threshold")
    p_ingest.set_defaults(func=cmd_ingest)

    # query
    p_query = subparsers.add_parser("query", help="Run a single query")
    p_query.add_argument("query", help="Natural-language query string")
    p_query.add_argument("-v", "--verbose", action="store_true")
    p_query.set_defaults(func=cmd_query)

    # interactive
    p_interactive = subparsers.add_parser("interactive", help="Interactive REPL mode")
    p_interactive.set_defaults(func=cmd_interactive)

    return parser


if __name__ == "__main__":
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
