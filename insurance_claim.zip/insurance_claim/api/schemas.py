"""
API-level Pydantic request/response schemas.

Kept separate from src/models/schemas.py (domain models) so the HTTP layer
can evolve independently of the agent internals.
"""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ── Guardrail summary (embedded in every response) ────────────────────────────

class GuardrailViolationSchema(BaseModel):
    guardrail: str
    severity:  str
    action:    str
    message:   str
    detail:    Optional[str] = None


class GuardrailSummary(BaseModel):
    stage:    str                                   # "input" | "output"
    passed:   bool
    blocked:  bool
    violations: list[GuardrailViolationSchema] = Field(default_factory=list)


# ── Request models ─────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, description="Natural-language query to analyse")


class ClaimsRetrievalRequest(BaseModel):
    query: str = Field(..., min_length=1, description="Search query for claim retrieval")


class FraudAnalysisRequest(BaseModel):
    query: str = Field(..., min_length=1)
    claims: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Claim records to analyse (use output from /agents/claims-retrieval)",
    )


class PolicyValidationRequest(BaseModel):
    query: str = Field(..., min_length=1)
    claims: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Claim records to validate against policy terms",
    )


class RiskScoringRequest(BaseModel):
    query: str = Field(..., min_length=1)
    claims: list[dict[str, Any]] = Field(default_factory=list)
    fraud_result: Optional[dict[str, Any]] = Field(
        None, description="Output from /agents/fraud-analysis"
    )
    policy_result: Optional[dict[str, Any]] = Field(
        None, description="Output from /agents/policy-validation"
    )


# ── Response models ────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    service: str
    version: str


class ChatResponse(BaseModel):
    query: str
    final_answer: str
    retrieved_claims_count: int
    fraud_result: Optional[dict[str, Any]] = None
    policy_result: Optional[dict[str, Any]] = None
    risk_score: Optional[dict[str, Any]] = None
    agent_outputs: list[dict[str, Any]] = Field(default_factory=list)
    guardrails: list[GuardrailSummary] = Field(
        default_factory=list,
        description="Input and output guardrail results"
    )
    answer_redacted: bool = Field(
        False,
        description="True if PII was redacted from the final answer"
    )
    error: Optional[str] = None


class ClaimsRetrievalResponse(BaseModel):
    claims: list[dict[str, Any]]
    summary: str
    count: int


class FraudAnalysisResponse(BaseModel):
    fraud_analysis: dict[str, Any]
    success: bool = True


class PolicyValidationResponse(BaseModel):
    policy_validation: dict[str, Any]
    success: bool = True


class RiskScoringResponse(BaseModel):
    risk_score: dict[str, Any]
    success: bool = True


class IngestResponse(BaseModel):
    status: str
    message: str
    files: list[str] = Field(default_factory=list)
