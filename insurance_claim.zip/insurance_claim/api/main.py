"""
FastAPI application entry point.

Run with:
    uvicorn api.main:app --reload --port 8000

Swagger UI: http://localhost:8000/api/docs
"""
from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routers import agents, chat, eval, ingest
from api.schemas import HealthResponse

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)

app = FastAPI(
    title="Insurance Claims Intelligence API",
    description=(
        "Multi-agent insurance claims analysis powered by LangGraph.\n\n"
        "Use `/api/chat/stream` for real-time SSE updates while agents run, "
        "or `/api/chat` for a single blocking response."
    ),
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",   # Vite dev server
        "http://localhost:3000",   # CRA / other
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(chat.router,   prefix="/api",        tags=["Chat"])
app.include_router(agents.router, prefix="/api/agents", tags=["Agents"])
app.include_router(ingest.router, prefix="/api",        tags=["Ingestion"])
app.include_router(eval.router,   prefix="/api/eval",   tags=["Evaluation"])


@app.get("/api/health", response_model=HealthResponse, tags=["System"])
async def health_check() -> HealthResponse:
    """Liveness / readiness probe."""
    return HealthResponse(
        status="healthy",
        service="Insurance Claims Intelligence API",
        version="1.0.0",
    )
