"""
Chat router — full orchestrated multi-agent pipeline with guardrails.

Request flow
────────────
  POST body
    │
    ▼
  InputGuardrailPipeline          ← regex: length, injection, PII
    │  (if blocked → 400)           LLM:   topic classification
    ▼
  LangGraph pipeline               ← supervisor + 4 specialist agents
    │
    ▼
  OutputGuardrailPipeline         ← regex: PII scrub, numeric sanity
    │                               LLM:   relevance check
    ▼
  Response (with guardrail summary)

Endpoints
─────────
POST /api/chat          → blocking, returns complete ChatResponse
POST /api/chat/stream   → SSE stream; yields events as each node runs
"""
from __future__ import annotations

import json
import logging
from typing import AsyncGenerator

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from langchain_core.messages import HumanMessage

from api.schemas import ChatRequest, ChatResponse, GuardrailSummary, GuardrailViolationSchema
from src.guardrails import InputGuardrailPipeline, OutputGuardrailPipeline
from src.guardrails.models import PipelineGuardrailResult

logger = logging.getLogger(__name__)
router = APIRouter()

# Singletons — built once, reused across requests
_input_pipeline  = InputGuardrailPipeline(enable_topic_classifier=True)
_output_pipeline = OutputGuardrailPipeline(enable_relevance_checker=True)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_initial_state(query: str) -> dict:
    return {
        "messages": [HumanMessage(content=query)],
        "query": query,
        "next_agent": "",
        "retrieved_claims": [],
        "fraud_result": None,
        "policy_result": None,
        "risk_score": None,
        "agent_outputs": [],
        "final_answer": None,
        "error": None,
    }


def _safe_json(obj: dict) -> dict:
    """Strip LangChain message objects; make everything JSON-serialisable."""
    out = {}
    for k, v in obj.items():
        if k == "messages":
            continue
        try:
            json.dumps(v, default=str)
            out[k] = v
        except Exception:
            out[k] = str(v)
    return out


def _guardrail_to_schema(pr: PipelineGuardrailResult) -> GuardrailSummary:
    return GuardrailSummary(
        stage=pr.stage,
        passed=pr.passed,
        blocked=pr.blocked,
        violations=[
            GuardrailViolationSchema(
                guardrail=v.guardrail,
                severity=v.severity.value,
                action=v.action.value,
                message=v.message,
                detail=v.detail,
            )
            for v in pr.violations
        ],
    )


# ── SSE streaming ──────────────────────────────────────────────────────────────

async def _stream_pipeline(query: str) -> AsyncGenerator[str, None]:
    """
    Runs input guardrails → LangGraph → output guardrails, yielding SSE events.

    SSE event shapes
    ─────────────────
    {"type": "start",          "query": "..."}
    {"type": "guardrail",      "stage": "input",  "passed": bool, "violations": [...]}
    {"type": "routing",        "node": "supervisor", "next_agent": "..."}
    {"type": "agent_update",   "node": "<name>",  "data": {...}}
    {"type": "final_answer",   "node": "finalize","answer": "...", "redacted": bool}
    {"type": "guardrail",      "stage": "output", "passed": bool, "violations": [...]}
    {"type": "done"}
    {"type": "error",          "message": "..."}
    """
    from src.graph.builder import get_graph

    def emit(payload: dict) -> str:
        return f"data: {json.dumps(payload, default=str)}\n\n"

    try:
        yield emit({"type": "start", "query": query})

        # ── Input guardrails ───────────────────────────────────────────
        input_gr = _input_pipeline.run(query)
        yield emit({
            "type":       "guardrail",
            "stage":      "input",
            "passed":     input_gr.passed,
            "blocked":    input_gr.blocked,
            "violations": [
                {"guardrail": v.guardrail, "severity": v.severity.value,
                 "action": v.action.value, "message": v.message}
                for v in input_gr.violations
            ],
        })

        if input_gr.blocked:
            first = input_gr.violations[0]
            yield emit({"type": "error", "message": first.message})
            return

        # ── LangGraph pipeline ─────────────────────────────────────────
        graph = get_graph()
        state = _build_initial_state(query)

        # Track structured results for output guardrail
        fraud_result  = None
        policy_result = None
        risk_score    = None
        final_answer  = ""

        for chunk in graph.stream(state, stream_mode="updates"):
            for node_name, node_output in chunk.items():
                safe = _safe_json(node_output)

                if node_name == "supervisor":
                    yield emit({
                        "type":       "routing",
                        "node":       "supervisor",
                        "next_agent": node_output.get("next_agent", ""),
                    })

                elif node_name == "finalize":
                    final_answer = node_output.get("final_answer", "")
                    # Output guardrails applied after the loop; send placeholder
                    pass

                else:
                    payload: dict = {}
                    for k, v in safe.items():
                        if k == "agent_outputs":
                            continue
                        if k == "retrieved_claims":
                            payload["retrieved_claims_count"] = len(v or [])
                        else:
                            payload[k] = v

                    # Capture structured results for output guardrail
                    if "fraud_result"  in payload: fraud_result  = payload["fraud_result"]
                    if "policy_result" in payload: policy_result = payload["policy_result"]
                    if "risk_score"    in payload: risk_score    = payload["risk_score"]

                    yield emit({"type": "agent_update", "node": node_name, "data": payload})

        # ── Output guardrails ──────────────────────────────────────────
        output_gr = _output_pipeline.run(
            answer        = final_answer,
            query         = query,
            fraud_result  = fraud_result,
            policy_result = policy_result,
            risk_score    = risk_score,
        )
        redacted_answer = output_gr.sanitized_text or final_answer
        was_redacted    = redacted_answer != final_answer

        yield emit({
            "type":     "final_answer",
            "node":     "finalize",
            "answer":   redacted_answer,
            "redacted": was_redacted,
        })

        yield emit({
            "type":       "guardrail",
            "stage":      "output",
            "passed":     output_gr.passed,
            "blocked":    output_gr.blocked,
            "violations": [
                {"guardrail": v.guardrail, "severity": v.severity.value,
                 "action": v.action.value, "message": v.message}
                for v in output_gr.violations
            ],
        })

        yield emit({"type": "done"})

    except Exception as exc:
        logger.exception("SSE stream error: %s", exc)
        yield emit({"type": "error", "message": str(exc)})


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.post("/chat/stream", summary="Stream pipeline via SSE (with guardrails)")
async def chat_stream(request: ChatRequest) -> StreamingResponse:
    """
    Run the full multi-agent pipeline and stream progress as Server-Sent Events.
    Input guardrails fire before the first agent; output guardrails fire after
    the final answer is assembled.
    """
    return StreamingResponse(
        _stream_pipeline(request.query),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@router.post(
    "/chat",
    response_model=ChatResponse,
    summary="Run pipeline (blocking, with guardrails)",
)
async def chat(request: ChatRequest) -> ChatResponse:
    """
    Run the full multi-agent pipeline synchronously.
    Input + output guardrail results are included in the response.
    """
    from src.graph.builder import get_graph

    # ── Input guardrails ───────────────────────────────────────────────────────
    input_gr = _input_pipeline.run(request.query)
    if input_gr.blocked:
        first_violation = input_gr.violations[0]
        raise HTTPException(
            status_code=400,
            detail={
                "message": first_violation.message,
                "guardrail": first_violation.guardrail,
                "severity": first_violation.severity.value,
            },
        )

    # ── LangGraph pipeline ─────────────────────────────────────────────────────
    graph = get_graph()
    state = _build_initial_state(request.query)

    try:
        result = graph.invoke(state)
    except Exception as exc:
        logger.exception("Graph invocation failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    final_answer  = result.get("final_answer") or ""
    fraud_result  = result.get("fraud_result")
    policy_result = result.get("policy_result")
    risk_score    = result.get("risk_score")

    # ── Output guardrails ──────────────────────────────────────────────────────
    output_gr = _output_pipeline.run(
        answer        = final_answer,
        query         = request.query,
        fraud_result  = fraud_result,
        policy_result = policy_result,
        risk_score    = risk_score,
    )
    clean_answer = output_gr.sanitized_text or final_answer
    was_redacted = clean_answer != final_answer

    return ChatResponse(
        query                 = request.query,
        final_answer          = clean_answer or "No answer generated.",
        retrieved_claims_count= len(result.get("retrieved_claims", [])),
        fraud_result          = fraud_result,
        policy_result         = policy_result,
        risk_score            = risk_score,
        agent_outputs         = result.get("agent_outputs", []),
        guardrails            = [
            _guardrail_to_schema(input_gr),
            _guardrail_to_schema(output_gr),
        ],
        answer_redacted       = was_redacted,
        error                 = result.get("error"),
    )
