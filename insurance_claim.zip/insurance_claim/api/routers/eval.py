"""
Evaluation router — trigger RAGAS / DeepEval evaluation runs via HTTP.

Endpoints
─────────
POST /api/eval/ragas        → run RAGAS on provided samples or golden dataset
POST /api/eval/deepeval     → run DeepEval on provided samples or golden dataset
POST /api/eval/run          → run both evaluators against the golden dataset
GET  /api/eval/test-cases   → list available golden test cases
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter()


# ── Request / response models ──────────────────────────────────────────────────

class EvalSample(BaseModel):
    """A single manually-provided evaluation sample."""
    question:  str
    answer:    str
    contexts:  list[str] = Field(default_factory=list)
    reference: str = ""


class RagasEvalRequest(BaseModel):
    samples: list[EvalSample] = Field(
        default_factory=list,
        description="Provide samples directly, or leave empty to run the golden dataset through the live pipeline.",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Filter golden test cases by tag (e.g. ['fraud', 'retrieval']). Ignored when samples are provided.",
    )


class DeepEvalRequest(BaseModel):
    samples: list[EvalSample] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)


class FullEvalRequest(BaseModel):
    tags:            list[str] = Field(default_factory=list)
    enable_ragas:    bool = True
    enable_deepeval: bool = True


class TestCaseSummary(BaseModel):
    id:             str
    question:       str
    expected_fraud: bool
    expected_tier:  str
    tags:           list[str]


# ── Helpers ────────────────────────────────────────────────────────────────────

def _samples_to_ragas(samples: list[EvalSample]):
    from src.evaluation.ragas_eval import RagasSample
    return [
        RagasSample(
            question  = s.question,
            answer    = s.answer,
            contexts  = s.contexts or ["No context provided."],
            reference = s.reference,
        )
        for s in samples
    ]


def _samples_to_deepeval(samples: list[EvalSample], evaluator):
    return [
        evaluator.build_test_case(
            question          = s.question,
            answer            = s.answer,
            expected_output   = s.reference,
            retrieval_context = s.contexts or ["No context provided."],
            test_case_id      = f"manual-{i}",
        )
        for i, s in enumerate(samples)
    ]


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/test-cases", response_model=list[TestCaseSummary], summary="List golden test cases")
async def list_test_cases(tags: Optional[str] = None) -> list[TestCaseSummary]:
    """
    Return the available golden test cases.
    Pass ``?tags=fraud,retrieval`` to filter by comma-separated tags.
    """
    from src.evaluation.test_cases import get_test_cases

    tag_list = [t.strip() for t in tags.split(",")] if tags else None
    cases    = get_test_cases(tag_list)
    return [
        TestCaseSummary(
            id             = tc.id,
            question       = tc.question,
            expected_fraud = tc.expected_fraud,
            expected_tier  = tc.expected_tier,
            tags           = tc.tags,
        )
        for tc in cases
    ]


@router.post("/ragas", summary="Run RAGAS evaluation")
async def eval_ragas(request: RagasEvalRequest) -> dict[str, Any]:
    """
    Run RAGAS metrics (faithfulness, answer relevancy, context precision/recall).

    - Provide ``samples`` to evaluate pre-collected outputs directly.
    - Leave ``samples`` empty to run the golden test cases through the live pipeline.
    """
    try:
        from src.evaluation.ragas_eval import RagasEvaluator
        evaluator = RagasEvaluator()

        if request.samples:
            result = evaluator.evaluate(_samples_to_ragas(request.samples))
        else:
            from src.evaluation.test_cases import get_test_cases
            cases  = get_test_cases(request.tags or None)
            result = evaluator.evaluate_pipeline(test_cases=cases)

        return result

    except ImportError as e:
        raise HTTPException(
            status_code=501,
            detail=f"RAGAS not installed. Run: pip install ragas. ({e})",
        )
    except Exception as exc:
        logger.exception("RAGAS evaluation error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/deepeval", summary="Run DeepEval evaluation")
async def eval_deepeval(request: DeepEvalRequest) -> dict[str, Any]:
    """
    Run DeepEval metrics (answer relevancy, faithfulness, contextual precision/recall,
    hallucination, fraud detection accuracy, risk tier accuracy).

    - Provide ``samples`` to evaluate pre-collected outputs directly.
    - Leave ``samples`` empty to run the golden test cases through the live pipeline.
    """
    try:
        from src.evaluation.deepeval_eval import DeepEvalEvaluator
        evaluator = DeepEvalEvaluator()

        if request.samples:
            cases  = _samples_to_deepeval(request.samples, evaluator)
            result = evaluator.evaluate(cases)
        else:
            from src.evaluation.test_cases import get_test_cases
            tc_list = get_test_cases(request.tags or None)
            result  = evaluator.evaluate_pipeline(test_cases=tc_list)

        return result

    except ImportError as e:
        raise HTTPException(
            status_code=501,
            detail=f"DeepEval not installed. Run: pip install deepeval. ({e})",
        )
    except Exception as exc:
        logger.exception("DeepEval evaluation error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/run", summary="Run full evaluation suite (RAGAS + DeepEval)")
async def eval_run(request: FullEvalRequest) -> dict[str, Any]:
    """
    Run the complete evaluation harness:
      1. Execute each golden test case through the live pipeline.
      2. Evaluate with RAGAS (if enabled).
      3. Evaluate with DeepEval (if enabled).
      4. Return a combined report with per-metric aggregate scores and a summary.

    This is a **synchronous** endpoint — it may take several minutes for large
    test suites. Consider running via CLI for long evaluations:

        python -m src.evaluation.harness --tags fraud --out results.json
    """
    try:
        from src.evaluation.harness import EvaluationHarness
        from src.evaluation.test_cases import get_test_cases

        harness = EvaluationHarness(
            enable_ragas    = request.enable_ragas,
            enable_deepeval = request.enable_deepeval,
        )
        cases  = get_test_cases(request.tags or None)
        report = harness.run(test_cases=cases)
        return report

    except Exception as exc:
        logger.exception("Full evaluation run error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))
