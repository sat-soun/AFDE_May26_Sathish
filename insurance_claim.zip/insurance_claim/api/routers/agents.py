"""
Individual agent endpoints with input guardrails.

Each endpoint runs the InputGuardrailPipeline before invoking the agent.
Topic classification is disabled here (agents may be called directly with
narrow, targeted queries), but PII detection and injection blocking still apply.

Endpoints
─────────
POST /api/agents/claims-retrieval
POST /api/agents/fraud-analysis
POST /api/agents/policy-validation
POST /api/agents/risk-scoring
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException
from langchain_core.messages import HumanMessage

from api.schemas import (
    ClaimsRetrievalRequest, ClaimsRetrievalResponse,
    FraudAnalysisRequest,   FraudAnalysisResponse,
    PolicyValidationRequest, PolicyValidationResponse,
    RiskScoringRequest,      RiskScoringResponse,
)
from src.guardrails import InputGuardrailPipeline

logger = logging.getLogger(__name__)
router = APIRouter()

# Topic classifier OFF for direct agent calls — queries are narrow by design
_input_pipeline = InputGuardrailPipeline(enable_topic_classifier=False)


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _guard_or_raise(query: str) -> None:
    """Run input guardrails; raise 400 if blocked."""
    result = _input_pipeline.run(query)
    if result.blocked:
        first = result.violations[0]
        raise HTTPException(
            status_code=400,
            detail={
                "message":   first.message,
                "guardrail": first.guardrail,
                "severity":  first.severity.value,
            },
        )


def _base_state(query: str) -> dict:
    return {
        "messages": [HumanMessage(content=query)],
        "query": query,
        "next_agent": "",
        "retrieved_claims": [],
        "fraud_result": None,
        "policy_result": None,
        "risk_score": None,
        "agent_outputs": [],
        "final_answer": None,
        "error": None,
    }


# ── Claims Retrieval ───────────────────────────────────────────────────────────

@router.post(
    "/claims-retrieval",
    response_model=ClaimsRetrievalResponse,
    summary="Retrieve similar claims (with input guardrails)",
)
async def claims_retrieval(request: ClaimsRetrievalRequest) -> ClaimsRetrievalResponse:
    """
    Translate a natural-language query into a semantic vector search and return
    the most relevant historical insurance claim records.

    Input guardrails applied: length · injection · PII detection.
    """
    _guard_or_raise(request.query)

    from src.agents.claims_retrieval import ClaimsRetrievalAgent
    try:
        agent  = ClaimsRetrievalAgent()
        result = agent.run(_base_state(request.query))
    except Exception as exc:
        logger.exception("ClaimsRetrievalAgent error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    if not result.success:
        raise HTTPException(status_code=500, detail=result.error or "Agent failed")

    claims = result.data.get("claims", [])
    return ClaimsRetrievalResponse(
        claims  = claims,
        summary = result.data.get("summary", ""),
        count   = len(claims),
    )


# ── Fraud Analysis ─────────────────────────────────────────────────────────────

@router.post(
    "/fraud-analysis",
    response_model=FraudAnalysisResponse,
    summary="Detect fraud signals (with input guardrails)",
)
async def fraud_analysis(request: FraudAnalysisRequest) -> FraudAnalysisResponse:
    """
    Examine claim records for known fraud patterns, duplicate submissions,
    and suspicious claimant history.

    Input guardrails applied: length · injection · PII detection.
    """
    _guard_or_raise(request.query)

    from src.agents.fraud_analysis import FraudAnalysisAgent
    try:
        agent  = FraudAnalysisAgent()
        state  = {**_base_state(request.query), "retrieved_claims": request.claims}
        result = agent.run(state)
    except Exception as exc:
        logger.exception("FraudAnalysisAgent error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    if not result.success:
        raise HTTPException(status_code=500, detail=result.error or "Agent failed")

    return FraudAnalysisResponse(
        fraud_analysis=result.data.get("fraud_analysis", {}),
        success=True,
    )


# ── Policy Validation ──────────────────────────────────────────────────────────

@router.post(
    "/policy-validation",
    response_model=PolicyValidationResponse,
    summary="Validate policy compliance (with input guardrails)",
)
async def policy_validation(request: PolicyValidationRequest) -> PolicyValidationResponse:
    """
    Verify that claims satisfy coverage limits, eligibility conditions,
    and policy terms.

    Input guardrails applied: length · injection · PII detection.
    """
    _guard_or_raise(request.query)

    from src.agents.policy_validation import PolicyValidationAgent
    try:
        agent  = PolicyValidationAgent()
        state  = {**_base_state(request.query), "retrieved_claims": request.claims}
        result = agent.run(state)
    except Exception as exc:
        logger.exception("PolicyValidationAgent error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    if not result.success:
        raise HTTPException(status_code=500, detail=result.error or "Agent failed")

    return PolicyValidationResponse(
        policy_validation=result.data.get("policy_validation", {}),
        success=True,
    )


# ── Risk Scoring ───────────────────────────────────────────────────────────────

@router.post(
    "/risk-scoring",
    response_model=RiskScoringResponse,
    summary="Compute risk score (with input guardrails)",
)
async def risk_scoring(request: RiskScoringRequest) -> RiskScoringResponse:
    """
    Synthesise fraud analysis and policy validation outputs into an
    explainable fraud probability score and investigation priority.

    Input guardrails applied: length · injection · PII detection.
    """
    _guard_or_raise(request.query)

    from src.agents.risk_scoring import RiskScoringAgent
    try:
        agent  = RiskScoringAgent()
        state  = {
            **_base_state(request.query),
            "retrieved_claims": request.claims,
            "fraud_result":     request.fraud_result,
            "policy_result":    request.policy_result,
        }
        result = agent.run(state)
    except Exception as exc:
        logger.exception("RiskScoringAgent error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    if not result.success:
        raise HTTPException(status_code=500, detail=result.error or "Agent failed")

    return RiskScoringResponse(
        risk_score=result.data.get("risk_score", {}),
        success=True,
    )
