"""
Ingestion router — trigger the CSV → chunk → embed → persist pipeline.

Endpoints
─────────
POST /api/ingest         → upload a CSV file and ingest it
POST /api/ingest/default → ingest all CSVs already in data/raw/
"""
from __future__ import annotations

import logging
import tempfile
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile

from api.schemas import IngestResponse

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/ingest", response_model=IngestResponse, summary="Upload and ingest a CSV")
async def ingest_upload(file: UploadFile = File(...)) -> IngestResponse:
    """
    Upload a CSV file containing insurance claim records and embed them
    into the vector store. Accepted format: same schema as `data/raw/*.csv`.
    """
    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are accepted.")

    try:
        from src.ingestion.embedder import run_ingestion_pipeline

        contents = await file.read()

        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
            tmp.write(contents)
            tmp_path = Path(tmp.name)

        try:
            run_ingestion_pipeline(tmp_path)
        finally:
            tmp_path.unlink(missing_ok=True)

        return IngestResponse(
            status="success",
            message=f"'{file.filename}' ingested successfully.",
            files=[file.filename],
        )

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Ingestion failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@router.post(
    "/ingest/default",
    response_model=IngestResponse,
    summary="Ingest all CSVs from data/raw/",
)
async def ingest_default() -> IngestResponse:
    """
    Run the ingestion pipeline over every CSV found in `data/raw/`.
    Use this after adding new files to the raw data directory.
    """
    from config.settings import get_settings
    from src.ingestion.embedder import run_ingestion_pipeline

    settings = get_settings()
    raw_dir = settings.raw_data_dir
    csv_files = sorted(raw_dir.glob("*.csv"))

    if not csv_files:
        raise HTTPException(
            status_code=404,
            detail=f"No CSV files found in {raw_dir}. Add files and retry.",
        )

    ingested: list[str] = []
    errors: list[str] = []

    for csv_path in csv_files:
        try:
            logger.info("Ingesting %s …", csv_path.name)
            run_ingestion_pipeline(csv_path)
            ingested.append(csv_path.name)
        except Exception as exc:
            logger.error("Failed to ingest %s: %s", csv_path.name, exc)
            errors.append(f"{csv_path.name}: {exc}")

    if errors and not ingested:
        raise HTTPException(status_code=500, detail="; ".join(errors))

    message = f"Ingested {len(ingested)} file(s)."
    if errors:
        message += f" {len(errors)} file(s) failed: {'; '.join(errors)}"

    return IngestResponse(
        status="success" if not errors else "partial",
        message=message,
        files=ingested,
    )
