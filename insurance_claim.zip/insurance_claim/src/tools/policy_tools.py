"""
Policy validation tools — used by the Policy Validation Agent.
Checks derived from fraud_oracle.csv fields:
  PolicyType, BasePolicy, Deductible, Days_Policy_Accident,
  Days_Policy_Claim, VehiclePrice, Fault
"""
from __future__ import annotations
import json
import logging
from langchain_core.tools import tool

logger = logging.getLogger(__name__)

_COVERAGE_MAP = {
    "Liability": {
        "description": "Covers third-party injury and property damage only.",
        "covers_own_vehicle_damage": False,
        "covers_third_party": True,
        "deductible_range": (300, 700),
    },
    "Collision": {
        "description": "Covers damage to own vehicle from collision events.",
        "covers_own_vehicle_damage": True,
        "covers_third_party": False,
        "deductible_range": (400, 900),
    },
    "All Perils": {
        "description": "Comprehensive: own damage + third-party + theft/weather.",
        "covers_own_vehicle_damage": True,
        "covers_third_party": True,
        "deductible_range": (300, 700),
    },
}

_WAITING_PERIOD_VIOLATION = {"none"}


def _normalise(value) -> str:
    return str(value).strip().lower()


@tool
def validate_policy_compliance(claim_json: str) -> str:
    """
    Run a structured compliance checklist against a single claim record.

    Checks: waiting period, coverage consistency, deductible, high-value vehicle,
    claim reporting timeliness.

    Args:
        claim_json: JSON string of a single claim record dict (or list of dicts).

    Returns:
        JSON string of a list of PolicyCheckItem dicts.
    """
    try:
        claim = json.loads(claim_json)
        if isinstance(claim, list):
            claim = claim[0] if claim else {}
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid claim JSON"})

    checks = []
    base_policy = str(claim.get("BasePolicy", "")).strip()
    fault = _normalise(claim.get("Fault", ""))
    days_accident = _normalise(claim.get("Days_Policy_Accident", ""))
    days_claim = _normalise(claim.get("Days_Policy_Claim", ""))
    vehicle_price = _normalise(claim.get("VehiclePrice", ""))

    try:
        deductible = int(str(claim.get("Deductible", 0)).strip())
    except (ValueError, TypeError):
        deductible = 0

    # Check 1: Waiting period
    if days_accident in _WAITING_PERIOD_VIOLATION:
        checks.append({
            "check_name": "waiting_period", "verdict": "FAIL",
            "rationale": (
                "Claim filed on same day as accident (Days_Policy_Accident=none). "
                "Verify no mandatory waiting period applies."
            ),
            "requires_human_review": True,
        })
    else:
        checks.append({
            "check_name": "waiting_period", "verdict": "PASS",
            "rationale": "Days between policy start and accident: {}.".format(
                claim.get("Days_Policy_Accident", "N/A")),
            "requires_human_review": False,
        })

    # Check 2: Coverage consistency
    coverage = _COVERAGE_MAP.get(base_policy, {})
    if not coverage:
        checks.append({
            "check_name": "coverage_consistency", "verdict": "NEEDS_REVIEW",
            "rationale": "Unknown BasePolicy value: '{}'. Manual review required.".format(base_policy),
            "requires_human_review": True,
        })
    elif fault == "third party" and not coverage.get("covers_third_party"):
        checks.append({
            "check_name": "coverage_consistency", "verdict": "FAIL",
            "rationale": (
                "Fault is 'Third Party' but policy '{}' does not cover third-party claims.".format(base_policy)
            ),
            "requires_human_review": True,
        })
    else:
        checks.append({
            "check_name": "coverage_consistency", "verdict": "PASS",
            "rationale": "Policy '{}' is consistent with fault assignment ({}).".format(
                base_policy, claim.get("Fault", "N/A")),
            "requires_human_review": False,
        })

    # Check 3: Deductible
    if deductible == 0:
        checks.append({
            "check_name": "deductible_applied", "verdict": "NEEDS_REVIEW",
            "rationale": "Deductible is zero or missing. Verify correct deductible was applied.",
            "requires_human_review": True,
        })
    else:
        low, high = coverage.get("deductible_range", (0, 9999)) if coverage else (0, 9999)
        if low <= deductible <= high:
            verdict, rationale = "PASS", "Deductible ${} within expected range ${}-${}.".format(
                deductible, low, high)
            human = False
        else:
            verdict, rationale = "NEEDS_REVIEW", (
                "Deductible ${} outside typical range ${}-${} for {}. Verify schedule.".format(
                    deductible, low, high, base_policy))
            human = True
        checks.append({
            "check_name": "deductible_applied", "verdict": verdict,
            "rationale": rationale, "requires_human_review": human,
        })

    # Check 4: High-value vehicle
    if any(kw in vehicle_price for kw in ("more than 69000", "60000 to 69000")):
        checks.append({
            "check_name": "high_value_vehicle", "verdict": "NEEDS_REVIEW",
            "rationale": "High-value vehicle ({}) requires independent appraisal.".format(
                claim.get("VehiclePrice", "N/A")),
            "requires_human_review": True,
        })
    else:
        checks.append({
            "check_name": "high_value_vehicle", "verdict": "PASS",
            "rationale": "Vehicle price ({}) within standard range.".format(
                claim.get("VehiclePrice", "N/A")),
            "requires_human_review": False,
        })

    # Check 5: Claim reporting timeliness
    if days_claim in {"none", "8 to 15"}:
        checks.append({
            "check_name": "claim_reporting_timeliness", "verdict": "NEEDS_REVIEW",
            "rationale": "Unusual reporting timing (Days_Policy_Claim: {}). Verify compliance.".format(
                claim.get("Days_Policy_Claim", "N/A")),
            "requires_human_review": True,
        })
    else:
        checks.append({
            "check_name": "claim_reporting_timeliness", "verdict": "PASS",
            "rationale": "Reporting timing: {}.".format(claim.get("Days_Policy_Claim", "N/A")),
            "requires_human_review": False,
        })

    logger.debug("validate_policy_compliance: %d checks", len(checks))
    return json.dumps(checks)


@tool
def check_coverage_eligibility(policy_id: str, claim_type: str) -> str:
    """
    Verify that a policy type covers a specific claim scenario.

    Args:
        policy_id:  Policy identifier.
        claim_type: BasePolicy value — Liability, Collision, or All Perils.

    Returns:
        JSON string with eligibility verdict and coverage details.
    """
    coverage = _COVERAGE_MAP.get(claim_type, {})
    if coverage:
        return json.dumps({
            "policy_id": policy_id,
            "claim_type": claim_type,
            "eligible": True,
            "coverage_details": coverage["description"],
            "covers_own_vehicle_damage": coverage["covers_own_vehicle_damage"],
            "covers_third_party": coverage["covers_third_party"],
        })
    return json.dumps({
        "policy_id": policy_id,
        "claim_type": claim_type,
        "eligible": None,
        "coverage_details": "Unknown claim type '{}'. Valid: Liability, Collision, All Perils.".format(claim_type),
    })


@tool
def verify_policy_active(policy_id: str, claim_date: str) -> str:
    """
    Check whether a policy was active on a specific claim date.

    Args:
        policy_id:  Policy identifier.
        claim_date: ISO 8601 date string or descriptive string.

    Returns:
        JSON string with active status and assessment rationale.
    """
    return json.dumps({
        "policy_id": policy_id,
        "claim_date": claim_date,
        "is_active": True,
        "assessment": (
            "Policy assumed active based on claim being processed. "
            "Days_Policy_Accident indicates policy age at accident time. "
            "For hard date verification, connect to a live policy management system."
        ),
    })
