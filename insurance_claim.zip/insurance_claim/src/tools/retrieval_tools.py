"""
Retrieval tools — used by the Claims Retrieval Agent.
Implement the actual vector-store search logic here when data is available.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from langchain_core.tools import tool

logger = logging.getLogger(__name__)


@tool
def retrieve_similar_claims(query: str, top_k: int = 5) -> str:
    """
    Retrieve the most semantically similar historical insurance claims
    for a given natural-language query.

    Args:
        query: Natural-language description of the claim scenario to search for.
        top_k: Number of results to return (default 5).

    Returns:
        JSON string of a list of claim record dicts ordered by relevance.
    """
    from src.vectorstore.store import similarity_search

    docs = similarity_search(query, top_k=top_k)
    claims = [
        {"page_content": doc.page_content, **doc.metadata}
        for doc in docs
    ]
    logger.debug("retrieve_similar_claims returned %d results", len(claims))
    return json.dumps(claims, default=str)


@tool
def filter_claims_by_metadata(
    query: str,
    claim_type: Optional[str] = None,
    status: Optional[str] = None,
    top_k: int = 5,
) -> str:
    """
    Retrieve claims filtered by structured metadata fields (claim_type, status)
    combined with semantic similarity on the query.

    Args:
        query:      Semantic search query.
        claim_type: Filter by claim type, e.g. "AUTO", "HEALTH", "PROPERTY".
        status:     Filter by claim status, e.g. "OPEN", "FRAUD_FLAGGED".
        top_k:      Number of results to return.

    Returns:
        JSON string of matching claim record dicts.
    """
    from src.vectorstore.store import similarity_search

    filter_meta: dict = {}
    if claim_type:
        filter_meta["claim_type"] = claim_type.upper()
    if status:
        filter_meta["status"] = status.upper()

    docs = similarity_search(
        query,
        top_k=top_k,
        filter_metadata=filter_meta if filter_meta else None,
    )
    claims = [
        {"page_content": doc.page_content, **doc.metadata}
        for doc in docs
    ]
    return json.dumps(claims, default=str)
