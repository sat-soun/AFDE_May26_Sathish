"""
Fraud analysis tools — used by the Fraud Analysis Agent.
Signal rules derived from fraud_oracle.csv fields.
"""
from __future__ import annotations
import json
import logging
from typing import Any
from langchain_core.tools import tool

logger = logging.getLogger(__name__)

_EARLY_INCEPTION_VALUES = {"none", "1 to 15", "15 to 30"}
_RECENT_ADDRESS_CHANGE = {"under 6 months", "1 year", "2 to 3 years"}
_HIGH_PAST_CLAIMS = {"2 to 4", "more than 4"}
_HIGH_SUPPLEMENTS = {"3 to 5", "more than 5"}


def _normalise(value: Any) -> str:
    return str(value).strip().lower()


def _detect_signals_for_claim(claim: dict[str, Any]) -> list[dict]:
    signals: list[dict] = []

    def _f(key: str) -> str:
        return _normalise(claim.get(key, ""))

    if _f("PoliceReportFiled") == "no":
        signals.append({
            "signal_type": "no_police_report", "severity": "MEDIUM",
            "description": "No police report was filed, reducing evidentiary support.",
            "field": "PoliceReportFiled", "value": claim.get("PoliceReportFiled", ""),
        })

    if _f("WitnessPresent") == "no":
        signals.append({
            "signal_type": "no_witness", "severity": "LOW",
            "description": "No witness was present at the incident.",
            "field": "WitnessPresent", "value": claim.get("WitnessPresent", ""),
        })

    days_val = _f("Days_Policy_Accident")
    if days_val in _EARLY_INCEPTION_VALUES:
        severity = "HIGH" if days_val == "none" else "MEDIUM"
        signals.append({
            "signal_type": "early_claim", "severity": severity,
            "description": "Claim filed very shortly after policy inception (Days_Policy_Accident: {}).".format(
                claim.get("Days_Policy_Accident", "")),
            "field": "Days_Policy_Accident", "value": claim.get("Days_Policy_Accident", ""),
        })

    addr_val = _f("AddressChange_Claim")
    if addr_val in _RECENT_ADDRESS_CHANGE:
        signals.append({
            "signal_type": "recent_address_change", "severity": "MEDIUM",
            "description": "Policyholder changed address recently before the claim ({}).".format(
                claim.get("AddressChange_Claim", "")),
            "field": "AddressChange_Claim", "value": claim.get("AddressChange_Claim", ""),
        })

    supp_val = _f("NumberOfSuppliments")
    if supp_val in _HIGH_SUPPLEMENTS:
        signals.append({
            "signal_type": "high_supplement_count", "severity": "HIGH",
            "description": "Unusually high supplements ({}) — possible claim inflation.".format(
                claim.get("NumberOfSuppliments", "")),
            "field": "NumberOfSuppliments", "value": claim.get("NumberOfSuppliments", ""),
        })

    past_val = _f("PastNumberOfClaims")
    if past_val in _HIGH_PAST_CLAIMS:
        signals.append({
            "signal_type": "repeat_claimant", "severity": "MEDIUM",
            "description": "Claimant has multiple prior claims ({}).".format(
                claim.get("PastNumberOfClaims", "")),
            "field": "PastNumberOfClaims", "value": claim.get("PastNumberOfClaims", ""),
        })

    try:
        driver_rating = int(str(claim.get("DriverRating", 0)).strip())
        if driver_rating >= 4:
            signals.append({
                "signal_type": "low_driver_rating", "severity": "LOW",
                "description": "Driver rating is {} (scale 1-4, higher = worse).".format(driver_rating),
                "field": "DriverRating", "value": str(driver_rating),
            })
    except (ValueError, TypeError):
        pass

    if _f("Fault") == "policy holder" and _f("PoliceReportFiled") == "no":
        signals.append({
            "signal_type": "fault_no_report", "severity": "HIGH",
            "description": "Policy holder at fault but no police report filed — high-risk combination.",
            "field": "Fault+PoliceReportFiled",
            "value": "Fault={}, PoliceReportFiled={}".format(
                claim.get("Fault", ""), claim.get("PoliceReportFiled", "")),
        })

    if _f("FraudFound_P") == "1":
        signals.append({
            "signal_type": "historical_fraud_label", "severity": "CRITICAL",
            "description": "This record was previously labelled as fraudulent in the dataset.",
            "field": "FraudFound_P", "value": "1",
        })

    return signals


@tool
def detect_fraud_patterns(claims_json: str) -> str:
    """
    Analyse a list of claim records for known fraud patterns and signals.

    Checks: no police report, no witness, early inception claim, recent address
    change, high supplement count, repeat claimant, low driver rating,
    fault without police report, historical fraud label.

    Args:
        claims_json: JSON string of claim record dicts (from retrieve_similar_claims).

    Returns:
        JSON string of detected FraudSignal objects.
    """
    try:
        claims: list[dict[str, Any]] = json.loads(claims_json)
        if not isinstance(claims, list):
            claims = [claims]
    except json.JSONDecodeError:
        return json.dumps({"error": "Invalid claims JSON"})

    all_signals: list[dict] = []
    for claim in claims:
        claim_signals = _detect_signals_for_claim(claim)
        claim_id = (
            claim.get("PolicyNumber")
            or claim.get("claim_id")
            or str(claim.get("row_index", "unknown"))
        )
        for sig in claim_signals:
            sig["claim_id"] = claim_id
        all_signals.extend(claim_signals)

    logger.debug("detect_fraud_patterns: %d signals across %d claims", len(all_signals), len(claims))
    return json.dumps(all_signals, default=str)


@tool
def check_duplicate_claims(claimant_id: str, window_days: int = 90) -> str:
    """
    Check whether a claimant has filed multiple claims within a given window.

    Args:
        claimant_id: The claimant's unique identifier.
        window_days: Look-back window in days (default 90).

    Returns:
        JSON string with duplicate flag and related claim IDs.
    """
    result = {
        "claimant_id": claimant_id,
        "window_days": window_days,
        "duplicate_found": False,
        "related_claim_ids": [],
        "note": (
            "Duplicate check based on PastNumberOfClaims field from the claim record. "
            "For real-time cross-database checks, connect to a live claims DB."
        ),
    }
    return json.dumps(result)


@tool
def analyse_claimant_history(claimant_id: str) -> str:
    """
    Summarise a claimant's historical claim record.

    Args:
        claimant_id: The claimant's unique identifier.

    Returns:
        JSON string of claimant history summary.
    """
    result = {
        "claimant_id": claimant_id,
        "note": (
            "Claimant history is encoded in the PastNumberOfClaims field. "
            "High values ('2 to 4', 'more than 4') are flagged as repeat_claimant "
            "signals by detect_fraud_patterns."
        ),
        "recommendation": (
            "Use detect_fraud_patterns on retrieved claims for a complete assessment."
        ),
    }
    return json.dumps(result)
