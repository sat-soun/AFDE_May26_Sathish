"""
Risk scoring tools — used by the Risk Scoring Agent.
"""

from __future__ import annotations

import json
import logging

from langchain_core.tools import tool

from config.settings import get_settings

logger = logging.getLogger(__name__)


@tool
def compute_risk_score(
    claim_id: str,
    fraud_signals_json: str,
    policy_verdict: str,
    prior_claims_count: int = 0,
    claimed_amount: float = 0.0,
    avg_claimed_amount: float = 0.0,
) -> str:
    """
    Compute a fraud probability score and risk tier for a claim.

    Scoring formula (weighted sum, normalised to [0, 1]):
      - fraud_signal_score   : 0.40 weight — derived from signal count & severity
      - policy_gap_score     : 0.30 weight — based on compliance verdict
      - anomaly_score        : 0.20 weight — claimed_amount vs. average
      - claimant_history     : 0.10 weight — prior claims count

    Args:
        claim_id:            Claim identifier.
        fraud_signals_json:  JSON list of FraudSignal dicts from fraud_tools.
        policy_verdict:      "PASS", "FAIL", or "NEEDS_REVIEW".
        prior_claims_count:  Number of prior claims by this claimant.
        claimed_amount:      The amount claimed in this incident.
        avg_claimed_amount:  Average claimed amount for this claim type.

    Returns:
        JSON RiskScore dict.
    """
    settings = get_settings()

    try:
        signals = json.loads(fraud_signals_json) if fraud_signals_json else []
    except json.JSONDecodeError:
        signals = []

    # ── Component scores ──────────────────────────────────────────────────

    # Fraud signal score
    severity_weights = {"LOW": 0.2, "MEDIUM": 0.5, "HIGH": 1.0}
    signal_score = min(
        sum(severity_weights.get(s.get("severity", "LOW"), 0.2) for s in signals) / max(len(signals), 1),
        1.0,
    ) if signals else 0.0

    # Policy compliance score
    policy_score_map = {"FAIL": 1.0, "NEEDS_REVIEW": 0.5, "PASS": 0.0}
    policy_score = policy_score_map.get(policy_verdict.upper(), 0.5)

    # Anomaly score (amount deviation)
    if avg_claimed_amount > 0:
        ratio = claimed_amount / avg_claimed_amount
        anomaly_score = min((ratio - 1.0) / 3.0, 1.0) if ratio > 1.0 else 0.0
    else:
        anomaly_score = 0.0

    # Claimant history score
    history_score = min(prior_claims_count / 10.0, 1.0)

    # ── Weighted aggregation ──────────────────────────────────────────────
    fraud_probability = round(
        0.40 * signal_score
        + 0.30 * policy_score
        + 0.20 * anomaly_score
        + 0.10 * history_score,
        4,
    )

    # ── Tier classification ───────────────────────────────────────────────
    if fraud_probability >= settings.fraud_high_risk_threshold:
        risk_tier = "HIGH" if len(signals) < 2 else "CRITICAL"
    elif fraud_probability >= settings.fraud_medium_risk_threshold:
        risk_tier = "MEDIUM"
    else:
        risk_tier = "LOW"

    investigation_priority = max(1, round(fraud_probability * 10))

    rationale = (
        f"Signal score: {signal_score:.2f} (×0.40) | "
        f"Policy score: {policy_score:.2f} (×0.30) | "
        f"Anomaly score: {anomaly_score:.2f} (×0.20) | "
        f"History score: {history_score:.2f} (×0.10) "
        f"→ fraud_probability={fraud_probability:.4f}"
    )

    result = {
        "claim_id": claim_id,
        "fraud_probability": fraud_probability,
        "risk_tier": risk_tier,
        "investigation_priority": investigation_priority,
        "score_rationale": rationale,
        "recommended_actions": _get_recommended_actions(risk_tier),
    }

    logger.info("Risk score for %s: %s (prob=%.4f)", claim_id, risk_tier, fraud_probability)
    return json.dumps(result)


@tool
def generate_investigation_recommendations(risk_tier: str, signals_json: str) -> str:
    """
    Generate a prioritised list of investigation actions based on risk tier
    and detected fraud signals.

    Args:
        risk_tier:    "LOW", "MEDIUM", "HIGH", or "CRITICAL".
        signals_json: JSON list of FraudSignal dicts.

    Returns:
        JSON list of recommended investigation action strings.
    """
    try:
        signals = json.loads(signals_json) if signals_json else []
    except json.JSONDecodeError:
        signals = []

    actions = _get_recommended_actions(risk_tier)

    # Signal-specific actions
    signal_types = {s.get("signal_type", "") for s in signals}
    if "duplicate_claim" in signal_types:
        actions.append("Cross-check for duplicate claim submissions across all policy systems.")
    if "high_value_anomaly" in signal_types:
        actions.append("Request independent appraisal or itemised repair/medical invoice.")
    if "early_claim" in signal_types:
        actions.append("Review policy inception circumstances and underwriting notes.")
    if "late_reporting" in signal_types:
        actions.append("Interview claimant about reporting delay; request timeline documentation.")

    return json.dumps(list(dict.fromkeys(actions)))  # deduplicate preserving order


# ── Private helpers ───────────────────────────────────────────────────────────

def _get_recommended_actions(risk_tier: str) -> list[str]:
    base: dict[str, list[str]] = {
        "LOW": ["Proceed with standard claim processing."],
        "MEDIUM": [
            "Request additional supporting documentation.",
            "Assign to experienced adjuster for secondary review.",
        ],
        "HIGH": [
            "Escalate to Special Investigations Unit (SIU).",
            "Place claim on hold pending fraud investigation.",
            "Notify compliance team.",
        ],
        "CRITICAL": [
            "Immediately refer to SIU.",
            "Suspend all payments on associated claims.",
            "Initiate formal fraud investigation protocol.",
            "Preserve all evidence and audit logs.",
            "Consider law enforcement referral if warranted.",
        ],
    }
    return list(base.get(risk_tier.upper(), base["LOW"]))
