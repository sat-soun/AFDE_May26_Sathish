"""
LangGraph graph assembly.

Graph topology
──────────────
                         ┌──────────────────────────────────────────┐
                         │                                          │
  START ──► supervisor ──┼──► claims_retrieval ──► supervisor       │
                         ├──► fraud_analysis   ──► supervisor       │
                         ├──► policy_validation──► supervisor       │
                         ├──► risk_scoring     ──► supervisor       │
                         └──► finalize ──► END                      │
                                                                     │
  (supervisor loops until it emits "FINISH", then routes to finalize)
"""

from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from config.settings import get_settings
from src.graph.edges import route_after_finalize, route_from_supervisor
from src.graph.nodes import (
    claims_retrieval_node,
    finalize_node,
    fraud_analysis_node,
    policy_validation_node,
    risk_scoring_node,
    supervisor_node,
)
from src.graph.state import InsuranceClaimState


def build_graph() -> StateGraph:
    """
    Assemble and compile the insurance claims multi-agent graph.

    Returns:
        A compiled LangGraph CompiledGraph ready for ``.invoke()`` /
        ``.stream()`` calls.
    """
    settings = get_settings()

    graph = StateGraph(InsuranceClaimState)

    # ── Register nodes ────────────────────────────────────────────────────
    graph.add_node("supervisor",         supervisor_node)
    graph.add_node("claims_retrieval",   claims_retrieval_node)
    graph.add_node("fraud_analysis",     fraud_analysis_node)
    graph.add_node("policy_validation",  policy_validation_node)
    graph.add_node("risk_scoring",       risk_scoring_node)
    graph.add_node("finalize",           finalize_node)

    # ── Entry point ───────────────────────────────────────────────────────
    graph.add_edge(START, "supervisor")

    # ── Supervisor conditional routing ────────────────────────────────────
    graph.add_conditional_edges(
        "supervisor",
        route_from_supervisor,
        {
            "claims_retrieval":  "claims_retrieval",
            "fraud_analysis":    "fraud_analysis",
            "policy_validation": "policy_validation",
            "risk_scoring":      "risk_scoring",
            "finalize":          "finalize",
        },
    )

    # ── Specialist agents always return to supervisor ─────────────────────
    for agent_node in (
        "claims_retrieval",
        "fraud_analysis",
        "policy_validation",
        "risk_scoring",
    ):
        graph.add_edge(agent_node, "supervisor")

    # ── Terminal edge ─────────────────────────────────────────────────────
    graph.add_conditional_edges("finalize", route_after_finalize, {END: END})

    return graph.compile(
        # Uncomment to add a memory checkpointer for multi-turn conversations:
        # checkpointer=MemorySaver(),
    )


# Module-level singleton (compiled once, reused across requests)
_compiled_graph = None


def get_graph():
    """Return the cached compiled graph (build once, reuse many times)."""
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_graph()
    return _compiled_graph
