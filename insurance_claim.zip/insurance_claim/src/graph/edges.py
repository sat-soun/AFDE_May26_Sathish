"""
Conditional edge functions for LangGraph routing.

Each function receives the current state and returns a string that maps to
a graph node name (or END).
"""

from __future__ import annotations

from langgraph.graph import END

from src.graph.state import InsuranceClaimState

# Map supervisor routing labels to actual graph node names
AGENT_ROUTE_MAP: dict[str, str] = {
    "claims_retrieval":  "claims_retrieval",
    "fraud_analysis":    "fraud_analysis",
    "policy_validation": "policy_validation",
    "risk_scoring":      "risk_scoring",
    "FINISH":            "finalize",
}


def route_from_supervisor(state: InsuranceClaimState) -> str:
    """
    Reads ``state["next_agent"]`` set by the supervisor node and returns the
    corresponding node name.  Falls back to "finalize" for unknown targets.
    """
    next_agent = state.get("next_agent", "FINISH")
    destination = AGENT_ROUTE_MAP.get(next_agent, "finalize")
    return destination


def route_after_finalize(_state: InsuranceClaimState) -> str:
    """Always terminates the graph after the finalize node."""
    return END
