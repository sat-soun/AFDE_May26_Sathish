"""
LangGraph node functions — one per agent.

Each node:
  1. Receives the current InsuranceClaimState
  2. Invokes its agent
  3. Returns a partial state update dict

Nodes never mutate state directly; they return only the keys they modify.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import AIMessage

from src.graph.state import InsuranceClaimState

logger = logging.getLogger(__name__)


# ── Import agents lazily to avoid circular imports ────────────────────────────

def _get_supervisor():
    from src.agents.supervisor import SupervisorAgent
    return SupervisorAgent()

def _get_claims_retrieval():
    from src.agents.claims_retrieval import ClaimsRetrievalAgent
    return ClaimsRetrievalAgent()

def _get_fraud_analysis():
    from src.agents.fraud_analysis import FraudAnalysisAgent
    return FraudAnalysisAgent()

def _get_policy_validation():
    from src.agents.policy_validation import PolicyValidationAgent
    return PolicyValidationAgent()

def _get_risk_scoring():
    from src.agents.risk_scoring import RiskScoringAgent
    return RiskScoringAgent()


# ── Node implementations ──────────────────────────────────────────────────────

def supervisor_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Orchestrator node — decides which agent to call next.
    Returns: {"next_agent": "<agent_name>", "messages": [...]}
    """
    logger.debug("supervisor_node invoked")
    agent = _get_supervisor()
    result = agent.run(state)
    return {
        "next_agent": result.data.get("next", "FINISH"),
        "messages": [AIMessage(content=str(result.data), name="supervisor")],
        "agent_outputs": [result.model_dump()],
    }


def claims_retrieval_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Claims Retrieval node — performs semantic search and returns matching claims.
    """
    logger.debug("claims_retrieval_node invoked")
    agent = _get_claims_retrieval()
    result = agent.run(state)
    return {
        "retrieved_claims": result.data.get("claims", []),
        "messages": [AIMessage(content=str(result.data), name="claims_retrieval")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def fraud_analysis_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Fraud Analysis node — detects fraud signals across retrieved claims.
    """
    logger.debug("fraud_analysis_node invoked")
    agent = _get_fraud_analysis()
    result = agent.run(state)
    return {
        "fraud_result": result.data.get("fraud_analysis"),
        "messages": [AIMessage(content=str(result.data), name="fraud_analysis")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def policy_validation_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Policy Validation node — checks compliance and coverage conditions.
    """
    logger.debug("policy_validation_node invoked")
    agent = _get_policy_validation()
    result = agent.run(state)
    return {
        "policy_result": result.data.get("policy_validation"),
        "messages": [AIMessage(content=str(result.data), name="policy_validation")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def risk_scoring_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Risk Scoring node — synthesises outputs into a fraud probability score.
    """
    logger.debug("risk_scoring_node invoked")
    agent = _get_risk_scoring()
    result = agent.run(state)
    return {
        "risk_score": result.data.get("risk_score"),
        "messages": [AIMessage(content=str(result.data), name="risk_scoring")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def finalize_node(state: InsuranceClaimState) -> dict[str, Any]:
    """
    Terminal node — assembles the final user-facing answer from all
    agent outputs collected in state.
    """
    logger.debug("finalize_node invoked")

    sections: list[str] = []

    if state.get("retrieved_claims"):
        sections.append(
            f"**Retrieved Claims:** {len(state['retrieved_claims'])} matching records found."
        )

    if state.get("fraud_result"):
        fr = state["fraud_result"]
        sections.append(
            f"**Fraud Analysis:** {fr.get('total_signals', 0)} signal(s) detected. "
            f"Highest severity: {fr.get('highest_severity', 'N/A')}. "
            f"{fr.get('analysis_summary', '')}"
        )

    if state.get("policy_result"):
        pr = state["policy_result"]
        sections.append(
            f"**Policy Validation:** Overall verdict — {pr.get('overall_verdict', 'N/A')}. "
            f"{pr.get('summary', '')}"
        )

    if state.get("risk_score"):
        rs = state["risk_score"]
        sections.append(
            f"**Risk Score:** Fraud probability {rs.get('fraud_probability', 0):.2%}, "
            f"Tier: {rs.get('risk_tier', 'N/A')}, "
            f"Investigation priority: {rs.get('investigation_priority', 'N/A')}/10.\n"
            f"Rationale: {rs.get('score_rationale', '')}\n"
            f"Recommended actions: {', '.join(rs.get('recommended_actions', []))}"
        )

    final_answer = "\n\n".join(sections) if sections else "No analysis results available."

    return {
        "final_answer": final_answer,
        "messages": [AIMessage(content=final_answer, name="system")],
    }
