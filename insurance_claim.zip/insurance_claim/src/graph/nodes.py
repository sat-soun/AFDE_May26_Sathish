"""
LangGraph node functions — one per agent.

Each node receives the current InsuranceClaimState, invokes its agent,
and returns a partial state update dict.
"""
from __future__ import annotations
import logging
from typing import Any
from langchain_core.messages import AIMessage
from src.graph.state import InsuranceClaimState

logger = logging.getLogger(__name__)


def _get_supervisor():
    from src.agents.supervisor import SupervisorAgent
    return SupervisorAgent()

def _get_claims_retrieval():
    from src.agents.claims_retrieval import ClaimsRetrievalAgent
    return ClaimsRetrievalAgent()

def _get_fraud_analysis():
    from src.agents.fraud_analysis import FraudAnalysisAgent
    return FraudAnalysisAgent()

def _get_policy_validation():
    from src.agents.policy_validation import PolicyValidationAgent
    return PolicyValidationAgent()

def _get_risk_scoring():
    from src.agents.risk_scoring import RiskScoringAgent
    return RiskScoringAgent()


def supervisor_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("supervisor_node invoked")
    agent = _get_supervisor()
    result = agent.run(state)
    return {
        "next_agent": result.data.get("next", "FINISH"),
        "messages": [AIMessage(content=str(result.data), name="supervisor")],
        "agent_outputs": [result.model_dump()],
    }


def claims_retrieval_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("claims_retrieval_node invoked")
    agent = _get_claims_retrieval()
    result = agent.run(state)

    error_msg = result.error
    if error_msg and "vector store not found" in str(error_msg).lower():
        error_msg = (
            "Vector store has not been ingested yet. "
            "Run: python -m src.ingestion.pipeline  OR  POST /api/ingest"
        )

    return {
        "retrieved_claims": result.data.get("claims", []),
        "messages": [AIMessage(content=str(result.data), name="claims_retrieval")],
        "agent_outputs": [result.model_dump()],
        "error": error_msg,
    }


def fraud_analysis_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("fraud_analysis_node invoked")
    agent = _get_fraud_analysis()
    result = agent.run(state)
    return {
        "fraud_result": result.data.get("fraud_analysis"),
        "messages": [AIMessage(content=str(result.data), name="fraud_analysis")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def policy_validation_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("policy_validation_node invoked")
    agent = _get_policy_validation()
    result = agent.run(state)
    return {
        "policy_result": result.data.get("policy_validation"),
        "messages": [AIMessage(content=str(result.data), name="policy_validation")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def risk_scoring_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("risk_scoring_node invoked")
    agent = _get_risk_scoring()
    result = agent.run(state)
    return {
        "risk_score": result.data.get("risk_score"),
        "messages": [AIMessage(content=str(result.data), name="risk_scoring")],
        "agent_outputs": [result.model_dump()],
        "error": result.error,
    }


def finalize_node(state: InsuranceClaimState) -> dict[str, Any]:
    logger.debug("finalize_node invoked")

    pipeline_error = state.get("error")
    retrieved_claims = state.get("retrieved_claims") or []

    # Surface vectorstore / retrieval errors clearly
    if pipeline_error and not retrieved_claims:
        err_lower = str(pipeline_error).lower()
        if "not been ingested" in err_lower or "vector store" in err_lower or "not found" in err_lower:
            final_answer = (
                "Setup required: the vector store has not been ingested yet.\n\n"
                "The claims database is empty. Populate it by running:\n\n"
                "    python -m src.ingestion.pipeline\n\n"
                "Or call the ingestion API:  POST /api/ingest\n\n"
                "Once complete, retry your query."
            )
        else:
            final_answer = (
                "An error occurred during claims retrieval:\n\n"
                + str(pipeline_error)
                + "\n\nCheck the server logs for details."
            )
        return {
            "final_answer": final_answer,
            "messages": [AIMessage(content=final_answer, name="system")],
        }

    sections: list[str] = []

    if retrieved_claims:
        count = len(retrieved_claims)
        sections.append(
            "**Retrieved Claims:** {} matching record{} found.".format(
                count, "s" if count != 1 else "")
        )

    if state.get("fraud_result"):
        fr = state["fraud_result"]
        n_signals = fr.get("total_signals", 0)
        sev = fr.get("highest_severity") or "none"
        summary = fr.get("analysis_summary", "")
        signals = fr.get("signals", [])
        signal_lines = [
            "  - [{}] {}: {}".format(
                s.get("severity", "?"), s.get("signal_type", "?"), s.get("description", ""))
            for s in signals[:6]
        ]
        signal_detail = ("\n" + "\n".join(signal_lines)) if signal_lines else ""
        sections.append(
            "**Fraud Analysis:** {} signal(s) detected. Highest severity: {}.{}\n{}".format(
                n_signals, sev, signal_detail, summary)
        )

    if state.get("policy_result"):
        pr = state["policy_result"]
        verdict = pr.get("overall_verdict", "N/A")
        summary = pr.get("summary", "")
        checks = pr.get("checks", [])
        check_lines = [
            "  - {}: {} - {}".format(
                c.get("check_name", "?"), c.get("verdict", "?"), c.get("rationale", ""))
            for c in checks
        ]
        check_detail = ("\n" + "\n".join(check_lines)) if check_lines else ""
        sections.append(
            "**Policy Validation:** Overall verdict - {}.{}\n{}".format(
                verdict, check_detail, summary)
        )

    if state.get("risk_score"):
        rs = state["risk_score"]
        prob = rs.get("fraud_probability", 0)
        tier = rs.get("risk_tier", "N/A")
        priority = rs.get("investigation_priority", "N/A")
        rationale = rs.get("score_rationale", "")
        actions = rs.get("recommended_actions", [])
        action_str = (
            "\n" + "\n".join("  {}. {}".format(i + 1, a) for i, a in enumerate(actions))
        ) if actions else ""
        sections.append(
            "**Risk Score:** Fraud probability {:.2%}, Tier: {}, Priority: {}/10.\n"
            "Rationale: {}\n"
            "Recommended actions:{}".format(prob, tier, priority, rationale, action_str)
        )

    if sections:
        final_answer = "\n\n".join(sections)
    elif pipeline_error:
        final_answer = "Pipeline completed with errors:\n\n" + str(pipeline_error)
    else:
        final_answer = (
            "No analysis results available for your query. Possible reasons:\n"
            "1. Vector store not ingested - run: python -m src.ingestion.pipeline\n"
            "2. No matching claims found for this query\n"
            "3. Query is out of scope for the insurance claims system\n\n"
            "Try rephrasing your query or check that ingestion has been run."
        )

    return {
        "final_answer": final_answer,
        "messages": [AIMessage(content=final_answer, name="system")],
    }
