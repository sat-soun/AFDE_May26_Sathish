"""
LangGraph shared state definition.

All agent nodes read from and write to this single TypedDict.
Using Annotated[list, operator.add] ensures message lists are appended
(not overwritten) when multiple nodes run.
"""

from __future__ import annotations

import operator
from typing import Annotated, Any, Optional

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class InsuranceClaimState(TypedDict):
    """
    Central state object flowing through the LangGraph.

    Fields
    ──────
    messages        : Full conversation history (HumanMessage, AIMessage, ToolMessage).
    query           : The original user query (unchanged throughout the run).
    next_agent      : Supervisor's routing decision; one of the agent names or "FINISH".
    retrieved_claims: Raw documents returned by the Claims Retrieval agent.
    fraud_result    : Serialised FraudAnalysisResult dict from the Fraud Analysis agent.
    policy_result   : Serialised PolicyValidationResult dict from the Policy Validation agent.
    risk_score      : Serialised RiskScore dict from the Risk Scoring agent.
    agent_outputs   : Accumulates every agent's AgentResponse for audit / eval.
    final_answer    : The assembled, user-facing answer produced after FINISH.
    error           : Set by any node that encounters an unrecoverable error.
    """

    messages: Annotated[list[BaseMessage], add_messages]
    query: str
    next_agent: str                            # routing target
    retrieved_claims: list[dict[str, Any]]     # list of claim metadata dicts
    fraud_result: Optional[dict[str, Any]]
    policy_result: Optional[dict[str, Any]]
    risk_score: Optional[dict[str, Any]]
    agent_outputs: Annotated[list[dict[str, Any]], operator.add]
    final_answer: Optional[str]
    error: Optional[str]
