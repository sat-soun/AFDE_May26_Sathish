"""
Vector store abstraction layer.
Wraps Chroma and exposes a clean retriever interface used by agent tools.
"""

from __future__ import annotations

import logging
from typing import Optional

from langchain_core.documents import Document
from langchain_core.vectorstores import VectorStoreRetriever

from config.settings import get_settings
from src.ingestion.embedder import load_vectorstore

logger = logging.getLogger(__name__)

_vectorstore_singleton = None


def get_retriever(
    top_k: Optional[int] = None,
    filter_metadata: Optional[dict] = None,
) -> VectorStoreRetriever:
    """
    Return a configured retriever backed by the persisted Chroma store.

    Args:
        top_k:            Number of results to return (falls back to settings).
        filter_metadata:  Optional Chroma metadata filter dict, e.g.
                          {"claim_type": "AUTO"}.

    Returns:
        LangChain VectorStoreRetriever instance.
    """
    global _vectorstore_singleton

    settings = get_settings()
    _top_k = top_k or settings.retrieval_top_k

    if _vectorstore_singleton is None:
        _vectorstore_singleton = load_vectorstore()

    search_kwargs: dict = {"k": _top_k}
    if filter_metadata:
        search_kwargs["filter"] = filter_metadata

    return _vectorstore_singleton.as_retriever(search_kwargs=search_kwargs)


def similarity_search(
    query: str,
    top_k: Optional[int] = None,
    filter_metadata: Optional[dict] = None,
) -> list[Document]:
    """
    Perform a direct similarity search without going through LangChain's
    retriever interface — useful for tool implementations.

    Args:
        query:           Natural-language search query.
        top_k:           Max results.
        filter_metadata: Optional Chroma metadata filter.

    Returns:
        List of matching Documents ordered by relevance.
    """
    global _vectorstore_singleton

    settings = get_settings()
    _top_k = top_k or settings.retrieval_top_k

    if _vectorstore_singleton is None:
        _vectorstore_singleton = load_vectorstore()

    kwargs: dict = {}
    if filter_metadata:
        kwargs["filter"] = filter_metadata

    results = _vectorstore_singleton.similarity_search_with_score(
        query, k=_top_k, **kwargs
    )

    docs = [doc for doc, _score in results]
    logger.debug("similarity_search returned %d results for query: %s", len(docs), query[:80])
    return docs
