"""
DeepEval-based evaluation for the insurance claims pipeline.

Metrics evaluated
──────────────────
Standard DeepEval metrics (all respect the project's LLM settings):
  AnswerRelevancyMetric       – Does the answer address the question?
  FaithfulnessMetric          – Is the answer grounded in retrieved context?
  ContextualPrecisionMetric   – Are the most relevant claims ranked first?
  ContextualRecallMetric      – Do retrieved claims cover the expected answer?
  HallucinationMetric         – Does the answer introduce facts not in context?

Custom G-Eval metrics (insurance-domain-specific):
  FraudDetectionAccuracy      – Does the fraud analysis match expected outcome?
  RiskTierAccuracy            – Is the risk tier correctly assigned?

Usage
──────
    from src.evaluation.deepeval_eval import DeepEvalEvaluator
    evaluator = DeepEvalEvaluator()

    tc = LLMTestCase(input="...", actual_output="...", retrieval_context=[...])
    result = evaluator.evaluate([tc])

    # Or drive from golden dataset + live pipeline:
    result = evaluator.evaluate_pipeline()
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ── Project LLM adapter for DeepEval ─────────────────────────────────────────

def _build_deepeval_model():
    """
    Return a DeepEvalBaseLLM implementation backed by the project's LLM settings.
    DeepEval uses this for all its internal LLM calls (metric scoring, G-Eval, etc.).
    """
    try:
        from deepeval.models import DeepEvalBaseLLM
        from langchain_openai import ChatOpenAI
        from config.settings import get_settings
    except ImportError as e:
        raise ImportError("Run: pip install deepeval") from e

    settings = get_settings()

    class ProjectLLM(DeepEvalBaseLLM):
        """Thin wrapper that routes DeepEval calls through the project LLM."""

        def __init__(self):
            self._model_name = settings.llm_model
            self._chat = ChatOpenAI(
                model=settings.llm_model,
                api_key=settings.llm_api_key,
                base_url=settings.llm_base_url,
                temperature=0.0,
            )

        def load_model(self):
            return self._chat

        def generate(self, prompt: str, **kwargs) -> str:
            from langchain_core.messages import HumanMessage
            response = self._chat.invoke([HumanMessage(content=prompt)])
            return response.content

        async def a_generate(self, prompt: str, **kwargs) -> str:
            from langchain_core.messages import HumanMessage
            response = await self._chat.ainvoke([HumanMessage(content=prompt)])
            return response.content

        def get_model_name(self) -> str:
            return self._model_name

    return ProjectLLM()


# ── Custom G-Eval metrics ──────────────────────────────────────────────────────

def _fraud_detection_accuracy_metric(model) -> Any:
    """
    G-Eval metric: does the pipeline's fraud analysis match the expected outcome?
    Scores 1.0 if the answer correctly identifies (or correctly clears) fraud,
    0.0 if it contradicts the ground truth.
    """
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCaseParams

    return GEval(
        name="Fraud Detection Accuracy",
        model=model,
        evaluation_steps=[
            "Read the 'Input' (user query) and 'Expected Output' (ground truth describing expected fraud signals and risk tier).",
            "Read the 'Actual Output' (the pipeline's final answer).",
            "Check whether the actual output correctly identifies or clears the fraud signals mentioned in the expected output.",
            "Check whether the risk tier in the actual output matches or is consistent with the expected tier.",
            "Score 1.0 for a fully accurate fraud assessment, 0.5 for a partially correct one, and 0.0 for an incorrect or missing assessment.",
        ],
        evaluation_params=[
            LLMTestCaseParams.INPUT,
            LLMTestCaseParams.ACTUAL_OUTPUT,
            LLMTestCaseParams.EXPECTED_OUTPUT,
        ],
        threshold=0.5,
    )


def _risk_tier_accuracy_metric(model) -> Any:
    """
    G-Eval metric: is the risk tier assigned by the pipeline consistent with
    the expected tier and the overall fraud signals?
    """
    from deepeval.metrics import GEval
    from deepeval.test_case import LLMTestCaseParams

    return GEval(
        name="Risk Tier Accuracy",
        model=model,
        evaluation_steps=[
            "Identify the risk tier stated in the 'Actual Output' (look for LOW, MEDIUM, HIGH, CRITICAL).",
            "Identify the expected risk tier in the 'Expected Output'.",
            "Score 1.0 if the tiers match exactly.",
            "Score 0.5 if the tiers are adjacent (e.g., MEDIUM vs HIGH).",
            "Score 0.0 if the tiers are more than one level apart (e.g., LOW vs HIGH).",
        ],
        evaluation_params=[
            LLMTestCaseParams.ACTUAL_OUTPUT,
            LLMTestCaseParams.EXPECTED_OUTPUT,
        ],
        threshold=0.5,
    )


# ── Evaluator ──────────────────────────────────────────────────────────────────

class DeepEvalEvaluator:
    """
    Wraps the DeepEval library with project LLM settings.
    All standard and custom metrics share the same ProjectLLM instance.
    """

    def __init__(self) -> None:
        self._model = None

    def _get_model(self):
        if self._model is None:
            self._model = _build_deepeval_model()
        return self._model

    def _default_metrics(self) -> list:
        """Build the default metric set using the project LLM."""
        try:
            from deepeval.metrics import (
                AnswerRelevancyMetric,
                FaithfulnessMetric,
                ContextualPrecisionMetric,
                ContextualRecallMetric,
                HallucinationMetric,
            )
        except ImportError as e:
            raise ImportError("Run: pip install deepeval") from e

        model = self._get_model()
        return [
            AnswerRelevancyMetric(    threshold=0.5, model=model, include_reason=True),
            FaithfulnessMetric(       threshold=0.5, model=model, include_reason=True),
            ContextualPrecisionMetric(threshold=0.5, model=model, include_reason=True),
            ContextualRecallMetric(   threshold=0.5, model=model, include_reason=True),
            HallucinationMetric(      threshold=0.5, model=model, include_reason=True),
            _fraud_detection_accuracy_metric(model),
            _risk_tier_accuracy_metric(model),
        ]

    # ── Build a test case ──────────────────────────────────────────────────────

    @staticmethod
    def build_test_case(
        question:          str,
        answer:            str,
        expected_output:   str,
        retrieval_context: list[str],
        test_case_id:      str = "",
    ):
        """Return a DeepEval LLMTestCase."""
        from deepeval.test_case import LLMTestCase
        return LLMTestCase(
            input             = question,
            actual_output     = answer,
            expected_output   = expected_output,
            retrieval_context = retrieval_context,
            name              = test_case_id or question[:60],
        )

    # ── Evaluate a pre-built list of test cases ────────────────────────────────

    def evaluate(
        self,
        test_cases: list,
        metrics:    Optional[list] = None,
        run_async:  bool = False,
    ) -> dict[str, Any]:
        """
        Run DeepEval metrics over a list of LLMTestCase objects.

        Args:
            test_cases: DeepEval LLMTestCase instances.
            metrics:    Metric instances. Defaults to the full default set.
            run_async:  Whether to use DeepEval's async evaluation mode.

        Returns:
            Evaluation report dict with per-metric and per-sample results.
        """
        try:
            from deepeval import evaluate as deepeval_evaluate
        except ImportError as e:
            raise ImportError("Run: pip install deepeval") from e

        if not test_cases:
            return {"error": "No test cases provided"}

        _metrics = metrics or self._default_metrics()

        logger.info(
            "Running DeepEval on %d test case(s) with %d metric(s) …",
            len(test_cases), len(_metrics),
        )

        eval_result = deepeval_evaluate(
            test_cases = test_cases,
            metrics    = _metrics,
            run_async  = run_async,
        )

        # Serialise into a plain dict
        report: dict[str, Any] = {
            "framework":    "deepeval",
            "sample_count": len(test_cases),
            "per_sample":   [],
        }

        metric_totals: dict[str, list[float]] = {}

        for tc_result in eval_result.test_results:
            sample_scores: dict[str, Any] = {"name": tc_result.name, "metrics": {}}
            for metric_data in tc_result.metrics_data:
                name    = metric_data.name
                score   = metric_data.score
                success = metric_data.success
                reason  = getattr(metric_data, "reason", None)
                sample_scores["metrics"][name] = {
                    "score":   round(score, 4) if score is not None else None,
                    "passed":  success,
                    "reason":  reason,
                }
                metric_totals.setdefault(name, [])
                if score is not None:
                    metric_totals[name].append(score)

            report["per_sample"].append(sample_scores)

        report["aggregate_scores"] = {
            name: round(sum(vals) / len(vals), 4)
            for name, vals in metric_totals.items()
            if vals
        }

        return report

    # ── Run live pipeline then evaluate ───────────────────────────────────────

    def evaluate_pipeline(
        self,
        test_cases: Optional[list] = None,
        metrics:    Optional[list] = None,
    ) -> dict[str, Any]:
        """
        Run each EvalTestCase through the live LangGraph pipeline, collect
        outputs, then evaluate with DeepEval.

        Args:
            test_cases: EvalTestCase list. Defaults to GOLDEN_DATASET.
            metrics:    DeepEval metric instances. Defaults to full default set.

        Returns:
            Combined evaluation report dict.
        """
        from langchain_core.messages import HumanMessage
        from src.graph.builder import get_graph
        from src.evaluation.test_cases import GOLDEN_DATASET

        cases = test_cases or GOLDEN_DATASET
        graph = get_graph()

        deepeval_cases = []
        run_logs: list[dict] = []

        for tc in cases:
            logger.info("Running pipeline for test case %s …", tc.id)
            try:
                state = {
                    "messages":        [HumanMessage(content=tc.question)],
                    "query":           tc.question,
                    "next_agent":      "",
                    "retrieved_claims":[],
                    "fraud_result":    None,
                    "policy_result":   None,
                    "risk_score":      None,
                    "agent_outputs":   [],
                    "final_answer":    None,
                    "error":           None,
                }
                result     = graph.invoke(state)
                answer     = result.get("final_answer") or ""
                raw_claims = result.get("retrieved_claims", [])
                contexts   = tc.contexts or [str(c) for c in raw_claims[:5]]

                deepeval_cases.append(self.build_test_case(
                    question          = tc.question,
                    answer            = answer,
                    expected_output   = tc.ground_truth,
                    retrieval_context = contexts if contexts else ["No claims retrieved."],
                    test_case_id      = tc.id,
                ))
                run_logs.append({"id": tc.id, "status": "ok"})
            except Exception as exc:
                logger.error("Pipeline failed for %s: %s", tc.id, exc)
                run_logs.append({"id": tc.id, "status": "error", "error": str(exc)})

        if not deepeval_cases:
            return {"error": "All pipeline runs failed", "run_logs": run_logs}

        eval_result = self.evaluate(deepeval_cases, metrics=metrics)
        eval_result["run_logs"]   = run_logs
        eval_result["test_cases"] = [tc.id for tc in cases]
        return eval_result
