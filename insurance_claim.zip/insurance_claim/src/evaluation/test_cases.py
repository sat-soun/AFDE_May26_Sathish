"""
Golden evaluation dataset for the insurance claims multi-agent system.

Each EvalTestCase contains:
  - question        : the user query sent to the pipeline
  - ground_truth    : the expected answer (reference for RAGAS context recall
                      and DeepEval expected_output)
  - expected_fraud  : whether the scenario involves fraud
  - expected_tier   : expected risk tier (LOW / MEDIUM / HIGH / CRITICAL)
  - tags            : which agents / aspects this case exercises
  - contexts        : optional pre-written reference contexts; if None the
                      harness fills them from real retrieval

Derived from fraud_oracle.csv (FraudFound_P column) and train.csv (is_claim).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class EvalTestCase:
    id:              str
    question:        str
    ground_truth:    str
    expected_fraud:  bool        = False
    expected_tier:   str         = "LOW"
    tags:            list[str]   = field(default_factory=list)
    contexts:        Optional[list[str]] = None   # injected by harness if None


# ── Golden test cases ─────────────────────────────────────────────────────────
#
# Categories
#   R  – retrieval quality
#   F  – fraud analysis
#   P  – policy validation
#   Rs – risk scoring
#   E2E– end-to-end pipeline

GOLDEN_DATASET: list[EvalTestCase] = [

    # ── Retrieval ─────────────────────────────────────────────────────────────
    EvalTestCase(
        id="R-001",
        question="Find all Sport vehicle auto claims where the fault was attributed to the policy holder.",
        ground_truth=(
            "The retrieved records should include Sport category vehicle claims where "
            "Fault is 'Policy Holder'. Key fields: VehicleCategory=Sport, Fault=Policy Holder."
        ),
        expected_fraud=False,
        expected_tier="LOW",
        tags=["retrieval"],
    ),
    EvalTestCase(
        id="R-002",
        question="Show me claims filed in December with no police report and no witness present.",
        ground_truth=(
            "Retrieved claims should have Month=Dec, PoliceReportFiled=No, WitnessPresent=No. "
            "These attributes are associated with higher fraud probability."
        ),
        expected_fraud=True,
        expected_tier="MEDIUM",
        tags=["retrieval", "fraud"],
    ),
    EvalTestCase(
        id="R-003",
        question="Retrieve claims where the vehicle price is above 69000 and the claimant has prior claims.",
        ground_truth=(
            "Results should filter for VehiclePrice='more than 69000' and "
            "PastNumberOfClaims != 'none'. High-value vehicles with repeat claimants "
            "warrant closer fraud scrutiny."
        ),
        expected_fraud=True,
        expected_tier="MEDIUM",
        tags=["retrieval"],
    ),

    # ── Fraud analysis ────────────────────────────────────────────────────────
    EvalTestCase(
        id="F-001",
        question="Analyse fraud signals for claims filed shortly after policy inception with no police report.",
        ground_truth=(
            "Key fraud signals: Days_Policy_Accident is very short (indicating claim filed soon "
            "after policy start), PoliceReportFiled=No reduces claim credibility. "
            "The fraud analysis should flag at least two HIGH-severity signals: "
            "early-claim pattern and absence of police documentation."
        ),
        expected_fraud=True,
        expected_tier="HIGH",
        tags=["fraud"],
    ),
    EvalTestCase(
        id="F-002",
        question="Check for duplicate or near-duplicate claim submissions from the same agent type.",
        ground_truth=(
            "The fraud analysis should detect clustering of claims from the same AgentType "
            "(External or Internal) within a short time window as a duplicate-submission signal."
        ),
        expected_fraud=True,
        expected_tier="MEDIUM",
        tags=["fraud"],
    ),
    EvalTestCase(
        id="F-003",
        question="Are there any low-risk claims with no fraud history and police report filed?",
        ground_truth=(
            "Claims with PoliceReportFiled=Yes, WitnessPresent=Yes, PastNumberOfClaims=none, "
            "and FraudFound_P=0 should receive a LOW risk tier with no fraud signals detected."
        ),
        expected_fraud=False,
        expected_tier="LOW",
        tags=["fraud", "risk_scoring"],
    ),

    # ── Policy validation ─────────────────────────────────────────────────────
    EvalTestCase(
        id="P-001",
        question="Validate whether Sport-Collision claims meet coverage requirements when the deductible is above 400.",
        ground_truth=(
            "PolicyType 'Sport - Collision' covers collision damage. "
            "A deductible of 400 or above is within standard policy terms. "
            "The policy validation verdict should be PASS or NEEDS_REVIEW depending on "
            "additional eligibility criteria."
        ),
        expected_fraud=False,
        expected_tier="LOW",
        tags=["policy_validation"],
    ),
    EvalTestCase(
        id="P-002",
        question="Check policy compliance for claims where the address changed within a year of the claim date.",
        ground_truth=(
            "AddressChange_Claim='1 year' is a known fraud indicator and may trigger a "
            "NEEDS_REVIEW verdict in policy validation because it raises questions about "
            "the insured's residency and risk profile continuity."
        ),
        expected_fraud=True,
        expected_tier="MEDIUM",
        tags=["policy_validation", "fraud"],
    ),

    # ── Risk scoring ──────────────────────────────────────────────────────────
    EvalTestCase(
        id="Rs-001",
        question=(
            "Score the risk for a claim with: no police report, no witness, "
            "address changed within 1 year, more than 5 supplemental claims, "
            "and the vehicle is a Sport category with value above 69000."
        ),
        ground_truth=(
            "This claim exhibits multiple HIGH-severity fraud signals: "
            "no police report, no witness, recent address change, and high supplemental count. "
            "Expected risk tier: HIGH or CRITICAL. Fraud probability > 0.7. "
            "Investigation priority >= 8. "
            "Recommended actions should include manual adjuster review and SIU referral."
        ),
        expected_fraud=True,
        expected_tier="HIGH",
        tags=["risk_scoring", "fraud"],
    ),
    EvalTestCase(
        id="Rs-002",
        question=(
            "What is the risk score for a first-time claimant with a police report, "
            "a witness, and a sedan vehicle under 20000 value?"
        ),
        ground_truth=(
            "First-time claimant (PastNumberOfClaims=none), police report filed, witness present, "
            "and low vehicle value are all LOW-risk indicators. "
            "Expected fraud probability < 0.3, risk tier LOW, priority <= 3."
        ),
        expected_fraud=False,
        expected_tier="LOW",
        tags=["risk_scoring"],
    ),

    # ── End-to-end pipeline ────────────────────────────────────────────────────
    EvalTestCase(
        id="E2E-001",
        question=(
            "Give me a full analysis of high-value Sport vehicle claims where "
            "FraudFound_P is 1, including fraud signals, policy status, and risk score."
        ),
        ground_truth=(
            "The pipeline should: (1) retrieve claims with VehicleCategory=Sport, "
            "VehiclePrice='more than 69000', FraudFound_P=1; "
            "(2) identify fraud signals such as no police report, no witness, short policy tenure; "
            "(3) validate policy compliance and flag any coverage gaps; "
            "(4) assign a HIGH or CRITICAL risk tier with investigation priority >= 7; "
            "(5) recommend SIU referral and manual review."
        ),
        expected_fraud=True,
        expected_tier="HIGH",
        tags=["retrieval", "fraud", "policy_validation", "risk_scoring"],
    ),
    EvalTestCase(
        id="E2E-002",
        question="Summarise the claims profile for married female claimants aged 26–35 with sedan vehicles.",
        ground_truth=(
            "The summary should cover: Sex=Female, MaritalStatus=Married, Age range 26-35, "
            "VehicleCategory=Sedan. It should include claim count, average claimed amount, "
            "fraud rate within this group, and any notable patterns. "
            "This is typically a low-fraud demographic."
        ),
        expected_fraud=False,
        expected_tier="LOW",
        tags=["retrieval", "risk_scoring"],
    ),
]


def get_test_cases(tags: Optional[list[str]] = None) -> list[EvalTestCase]:
    """
    Return test cases, optionally filtered by tag.

    Args:
        tags: If provided, only return cases that have at least one matching tag.

    Returns:
        Filtered list of EvalTestCase.
    """
    if not tags:
        return GOLDEN_DATASET
    return [tc for tc in GOLDEN_DATASET if any(t in tc.tags for t in tags)]
