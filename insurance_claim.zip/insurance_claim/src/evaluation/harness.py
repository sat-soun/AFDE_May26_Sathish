"""
Evaluation harness — orchestrates the full evaluation run.

The harness:
  1. Runs each EvalTestCase through the live LangGraph pipeline
  2. Feeds pipeline outputs into both RAGAS and DeepEval evaluators
  3. Merges the two reports into a single combined result
  4. Optionally writes the report to disk as JSON

Usage
──────
    # CLI
    python -m src.evaluation.harness --tags fraud risk_scoring --out results.json

    # Programmatic
    from src.evaluation.harness import EvaluationHarness
    harness = EvaluationHarness()
    report  = harness.run(tags=["fraud"])
    print(report["summary"])
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Optional

from src.evaluation.test_cases import EvalTestCase, get_test_cases

logger = logging.getLogger(__name__)


class EvaluationHarness:
    """
    Unified entry point for running RAGAS + DeepEval evaluation.

    Both evaluators share the same pipeline runs (single invoke per test case)
    to avoid redundant LLM calls and ensure apples-to-apples comparison.
    """

    def __init__(
        self,
        enable_ragas:    bool = True,
        enable_deepeval: bool = True,
    ) -> None:
        self.enable_ragas    = enable_ragas
        self.enable_deepeval = enable_deepeval

    # ── Core run ───────────────────────────────────────────────────────────────

    def run(
        self,
        test_cases: Optional[list[EvalTestCase]] = None,
        tags:       Optional[list[str]]          = None,
        output_path: Optional[Path | str]        = None,
    ) -> dict[str, Any]:
        """
        Execute the evaluation pipeline.

        Args:
            test_cases:  Explicit list of EvalTestCase. Overrides ``tags``.
            tags:        Filter test cases by tag subset. None = all cases.
            output_path: If provided, write the JSON report to this path.

        Returns:
            Combined evaluation report dict.
        """
        cases = test_cases or get_test_cases(tags)
        logger.info(
            "Harness: running %d test case(s) through pipeline …", len(cases)
        )

        # ── Run pipeline once per test case ────────────────────────────────────
        pipeline_outputs = self._run_pipeline(cases)

        report: dict[str, Any] = {
            "timestamp":    time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "test_cases":   [tc.id for tc in cases],
            "pipeline_runs": pipeline_outputs["logs"],
            "ragas":        None,
            "deepeval":     None,
            "summary":      {},
        }

        # ── RAGAS ─────────────────────────────────────────────────────────────
        if self.enable_ragas:
            try:
                from src.evaluation.ragas_eval import RagasEvaluator, RagasSample
                evaluator  = RagasEvaluator()
                ragas_samples = [
                    RagasSample(
                        question  = o["question"],
                        answer    = o["answer"],
                        contexts  = o["contexts"],
                        reference = o["reference"],
                    )
                    for o in pipeline_outputs["results"]
                ]
                report["ragas"] = evaluator.evaluate(ragas_samples)
            except Exception as exc:
                logger.error("RAGAS evaluation failed: %s", exc)
                report["ragas"] = {"error": str(exc)}

        # ── DeepEval ───────────────────────────────────────────────────────────
        if self.enable_deepeval:
            try:
                from src.evaluation.deepeval_eval import DeepEvalEvaluator
                evaluator      = DeepEvalEvaluator()
                deepeval_cases = [
                    evaluator.build_test_case(
                        question          = o["question"],
                        answer            = o["answer"],
                        expected_output   = o["reference"],
                        retrieval_context = o["contexts"],
                        test_case_id      = o["id"],
                    )
                    for o in pipeline_outputs["results"]
                ]
                report["deepeval"] = evaluator.evaluate(deepeval_cases)
            except Exception as exc:
                logger.error("DeepEval evaluation failed: %s", exc)
                report["deepeval"] = {"error": str(exc)}

        # ── Summary ────────────────────────────────────────────────────────────
        report["summary"] = self._build_summary(report)

        # ── Persist ────────────────────────────────────────────────────────────
        if output_path:
            out = Path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(report, indent=2, default=str))
            logger.info("Evaluation report written to %s", out)

        return report

    # ── Pipeline runner ────────────────────────────────────────────────────────

    def _run_pipeline(self, cases: list[EvalTestCase]) -> dict[str, Any]:
        """Run the LangGraph pipeline for each test case; return collected outputs."""
        from langchain_core.messages import HumanMessage
        from src.graph.builder import get_graph

        graph   = get_graph()
        results = []
        logs    = []

        for tc in cases:
            try:
                state = {
                    "messages":         [HumanMessage(content=tc.question)],
                    "query":            tc.question,
                    "next_agent":       "",
                    "retrieved_claims": [],
                    "fraud_result":     None,
                    "policy_result":    None,
                    "risk_score":       None,
                    "agent_outputs":    [],
                    "final_answer":     None,
                    "error":            None,
                }
                result     = graph.invoke(state)
                answer     = result.get("final_answer") or ""
                raw_claims = result.get("retrieved_claims", [])
                contexts   = tc.contexts or [str(c) for c in raw_claims[:5]]

                results.append({
                    "id":        tc.id,
                    "question":  tc.question,
                    "answer":    answer,
                    "contexts":  contexts if contexts else ["No claims retrieved."],
                    "reference": tc.ground_truth,
                    "tags":      tc.tags,
                })
                logs.append({"id": tc.id, "status": "ok"})
                logger.info("  [%s] pipeline OK (answer length=%d)", tc.id, len(answer))

            except Exception as exc:
                logger.error("  [%s] pipeline FAILED: %s", tc.id, exc)
                logs.append({"id": tc.id, "status": "error", "error": str(exc)})

        return {"results": results, "logs": logs}

    # ── Summary builder ────────────────────────────────────────────────────────

    @staticmethod
    def _build_summary(report: dict[str, Any]) -> dict[str, Any]:
        summary: dict[str, Any] = {}

        ragas = report.get("ragas") or {}
        if "aggregate_scores" in ragas:
            summary["ragas"] = ragas["aggregate_scores"]

        deepeval = report.get("deepeval") or {}
        if "aggregate_scores" in deepeval:
            summary["deepeval"] = deepeval["aggregate_scores"]

        # Overall health: average of all numeric scores across both frameworks
        all_scores = [
            v for d in [summary.get("ragas", {}), summary.get("deepeval", {})]
            for v in d.values()
            if isinstance(v, (int, float))
        ]
        summary["overall_avg"] = (
            round(sum(all_scores) / len(all_scores), 4) if all_scores else None
        )

        total   = len(report.get("pipeline_runs", []))
        ok      = sum(1 for r in report.get("pipeline_runs", []) if r.get("status") == "ok")
        summary["pipeline_success_rate"] = f"{ok}/{total}"

        return summary


# ── CLI entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    )

    parser = argparse.ArgumentParser(description="Run RAGAS + DeepEval evaluation")
    parser.add_argument(
        "--tags", nargs="*",
        help="Filter test cases by tag (e.g. fraud retrieval). Omit for all cases."
    )
    parser.add_argument(
        "--out", default="data/processed/eval_report.json",
        help="Output path for the JSON report."
    )
    parser.add_argument("--no-ragas",    action="store_true")
    parser.add_argument("--no-deepeval", action="store_true")
    args = parser.parse_args()

    harness = EvaluationHarness(
        enable_ragas    = not args.no_ragas,
        enable_deepeval = not args.no_deepeval,
    )
    report = harness.run(tags=args.tags, output_path=args.out)

    print("\n" + "═" * 60)
    print("EVALUATION SUMMARY")
    print("═" * 60)
    print(json.dumps(report["summary"], indent=2))
    print("═" * 60)
