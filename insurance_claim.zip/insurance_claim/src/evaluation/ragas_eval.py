"""
RAGAS-based evaluation for the insurance claims pipeline.

Metrics evaluated
──────────────────
  Faithfulness          – Is the answer grounded in the retrieved claims?
  AnswerRelevancy       – Does the answer address the user's question?
  LLMContextPrecision   – Are the most relevant claims ranked highest?
  LLMContextRecall      – Do the retrieved claims cover the reference answer?

The evaluator LLM and embeddings are wired from project settings so the same
base URL / API key used by agents is also used for RAGAS evaluation.

Usage
──────
    from src.evaluation.ragas_eval import RagasEvaluator
    evaluator = RagasEvaluator()

    # From pipeline outputs
    sample = evaluator.build_sample(
        question="...",
        answer="...",
        contexts=["claim 1 text", "claim 2 text"],
        reference="expected answer",
    )
    result = evaluator.evaluate([sample])

    # Or run the full golden dataset through the live pipeline
    result = evaluator.evaluate_pipeline(test_cases=[...])
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ── RAGAS sample wrapper ───────────────────────────────────────────────────────

@dataclass
class RagasSample:
    """Thin wrapper — holds the data fields before building a RAGAS dataset."""
    question:  str
    answer:    str
    contexts:  list[str]
    reference: str             # ground_truth


# ── Evaluator ──────────────────────────────────────────────────────────────────

class RagasEvaluator:
    """
    Wraps the RAGAS evaluation library with project LLM / embedding settings.
    Lazy-imports ragas so the module can be imported even if ragas is not yet
    installed (it will fail at evaluate-time with a clear message).
    """

    def __init__(self) -> None:
        self._llm        = None
        self._embeddings = None

    def _get_llm(self):
        """Build a RAGAS-compatible LLM wrapper from project settings."""
        if self._llm is None:
            try:
                from ragas.llms import LangchainLLMWrapper
                from langchain_openai import ChatOpenAI
                from config.settings import get_settings

                settings = get_settings()
                self._llm = LangchainLLMWrapper(ChatOpenAI(
                    model=settings.llm_model,
                    api_key=settings.llm_api_key,
                    base_url=settings.llm_base_url,
                    temperature=0.0,
                ))
            except ImportError as e:
                raise ImportError(
                    "RAGAS is not installed. Run: pip install ragas"
                ) from e
        return self._llm

    def _get_embeddings(self):
        """Build a RAGAS-compatible embeddings wrapper from project settings."""
        if self._embeddings is None:
            from ragas.embeddings import LangchainEmbeddingsWrapper
            from langchain_openai import OpenAIEmbeddings
            from config.settings import get_settings

            settings = get_settings()
            self._embeddings = LangchainEmbeddingsWrapper(OpenAIEmbeddings(
                model=settings.embedding_model,
                api_key=settings.effective_embedding_api_key,
                base_url=settings.effective_embedding_base_url,
            ))
        return self._embeddings

    # ── Build individual samples ───────────────────────────────────────────────

    @staticmethod
    def build_sample(
        question:  str,
        answer:    str,
        contexts:  list[str],
        reference: str,
    ) -> RagasSample:
        return RagasSample(
            question=question,
            answer=answer,
            contexts=contexts,
            reference=reference,
        )

    # ── Evaluate a list of pre-built samples ───────────────────────────────────

    def evaluate(
        self,
        samples: list[RagasSample],
        metrics: Optional[list] = None,
    ) -> dict[str, Any]:
        """
        Run RAGAS metrics over a list of RagasSample objects.

        Args:
            samples: List of (question, answer, contexts, reference) tuples.
            metrics: RAGAS metric instances to use. Defaults to the four core metrics.

        Returns:
            Dict with per-metric scores and a per-sample breakdown.
        """
        try:
            from ragas import evaluate as ragas_evaluate
            from ragas.dataset_schema import SingleTurnSample, EvaluationDataset
            from ragas.metrics import (
                Faithfulness,
                AnswerRelevancy,
                LLMContextPrecisionWithReference,
                LLMContextRecall,
            )
        except ImportError as e:
            raise ImportError("Run: pip install ragas") from e

        if not samples:
            return {"error": "No samples provided", "scores": {}}

        _metrics = metrics or [
            Faithfulness(),
            AnswerRelevancy(),
            LLMContextPrecisionWithReference(),
            LLMContextRecall(),
        ]

        # Wire project LLM + embeddings into every metric
        llm        = self._get_llm()
        embeddings = self._get_embeddings()
        for m in _metrics:
            if hasattr(m, "llm"):
                m.llm = llm
            if hasattr(m, "embeddings"):
                m.embeddings = embeddings

        # Build RAGAS dataset
        ragas_samples = [
            SingleTurnSample(
                user_input         = s.question,
                response           = s.answer,
                retrieved_contexts = s.contexts,
                reference          = s.reference,
            )
            for s in samples
        ]
        dataset = EvaluationDataset(samples=ragas_samples)

        logger.info("Running RAGAS evaluation on %d samples …", len(samples))
        result = ragas_evaluate(dataset=dataset, metrics=_metrics)
        scores = result.to_pandas().to_dict(orient="list")

        return {
            "framework":        "ragas",
            "sample_count":     len(samples),
            "aggregate_scores": {
                k: round(float(sum(v) / len(v)), 4)
                for k, v in scores.items()
                if isinstance(v[0], (int, float))
            },
            "per_sample":       scores,
        }

    # ── Run the live pipeline then evaluate ───────────────────────────────────

    def evaluate_pipeline(
        self,
        test_cases: Optional[list] = None,
        metrics:    Optional[list] = None,
    ) -> dict[str, Any]:
        """
        Run each EvalTestCase through the live LangGraph pipeline, collect
        outputs, then evaluate with RAGAS.

        Args:
            test_cases: EvalTestCase list. Defaults to the full GOLDEN_DATASET.
            metrics:    RAGAS metric instances. Defaults to the four core metrics.

        Returns:
            Combined evaluation report dict.
        """
        from langchain_core.messages import HumanMessage
        from src.graph.builder import get_graph
        from src.evaluation.test_cases import GOLDEN_DATASET

        cases  = test_cases or GOLDEN_DATASET
        graph  = get_graph()
        samples: list[RagasSample] = []
        run_logs: list[dict] = []

        for tc in cases:
            logger.info("Running pipeline for test case %s …", tc.id)
            try:
                state = {
                    "messages": [HumanMessage(content=tc.question)],
                    "query": tc.question,
                    "next_agent": "",
                    "retrieved_claims": [],
                    "fraud_result":  None,
                    "policy_result": None,
                    "risk_score":    None,
                    "agent_outputs": [],
                    "final_answer":  None,
                    "error":         None,
                }
                result       = graph.invoke(state)
                answer       = result.get("final_answer") or ""
                raw_claims   = result.get("retrieved_claims", [])
                contexts     = tc.contexts or [str(c) for c in raw_claims[:5]]

                samples.append(self.build_sample(
                    question  = tc.question,
                    answer    = answer,
                    contexts  = contexts if contexts else ["No claims retrieved."],
                    reference = tc.ground_truth,
                ))
                run_logs.append({"id": tc.id, "status": "ok"})
            except Exception as exc:
                logger.error("Pipeline failed for %s: %s", tc.id, exc)
                run_logs.append({"id": tc.id, "status": "error", "error": str(exc)})

        if not samples:
            return {"error": "All pipeline runs failed", "run_logs": run_logs}

        eval_result = self.evaluate(samples, metrics=metrics)
        eval_result["run_logs"]   = run_logs
        eval_result["test_cases"] = [tc.id for tc in cases]
        return eval_result
