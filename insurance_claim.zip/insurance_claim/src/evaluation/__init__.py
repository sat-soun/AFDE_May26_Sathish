"""
Evaluation framework for the insurance claims multi-agent system.

Modules
────────
  test_cases.py    – Golden Q&A dataset (EvalTestCase, GOLDEN_DATASET)
  metrics.py       – Lightweight custom metrics (retrieval precision, fraud F1, MAE)
  ragas_eval.py    – RAGAS: faithfulness, answer relevancy, context precision/recall
  deepeval_eval.py – DeepEval: standard + custom G-Eval metrics (fraud accuracy, risk tier)
  harness.py       – Orchestration: run pipeline → RAGAS + DeepEval → combined report

Quick start
────────────
    # Run full evaluation from CLI:
    python -m src.evaluation.harness --out data/processed/eval_report.json

    # Filter to fraud-related test cases only:
    python -m src.evaluation.harness --tags fraud --no-deepeval

    # Programmatic use:
    from src.evaluation.harness import EvaluationHarness
    report = EvaluationHarness().run(tags=["fraud", "risk_scoring"])
"""
from src.evaluation.harness import EvaluationHarness
from src.evaluation.test_cases import EvalTestCase, GOLDEN_DATASET, get_test_cases
from src.evaluation.ragas_eval import RagasEvaluator
from src.evaluation.deepeval_eval import DeepEvalEvaluator

__all__ = [
    "EvaluationHarness",
    "EvalTestCase",
    "GOLDEN_DATASET",
    "get_test_cases",
    "RagasEvaluator",
    "DeepEvalEvaluator",
]
