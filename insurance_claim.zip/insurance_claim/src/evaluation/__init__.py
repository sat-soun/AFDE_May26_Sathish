"""
Evaluation framework for the insurance claims multi-agent system.

Planned modules (add as the project matures):
  - metrics.py      : Retrieval precision/recall, fraud F1, risk score calibration
  - test_cases.py   : Golden Q&A pairs for regression testing
  - harness.py      : Run the full graph against a test suite and report scores
  - ragas_eval.py   : RAGAS-based faithfulness, context relevance, answer relevance
"""
