"""
Embedding pipeline — converts chunked Documents into a persisted vector store.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from config.settings import get_settings

logger = logging.getLogger(__name__)


def build_embeddings() -> OpenAIEmbeddings:
    """Construct the embedding model from settings.
    Uses EMBEDDING_API_KEY / EMBEDDING_BASE_URL if set,
    otherwise falls back to LLM_API_KEY / LLM_BASE_URL.
    """
    settings = get_settings()
    return OpenAIEmbeddings(
        model=settings.embedding_model,
        api_key=settings.effective_embedding_api_key,
        base_url=settings.effective_embedding_base_url,
    )


def embed_and_persist(
    documents: list[Document],
    collection_name: Optional[str] = None,
    persist_directory: Optional[str | Path] = None,
) -> Chroma:
    """
    Embed a list of chunked Documents and persist them to a Chroma vector store.

    Args:
        documents:         Chunked Documents from the ingestion pipeline.
        collection_name:   Chroma collection name (falls back to settings).
        persist_directory: Directory for on-disk persistence (falls back to settings).

    Returns:
        A ready-to-query Chroma instance.
    """
    settings = get_settings()
    _collection = collection_name or settings.vectorstore_collection
    _persist_dir = str(persist_directory or settings.vectorstore_path)

    embeddings = build_embeddings()

    logger.info(
        "Embedding %d documents into collection '%s' at %s",
        len(documents),
        _collection,
        _persist_dir,
    )

    vectorstore = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        collection_name=_collection,
        persist_directory=_persist_dir,
    )

    logger.info("Vector store persisted successfully.")
    return vectorstore


def load_vectorstore(
    collection_name: Optional[str] = None,
    persist_directory: Optional[str | Path] = None,
) -> Chroma:
    """
    Load an existing persisted Chroma vector store.

    Raises:
        FileNotFoundError: If the persist directory does not exist.
    """
    settings = get_settings()
    _collection = collection_name or settings.vectorstore_collection
    _persist_dir = Path(persist_directory or settings.vectorstore_path)

    if not _persist_dir.exists():
        raise FileNotFoundError(
            f"Vector store not found at {_persist_dir}. "
            "Run the ingestion pipeline first."
        )

    embeddings = build_embeddings()

    logger.info("Loading vector store from %s", _persist_dir)
    return Chroma(
        collection_name=_collection,
        embedding_function=embeddings,
        persist_directory=str(_persist_dir),
    )


def run_ingestion_pipeline(
    csv_path: str | Path,
    text_columns: Optional[list[str]] = None,
    metadata_columns: Optional[list[str]] = None,
    max_chars: int = 1500,
) -> Chroma:
    """
    End-to-end convenience wrapper: load → chunk → embed → persist.

    Args:
        csv_path:         Path to the raw insurance claims CSV.
        text_columns:     Columns to include in page_content.
        metadata_columns: Columns to include in metadata.
        max_chars:        Chunking threshold (see chunker.py).

    Returns:
        Persisted Chroma vector store.
    """
    from src.ingestion.loader import load_csv_as_documents
    from src.ingestion.chunker import chunk_documents

    raw_docs = load_csv_as_documents(
        csv_path,
        text_columns=text_columns,
        metadata_columns=metadata_columns,
    )
    chunked_docs = chunk_documents(raw_docs, max_chars=max_chars)
    return embed_and_persist(chunked_docs)
