"""
Chunking strategy for insurance claim CSV data.

Design rationale
────────────────
Insurance claim CSVs are inherently row-structured: each row is a self-contained
claim record. Unlike unstructured text where overlapping sliding windows are
appropriate, here the optimal chunk IS the row — splitting a row mid-way would
destroy relational context (e.g. splitting claim_id from claim_amount).

Strategy: Row-Level Chunking with Optional Field-Group Sub-Chunking
────────────────────────────────────────────────────────────────────
1. PRIMARY   — one Document per row (default, always produced)
   Best for: exact claim retrieval, fraud signal matching.

2. SECONDARY — if a row's page_content exceeds `max_chars`, the row is split
   into logical field groups (identity, financials, narrative) so that
   each embedded chunk stays within the model's context window without
   losing field-label context.

Both strategies tag every chunk with a `chunk_strategy` metadata field so
downstream components can inspect what they received.
"""

from __future__ import annotations

import logging
from typing import Optional

from langchain_core.documents import Document

logger = logging.getLogger(__name__)

# Default groups used when a row exceeds max_chars.
# Adjust group names / field prefixes to match your actual CSV headers.
DEFAULT_FIELD_GROUPS: list[tuple[str, list[str]]] = [
    (
        "identity",
        ["claim_id", "policy_id", "claimant_id", "claimant_name",
         "policy_holder", "customer_id"],
    ),
    (
        "incident",
        ["claim_type", "claim_date", "incident_date", "reported_date",
         "location", "description", "incident_description"],
    ),
    (
        "financials",
        ["claimed_amount", "approved_amount", "deductible",
         "settlement_amount", "policy_limit"],
    ),
    (
        "status_and_flags",
        ["status", "fraud_flag", "prior_claims_count", "provider_id",
         "adjuster_id", "notes"],
    ),
]


def chunk_documents(
    documents: list[Document],
    max_chars: int = 1500,
    field_groups: Optional[list[tuple[str, list[str]]]] = None,
) -> list[Document]:
    """
    Apply row-level chunking to a list of Documents loaded from a CSV.

    For rows whose page_content is within `max_chars`, returns the row as-is
    (tagged `chunk_strategy=row`).

    For rows exceeding `max_chars`, splits into field-group sub-chunks
    (tagged `chunk_strategy=field_group`), each inheriting the row's metadata.

    Args:
        documents:    Output of ``loader.load_csv_as_documents``.
        max_chars:    Character threshold above which field-group splitting
                      is applied (default 1 500).
        field_groups: Custom field-group definitions. Falls back to
                      ``DEFAULT_FIELD_GROUPS`` when None.

    Returns:
        Flat list of chunked Documents ready for embedding.
    """
    _groups = field_groups or DEFAULT_FIELD_GROUPS
    chunked: list[Document] = []

    for doc in documents:
        if len(doc.page_content) <= max_chars:
            # Row fits — keep as single chunk
            doc.metadata["chunk_strategy"] = "row"
            doc.metadata["chunk_id"] = _make_chunk_id(doc, "row", 0)
            chunked.append(doc)
        else:
            # Row too long — split by field groups
            sub_chunks = _split_by_field_groups(doc, _groups)
            if sub_chunks:
                chunked.extend(sub_chunks)
            else:
                # Fallback: keep the full row even if oversized
                doc.metadata["chunk_strategy"] = "row_oversized"
                doc.metadata["chunk_id"] = _make_chunk_id(doc, "row_oversized", 0)
                chunked.append(doc)

    logger.info(
        "Chunked %d source documents → %d chunks",
        len(documents),
        len(chunked),
    )
    return chunked


def _split_by_field_groups(
    doc: Document,
    groups: list[tuple[str, list[str]]],
) -> list[Document]:
    """
    Split a single Document into sub-Documents, one per field group.
    Each sub-Document inherits all original metadata.
    """
    # Parse the "key: value | key: value | ..." format back to a dict
    kv_pairs: dict[str, str] = {}
    for part in doc.page_content.split(" | "):
        if ": " in part:
            k, _, v = part.partition(": ")
            kv_pairs[k.strip()] = v.strip()

    sub_docs: list[Document] = []

    for group_idx, (group_name, field_prefixes) in enumerate(groups):
        # Match fields by exact name OR prefix (case-insensitive)
        matched_pairs = {
            k: v for k, v in kv_pairs.items()
            if any(
                k.lower() == fp.lower() or k.lower().startswith(fp.lower())
                for fp in field_prefixes
            )
        }

        if not matched_pairs:
            continue

        content = " | ".join(f"{k}: {v}" for k, v in matched_pairs.items())

        meta = dict(doc.metadata)
        meta["chunk_strategy"] = "field_group"
        meta["field_group"] = group_name
        meta["chunk_id"] = _make_chunk_id(doc, group_name, group_idx)

        sub_docs.append(Document(page_content=content, metadata=meta))

    return sub_docs


def _make_chunk_id(doc: Document, suffix: str, idx: int) -> str:
    row_idx = doc.metadata.get("row_index", "?")
    source = doc.metadata.get("source_file", "unknown")
    return f"{source}_row{row_idx}_{suffix}_{idx}"
