"""
CSV Loader — reads raw insurance claim CSV files and returns a list of
LangChain Document objects ready for chunking.
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Optional

from langchain_core.documents import Document

logger = logging.getLogger(__name__)


def load_csv_as_documents(
    file_path: str | Path,
    text_columns: Optional[list[str]] = None,
    metadata_columns: Optional[list[str]] = None,
    encoding: str = "utf-8",
) -> list[Document]:
    """
    Load a CSV file and convert every row into a LangChain Document.

    Strategy (row-level chunking):
    - page_content  : human-readable text reconstruction of key narrative fields
    - metadata      : all remaining columns stored as structured key-value pairs

    This keeps the full claim context visible to the LLM while preserving
    every field for filtered retrieval and post-processing.

    Args:
        file_path:        Path to the CSV file.
        text_columns:     Columns whose values form the page_content string.
                          Defaults to ALL columns when None.
        metadata_columns: Columns to store as metadata.
                          Defaults to ALL columns when None.
        encoding:         File encoding (default utf-8).

    Returns:
        List of Document objects, one per CSV row.
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"CSV file not found: {file_path}")

    documents: list[Document] = []

    with file_path.open(newline="", encoding=encoding) as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise ValueError("CSV file has no header row.")

        all_columns = list(reader.fieldnames)

        # Resolve column lists
        _text_cols = text_columns or all_columns
        _meta_cols = metadata_columns or all_columns

        for row_idx, row in enumerate(reader):
            # ── Build page_content ────────────────────────────────────────
            # Format: "field_name: value | field_name: value | ..."
            # This preserves field semantics in the embedded text so the
            # retriever can match on both field names and values.
            content_parts = [
                f"{col}: {row.get(col, '').strip()}"
                for col in _text_cols
                if row.get(col, "").strip()
            ]
            page_content = " | ".join(content_parts)

            # ── Build metadata ────────────────────────────────────────────
            metadata: dict = {
                col: row.get(col, "").strip()
                for col in _meta_cols
            }
            metadata["source_file"] = file_path.name
            metadata["row_index"] = row_idx

            documents.append(
                Document(page_content=page_content, metadata=metadata)
            )

    logger.info(
        "Loaded %d documents from %s", len(documents), file_path.name
    )
    return documents
