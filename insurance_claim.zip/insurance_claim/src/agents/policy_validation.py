"""
Policy Validation Agent.

Verifies that a claim satisfies the terms, coverage limits, and eligibility
conditions of the associated insurance policy.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent

from config.prompts import POLICY_VALIDATION_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.policy_tools import (
    validate_policy_compliance,
    check_coverage_eligibility,
    verify_policy_active,
)

logger = logging.getLogger(__name__)


class PolicyValidationAgent(BaseAgent):
    agent_name = "policy_validation"
    system_prompt = POLICY_VALIDATION_SYSTEM_PROMPT
    tools = [validate_policy_compliance, check_coverage_eligibility, verify_policy_active]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        retrieved_claims = state.get("retrieved_claims", [])
        query = state.get("query", "")

        prompt = (
            f"User Query: {query}\n\n"
            f"Claims to validate ({len(retrieved_claims)} records):\n"
            + "\n".join(str(c) for c in retrieved_claims[:10])
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        policy_validation = {
            "claim_ids_validated": [c.get("claim_id") for c in retrieved_claims],
            "summary": last_ai,
            "checks": [],           # populated by validate_policy_compliance tool
            "overall_verdict": "NEEDS_REVIEW",
        }

        logger.info("PolicyValidationAgent completed validation")
        return {"policy_validation": policy_validation}
