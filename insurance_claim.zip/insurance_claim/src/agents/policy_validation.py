"""
Policy Validation Agent.

Verifies that a claim satisfies the terms, coverage limits, and eligibility
conditions of the associated insurance policy.
"""
from __future__ import annotations
import json
import logging
from typing import Any
from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent
from config.prompts import POLICY_VALIDATION_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.policy_tools import (
    validate_policy_compliance,
    check_coverage_eligibility,
    verify_policy_active,
)

logger = logging.getLogger(__name__)


def _derive_overall_verdict(checks: list[dict]) -> str:
    verdicts = {c.get("verdict", "NEEDS_REVIEW") for c in checks}
    if "FAIL" in verdicts:
        return "FAIL"
    if "NEEDS_REVIEW" in verdicts:
        return "NEEDS_REVIEW"
    return "PASS"


class PolicyValidationAgent(BaseAgent):
    agent_name = "policy_validation"
    system_prompt = POLICY_VALIDATION_SYSTEM_PROMPT
    tools = [validate_policy_compliance, check_coverage_eligibility, verify_policy_active]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        retrieved_claims = state.get("retrieved_claims", [])
        query = state.get("query", "")

        prompt = (
            "User Query: {}\n\nClaims to validate ({} records):\n{}".format(
                query, len(retrieved_claims),
                "\n".join(str(c) for c in retrieved_claims[:10])
            )
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        # Parse checks from validate_policy_compliance ToolMessage
        all_checks: list[dict] = []
        for msg in result.get("messages", []):
            tool_name = getattr(msg, "name", None)
            if tool_name == "validate_policy_compliance":
                try:
                    parsed = json.loads(msg.content)
                    if isinstance(parsed, list):
                        all_checks.extend(parsed)
                    elif isinstance(parsed, dict) and "error" not in parsed:
                        all_checks.append(parsed)
                except (json.JSONDecodeError, TypeError):
                    logger.warning("Could not parse validate_policy_compliance output")

        overall_verdict = _derive_overall_verdict(all_checks) if all_checks else "NEEDS_REVIEW"

        policy_validation = {
            "claim_ids_validated": [
                c.get("PolicyNumber") or c.get("claim_id") or c.get("row_index")
                for c in retrieved_claims
            ],
            "summary": last_ai,
            "checks": all_checks,
            "overall_verdict": overall_verdict,
        }

        logger.info(
            "PolicyValidationAgent: %d check(s), verdict=%s",
            len(all_checks), overall_verdict,
        )
        return {"policy_validation": policy_validation}
