"""
Base agent class — provides shared LLM initialisation, tool binding,
and a standardised run() interface.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from langchain_core.tools import BaseTool
from langchain_openai import ChatOpenAI

from config.settings import get_settings
from src.models.schemas import AgentResponse

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Abstract base for all insurance-claims agents.

    Subclasses must implement:
      - ``agent_name``  : str class attribute
      - ``tools``       : list[BaseTool] class/instance attribute
      - ``system_prompt``: str class attribute (imported from config/prompts.py)
      - ``_execute()``  : core agent logic

    The ``run()`` method provides a uniform error-handling wrapper so graph
    nodes never need to catch exceptions themselves.
    """

    agent_name: str = "base"
    tools: list[BaseTool] = []
    system_prompt: str = ""

    def __init__(self) -> None:
        settings = get_settings()
        self._llm = ChatOpenAI(
            model=settings.llm_model,
            temperature=settings.llm_temperature,
            max_tokens=settings.llm_max_tokens,
            openai_api_key=settings.openai_api_key,
        )
        if self.tools:
            self._llm_with_tools = self._llm.bind_tools(self.tools)
        else:
            self._llm_with_tools = self._llm

    # ── Public interface ──────────────────────────────────────────────────

    def run(self, state: dict[str, Any]) -> AgentResponse:
        """
        Execute the agent and return a standardised AgentResponse.
        All exceptions are caught and surfaced as error responses so the
        graph never crashes on a single agent failure.
        """
        try:
            data = self._execute(state)
            return AgentResponse(agent_name=self.agent_name, success=True, data=data)
        except Exception as exc:
            logger.exception("Agent '%s' raised an exception", self.agent_name)
            return AgentResponse(
                agent_name=self.agent_name,
                success=False,
                data={},
                error=str(exc),
            )

    # ── Abstract ──────────────────────────────────────────────────────────

    @abstractmethod
    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        """
        Core agent logic.  Receives the full graph state, returns a dict
        that will be stored in AgentResponse.data.
        """
        ...
