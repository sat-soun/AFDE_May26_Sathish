"""
Claims Retrieval Agent.

Translates a natural-language query into a semantic vector search and
returns the most relevant historical insurance claim records.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.prebuilt import create_react_agent

from config.prompts import CLAIMS_RETRIEVAL_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.retrieval_tools import retrieve_similar_claims, filter_claims_by_metadata

logger = logging.getLogger(__name__)


class ClaimsRetrievalAgent(BaseAgent):
    agent_name = "claims_retrieval"
    system_prompt = CLAIMS_RETRIEVAL_SYSTEM_PROMPT
    tools = [retrieve_similar_claims, filter_claims_by_metadata]

    def __init__(self) -> None:
        super().__init__()
        # ReAct agent with tool-calling loop
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        query = state.get("query", "")

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=query)]}
        )

        # Extract tool outputs (claim records) from message history
        claims: list[dict] = []
        for msg in result.get("messages", []):
            if hasattr(msg, "name") and msg.name == "retrieve_similar_claims":
                try:
                    import json
                    claims = json.loads(msg.content)
                except Exception:
                    pass

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        logger.info("ClaimsRetrievalAgent retrieved %d claims", len(claims))
        return {
            "claims": claims,
            "summary": last_ai,
        }
