"""
Supervisor (Orchestrator) Agent.

Reads the current state and conversation history, then decides which
specialist agent to invoke next, or emits "FINISH" when done.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from config.prompts import SUPERVISOR_SYSTEM_PROMPT
from src.agents.base import BaseAgent

logger = logging.getLogger(__name__)

# Agents the supervisor is allowed to route to
VALID_AGENTS = {
    "claims_retrieval",
    "fraud_analysis",
    "policy_validation",
    "risk_scoring",
    "FINISH",
}


class SupervisorAgent(BaseAgent):
    agent_name = "supervisor"
    tools = []  # Supervisor uses no tools — it only routes
    system_prompt = SUPERVISOR_SYSTEM_PROMPT

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        messages = state.get("messages", [])
        query = state.get("query", "")

        # Build context summary of what has already been done
        completed = [
            o["agent_name"]
            for o in state.get("agent_outputs", [])
            if o.get("success") and o["agent_name"] != "supervisor"
        ]
        context = (
            f"Query: {query}\n"
            f"Agents already called: {completed or 'none'}\n"
            f"Retrieved claims count: {len(state.get('retrieved_claims', []))}\n"
            f"Fraud result available: {state.get('fraud_result') is not None}\n"
            f"Policy result available: {state.get('policy_result') is not None}\n"
            f"Risk score available: {state.get('risk_score') is not None}"
        )

        response = self._llm.invoke([
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=context),
        ])

        # Extract routing decision from response
        raw = response.content.strip()
        next_agent = self._parse_routing(raw, completed)

        logger.info("Supervisor routing → %s", next_agent)
        return {"next": next_agent, "raw_response": raw}

    # ── Helpers ───────────────────────────────────────────────────────────

    def _parse_routing(self, raw: str, completed: list[str]) -> str:
        """
        Parse the LLM's routing response.  Tries JSON first, falls back to
        keyword scanning, then applies safety rules.
        """
        next_agent = None

        # Attempt JSON parse
        try:
            data = json.loads(raw)
            next_agent = data.get("next")
        except (json.JSONDecodeError, AttributeError):
            pass

        # Keyword scan fallback
        if next_agent not in VALID_AGENTS:
            for agent in VALID_AGENTS:
                if agent.lower() in raw.lower():
                    next_agent = agent
                    break

        # Default to FINISH if routing is ambiguous
        if next_agent not in VALID_AGENTS:
            logger.warning("Supervisor returned ambiguous routing '%s'; defaulting to FINISH", raw)
            next_agent = "FINISH"

        # Safety: if risk_scoring was routed before fraud_analysis, fix it
        if (
            next_agent == "risk_scoring"
            and "fraud_analysis" not in completed
            and "policy_validation" not in completed
        ):
            logger.info("Supervisor guard: routing to fraud_analysis before risk_scoring")
            next_agent = "fraud_analysis"

        return next_agent
