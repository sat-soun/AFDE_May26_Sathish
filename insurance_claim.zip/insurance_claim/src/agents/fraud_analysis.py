"""
Fraud Analysis Agent.

Examines retrieved claim records for known fraud signals and suspicious
behavioural patterns.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent

from config.prompts import FRAUD_ANALYSIS_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.fraud_tools import (
    detect_fraud_patterns,
    check_duplicate_claims,
    analyse_claimant_history,
)

logger = logging.getLogger(__name__)


class FraudAnalysisAgent(BaseAgent):
    agent_name = "fraud_analysis"
    system_prompt = FRAUD_ANALYSIS_SYSTEM_PROMPT
    tools = [detect_fraud_patterns, check_duplicate_claims, analyse_claimant_history]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        retrieved_claims = state.get("retrieved_claims", [])
        query = state.get("query", "")

        # Provide the agent with the retrieved claims as context
        prompt = (
            f"User Query: {query}\n\n"
            f"Claims to analyse ({len(retrieved_claims)} records):\n"
            + "\n".join(str(c) for c in retrieved_claims[:10])  # cap context
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        # Structured result placeholder — agents will populate this via tools
        fraud_analysis = {
            "claim_ids_analysed": [c.get("claim_id") for c in retrieved_claims],
            "analysis_summary": last_ai,
            "signals": [],           # populated by detect_fraud_patterns tool
            "total_signals": 0,
            "highest_severity": None,
        }

        logger.info("FraudAnalysisAgent completed analysis")
        return {"fraud_analysis": fraud_analysis}
