"""
Fraud Analysis Agent.

Examines retrieved claim records for known fraud signals and suspicious
behavioural patterns.
"""
from __future__ import annotations
import json
import logging
from typing import Any
from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent
from config.prompts import FRAUD_ANALYSIS_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.fraud_tools import (
    detect_fraud_patterns,
    check_duplicate_claims,
    analyse_claimant_history,
)

logger = logging.getLogger(__name__)
_SEVERITY_ORDER = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


class FraudAnalysisAgent(BaseAgent):
    agent_name = "fraud_analysis"
    system_prompt = FRAUD_ANALYSIS_SYSTEM_PROMPT
    tools = [detect_fraud_patterns, check_duplicate_claims, analyse_claimant_history]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        retrieved_claims = state.get("retrieved_claims", [])
        query = state.get("query", "")

        prompt = (
            "User Query: {}\n\nClaims to analyse ({} records):\n{}".format(
                query, len(retrieved_claims),
                "\n".join(str(c) for c in retrieved_claims[:10])
            )
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        # Parse signals from detect_fraud_patterns ToolMessage
        signals: list[dict] = []
        for msg in result.get("messages", []):
            tool_name = getattr(msg, "name", None)
            if tool_name == "detect_fraud_patterns":
                try:
                    parsed = json.loads(msg.content)
                    if isinstance(parsed, list):
                        signals.extend(parsed)
                    elif isinstance(parsed, dict) and "error" not in parsed:
                        signals.append(parsed)
                except (json.JSONDecodeError, TypeError):
                    logger.warning("Could not parse detect_fraud_patterns output")

        highest_severity = None
        if signals:
            highest_severity = max(
                (s.get("severity", "LOW") for s in signals),
                key=lambda s: _SEVERITY_ORDER.get(s, 0),
            )

        fraud_analysis = {
            "claim_ids_analysed": [
                c.get("PolicyNumber") or c.get("claim_id") or c.get("row_index")
                for c in retrieved_claims
            ],
            "analysis_summary": last_ai,
            "signals": signals,
            "total_signals": len(signals),
            "highest_severity": highest_severity,
        }

        logger.info(
            "FraudAnalysisAgent: %d signal(s), highest_severity=%s",
            len(signals), highest_severity,
        )
        return {"fraud_analysis": fraud_analysis}
