"""
Risk Scoring Agent.

Synthesises outputs from Fraud Analysis and Policy Validation to produce
an explainable fraud probability score and investigation priority.
"""
from __future__ import annotations
import json
import logging
from typing import Any
from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent
from config.prompts import RISK_SCORING_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.scoring_tools import compute_risk_score, generate_investigation_recommendations

logger = logging.getLogger(__name__)


def _default_actions(risk_tier: str) -> list[str]:
    base = {
        "LOW":      ["Proceed with standard claim processing."],
        "MEDIUM":   ["Request additional documentation.", "Assign experienced adjuster."],
        "HIGH":     ["Escalate to SIU.", "Place claim on hold.", "Notify compliance."],
        "CRITICAL": ["Immediately refer to SIU.", "Suspend payments.", "Initiate fraud investigation."],
    }
    return base.get(risk_tier.upper(), base["LOW"])


class RiskScoringAgent(BaseAgent):
    agent_name = "risk_scoring"
    system_prompt = RISK_SCORING_SYSTEM_PROMPT
    tools = [compute_risk_score, generate_investigation_recommendations]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        query = state.get("query", "")
        fraud_result = state.get("fraud_result") or {}
        policy_result = state.get("policy_result") or {}
        retrieved_claims = state.get("retrieved_claims", [])

        prompt = (
            "User Query: {}\n\n"
            "Fraud Analysis Summary:\n{}\n"
            "Total fraud signals: {}\n"
            "Highest severity: {}\n\n"
            "Policy Validation Summary:\n{}\n"
            "Overall verdict: {}\n\n"
            "Number of claims under review: {}"
        ).format(
            query,
            fraud_result.get("analysis_summary", "N/A"),
            fraud_result.get("total_signals", 0),
            fraud_result.get("highest_severity", "N/A"),
            policy_result.get("summary", "N/A"),
            policy_result.get("overall_verdict", "N/A"),
            len(retrieved_claims),
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        # Parse score from compute_risk_score ToolMessage
        parsed_score: dict | None = None
        for msg in result.get("messages", []):
            if getattr(msg, "name", None) == "compute_risk_score":
                try:
                    parsed = json.loads(msg.content)
                    if isinstance(parsed, dict) and "fraud_probability" in parsed:
                        parsed_score = parsed
                        break
                except (json.JSONDecodeError, TypeError):
                    logger.warning("Could not parse compute_risk_score output")

        # Parse recommendations from generate_investigation_recommendations ToolMessage
        recommended_actions: list[str] = []
        for msg in result.get("messages", []):
            if getattr(msg, "name", None) == "generate_investigation_recommendations":
                try:
                    parsed = json.loads(msg.content)
                    if isinstance(parsed, list):
                        recommended_actions = parsed
                        break
                except (json.JSONDecodeError, TypeError):
                    logger.warning("Could not parse generate_investigation_recommendations output")

        if parsed_score:
            risk_score = {
                **parsed_score,
                "score_rationale": parsed_score.get("score_rationale", last_ai),
                "recommended_actions": recommended_actions or parsed_score.get("recommended_actions", []),
            }
        else:
            # Fallback: derive score from signal count + policy verdict
            signal_count = fraud_result.get("total_signals", 0)
            highest_sev = fraud_result.get("highest_severity") or "LOW"
            policy_verdict = policy_result.get("overall_verdict", "NEEDS_REVIEW")
            sev_prob = {"LOW": 0.10, "MEDIUM": 0.30, "HIGH": 0.55, "CRITICAL": 0.85}
            pol_bonus = {"FAIL": 0.25, "NEEDS_REVIEW": 0.10, "PASS": 0.0}
            fraud_probability = min(round(
                sev_prob.get(highest_sev, 0.10)
                + pol_bonus.get(policy_verdict, 0.10)
                + min(signal_count * 0.05, 0.20), 4), 1.0)
            if fraud_probability >= 0.7:
                risk_tier = "CRITICAL" if signal_count >= 3 else "HIGH"
            elif fraud_probability >= 0.4:
                risk_tier = "MEDIUM"
            else:
                risk_tier = "LOW"
            claim_id = "BATCH"
            if retrieved_claims:
                claim_id = (
                    retrieved_claims[0].get("PolicyNumber")
                    or retrieved_claims[0].get("claim_id")
                    or "BATCH"
                )
            risk_score = {
                "claim_id": claim_id,
                "fraud_probability": fraud_probability,
                "risk_tier": risk_tier,
                "investigation_priority": max(1, round(fraud_probability * 10)),
                "score_rationale": (
                    "Derived from {} fraud signal(s) (highest: {}), "
                    "policy verdict: {}. {}".format(
                        signal_count, highest_sev, policy_verdict, last_ai)
                ),
                "recommended_actions": recommended_actions or _default_actions(risk_tier),
            }

        logger.info(
            "RiskScoringAgent: fraud_probability=%.4f, tier=%s",
            risk_score.get("fraud_probability", 0), risk_score.get("risk_tier", "N/A"),
        )
        return {"risk_score": risk_score}
