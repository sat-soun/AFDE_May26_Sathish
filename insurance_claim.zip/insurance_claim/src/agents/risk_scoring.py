"""
Risk Scoring Agent.

Synthesises outputs from Fraud Analysis and Policy Validation to produce
an explainable fraud probability score and investigation priority.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage
from langgraph.prebuilt import create_react_agent

from config.prompts import RISK_SCORING_SYSTEM_PROMPT
from src.agents.base import BaseAgent
from src.tools.scoring_tools import compute_risk_score, generate_investigation_recommendations

logger = logging.getLogger(__name__)


class RiskScoringAgent(BaseAgent):
    agent_name = "risk_scoring"
    system_prompt = RISK_SCORING_SYSTEM_PROMPT
    tools = [compute_risk_score, generate_investigation_recommendations]

    def __init__(self) -> None:
        super().__init__()
        self._react_agent = create_react_agent(
            model=self._llm,
            tools=self.tools,
            prompt=self.system_prompt,
        )

    def _execute(self, state: dict[str, Any]) -> dict[str, Any]:
        query = state.get("query", "")
        fraud_result = state.get("fraud_result") or {}
        policy_result = state.get("policy_result") or {}
        retrieved_claims = state.get("retrieved_claims", [])

        prompt = (
            f"User Query: {query}\n\n"
            f"Fraud Analysis Summary:\n{fraud_result.get('analysis_summary', 'N/A')}\n"
            f"Total fraud signals: {fraud_result.get('total_signals', 0)}\n"
            f"Highest severity: {fraud_result.get('highest_severity', 'N/A')}\n\n"
            f"Policy Validation Summary:\n{policy_result.get('summary', 'N/A')}\n"
            f"Overall verdict: {policy_result.get('overall_verdict', 'N/A')}\n\n"
            f"Number of claims under review: {len(retrieved_claims)}"
        )

        result = self._react_agent.invoke(
            {"messages": [HumanMessage(content=prompt)]}
        )

        last_ai = result["messages"][-1].content if result.get("messages") else ""

        # Default structured score (tools will override with real values)
        risk_score = {
            "claim_id": retrieved_claims[0].get("claim_id") if retrieved_claims else "BATCH",
            "fraud_probability": 0.0,
            "risk_tier": "LOW",
            "investigation_priority": 1,
            "score_rationale": last_ai,
            "recommended_actions": [],
        }

        logger.info("RiskScoringAgent completed scoring")
        return {"risk_score": risk_score}
