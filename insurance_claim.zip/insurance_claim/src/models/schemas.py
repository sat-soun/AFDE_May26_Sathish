"""
Pydantic domain models shared across agents, tools, and graph nodes.
"""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


# ── Enumerations ──────────────────────────────────────────────────────────────

class ClaimStatus(str, Enum):
    OPEN = "OPEN"
    UNDER_REVIEW = "UNDER_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    SETTLED = "SETTLED"
    FRAUD_FLAGGED = "FRAUD_FLAGGED"


class ClaimType(str, Enum):
    AUTO = "AUTO"
    HEALTH = "HEALTH"
    PROPERTY = "PROPERTY"
    LIABILITY = "LIABILITY"
    LIFE = "LIFE"
    TRAVEL = "TRAVEL"
    OTHER = "OTHER"


class RiskTier(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class FraudSignalSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class PolicyComplianceVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    NEEDS_REVIEW = "NEEDS_REVIEW"


# ── Core domain models ────────────────────────────────────────────────────────

class ClaimRecord(BaseModel):
    """Represents a single insurance claim record (source: CSV row)."""

    claim_id: str = Field(..., description="Unique claim identifier")
    policy_id: str = Field(..., description="Associated policy identifier")
    claimant_id: str = Field(..., description="Claimant/customer identifier")
    claim_type: ClaimType
    claim_date: date
    reported_date: Optional[date] = None
    settlement_date: Optional[date] = None
    claimed_amount: float = Field(..., ge=0)
    approved_amount: Optional[float] = Field(None, ge=0)
    status: ClaimStatus
    description: str = Field(..., description="Free-text claim narrative")
    provider_id: Optional[str] = None
    location: Optional[str] = None
    prior_claims_count: int = Field(0, ge=0)
    fraud_flag: Optional[bool] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class FraudSignal(BaseModel):
    """A single detected fraud indicator for a claim."""

    signal_type: str = Field(..., description="Short label, e.g. 'duplicate_claim'")
    severity: FraudSignalSeverity
    description: str
    evidence: str = Field(..., description="Supporting data or reasoning")
    confidence: float = Field(..., ge=0.0, le=1.0)


class FraudAnalysisResult(BaseModel):
    """Aggregated output from the Fraud Analysis agent."""

    claim_id: str
    signals: list[FraudSignal] = Field(default_factory=list)
    total_signals: int = 0
    highest_severity: Optional[FraudSignalSeverity] = None
    analysis_summary: str = ""

    def model_post_init(self, __context: Any) -> None:
        self.total_signals = len(self.signals)
        if self.signals:
            severity_order = [s.value for s in FraudSignalSeverity]
            self.highest_severity = max(
                self.signals,
                key=lambda s: severity_order.index(s.severity.value),
            ).severity


class PolicyCheckItem(BaseModel):
    """Result of a single policy compliance check."""

    check_name: str
    verdict: PolicyComplianceVerdict
    rationale: str
    requires_human_review: bool = False


class PolicyValidationResult(BaseModel):
    """Aggregated output from the Policy Validation agent."""

    claim_id: str
    policy_id: str
    checks: list[PolicyCheckItem] = Field(default_factory=list)
    overall_verdict: PolicyComplianceVerdict = PolicyComplianceVerdict.NEEDS_REVIEW
    summary: str = ""

    def model_post_init(self, __context: Any) -> None:
        verdicts = [c.verdict for c in self.checks]
        if PolicyComplianceVerdict.FAIL in verdicts:
            self.overall_verdict = PolicyComplianceVerdict.FAIL
        elif all(v == PolicyComplianceVerdict.PASS for v in verdicts):
            self.overall_verdict = PolicyComplianceVerdict.PASS
        else:
            self.overall_verdict = PolicyComplianceVerdict.NEEDS_REVIEW


class RiskScore(BaseModel):
    """Output from the Risk Scoring agent."""

    claim_id: str
    fraud_probability: float = Field(..., ge=0.0, le=1.0)
    risk_tier: RiskTier
    investigation_priority: int = Field(..., ge=1, le=10)
    score_rationale: str
    recommended_actions: list[str] = Field(default_factory=list)
    computed_at: datetime = Field(default_factory=datetime.utcnow)


class RetrievalResult(BaseModel):
    """A single semantically retrieved claim with relevance metadata."""

    claim: ClaimRecord
    similarity_score: float = Field(..., ge=0.0, le=1.0)
    chunk_id: str


class AgentResponse(BaseModel):
    """Standardised response envelope returned by every agent node."""

    agent_name: str
    success: bool = True
    data: dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    token_usage: Optional[dict[str, int]] = None
