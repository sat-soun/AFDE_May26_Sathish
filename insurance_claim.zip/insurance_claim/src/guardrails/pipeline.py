"""
Guardrail pipelines — orchestrate multiple guards into a single callable.

InputGuardrailPipeline
  Order: LengthValidator → InjectionDetector → PIIDetector → TopicClassifier
  Short-circuits on the first blocking violation.
  TopicClassifier (LLM) only runs if regex checks all pass.

OutputGuardrailPipeline
  Order: PIIScrubber → NumericSanityChecker → RelevanceChecker (LLM)
  Never blocks — redacts and warns only.
  RelevanceChecker only runs if a final answer is present.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from src.guardrails.models import GuardrailResult, PipelineGuardrailResult
from src.guardrails.regex_guards import (
    InjectionDetector,
    LengthValidator,
    NumericSanityChecker,
    PIIDetector,
    PIIScrubber,
)
from src.guardrails.llm_guards import RelevanceChecker, TopicClassifier

logger = logging.getLogger(__name__)


class InputGuardrailPipeline:
    """
    Runs all input guards in priority order.
    Returns immediately after the first BLOCK violation to avoid unnecessary
    LLM calls on clearly invalid input.
    """

    def __init__(self, enable_topic_classifier: bool = True) -> None:
        self._length    = LengthValidator(min_chars=5, max_chars=2_000)
        self._injection = InjectionDetector()
        self._pii       = PIIDetector()
        self._topic     = TopicClassifier(block_threshold=0.85) if enable_topic_classifier else None

    def run(self, query: str) -> PipelineGuardrailResult:
        accumulated = GuardrailResult(passed=True)

        # ── Fast regex guards (in order of cheapness) ──────────────────
        for guard_fn in (
            lambda: self._length.check(query),
            lambda: self._injection.check(query),
            lambda: self._pii.check(query),
        ):
            result = guard_fn()
            accumulated = accumulated.merge(result)
            if accumulated.blocked:
                logger.warning(
                    "Input guardrail BLOCKED | violations=%s",
                    [v.guardrail for v in accumulated.violations],
                )
                return PipelineGuardrailResult.from_result("input", accumulated)

        # ── LLM topic classifier (only if regex guards all passed) ──────
        if self._topic:
            try:
                topic_result = self._topic.check(query)
                accumulated = accumulated.merge(topic_result)
                if accumulated.blocked:
                    logger.warning("TopicClassifier BLOCKED query")
                    return PipelineGuardrailResult.from_result("input", accumulated)
            except Exception as exc:
                # Fail open: log but do not block
                logger.error("TopicClassifier raised unexpectedly: %s", exc)

        logger.debug("Input guardrails PASSED for query (length=%d)", len(query))
        return PipelineGuardrailResult.from_result("input", accumulated)


class OutputGuardrailPipeline:
    """
    Runs all output guards. Never blocks — only redacts and warns.
    """

    def __init__(self, enable_relevance_checker: bool = True) -> None:
        self._scrubber   = PIIScrubber()
        self._sanity     = NumericSanityChecker()
        self._relevance  = RelevanceChecker() if enable_relevance_checker else None

    def run(
        self,
        answer:        str,
        query:         str                      = "",
        fraud_result:  Optional[dict[str, Any]] = None,
        policy_result: Optional[dict[str, Any]] = None,
        risk_score:    Optional[dict[str, Any]] = None,
    ) -> PipelineGuardrailResult:
        accumulated = GuardrailResult(passed=True, sanitized_text=answer)

        # ── PII scrubbing ───────────────────────────────────────────────
        scrub_result = self._scrubber.scrub(answer)
        accumulated  = accumulated.merge(scrub_result)
        # Use scrubbed text for subsequent checks
        clean_answer = accumulated.sanitized_text or answer

        # ── Numeric sanity on structured outputs ────────────────────────
        sanity_result = self._sanity.check(
            fraud_result=fraud_result,
            policy_result=policy_result,
            risk_score=risk_score,
        )
        accumulated = accumulated.merge(sanity_result)

        # ── LLM relevance check ─────────────────────────────────────────
        if self._relevance and query and clean_answer:
            try:
                rel_result  = self._relevance.check(query=query, answer=clean_answer)
                accumulated = accumulated.merge(rel_result)
            except Exception as exc:
                logger.error("RelevanceChecker raised unexpectedly: %s", exc)

        if accumulated.violations:
            labels = [f"{v.guardrail}:{v.action}" for v in accumulated.violations]
            logger.info("Output guardrails: %s", labels)

        # Ensure sanitized_text always contains the (possibly scrubbed) answer
        accumulated.sanitized_text = clean_answer
        return PipelineGuardrailResult.from_result("output", accumulated)
