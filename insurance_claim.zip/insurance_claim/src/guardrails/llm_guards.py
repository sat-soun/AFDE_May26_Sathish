"""
LLM-based guardrails — used only when regex cannot express the required
semantic understanding.  Both guards use a small, fast model (gpt-4o-mini)
with a short timeout to minimise latency impact.

Guards implemented
──────────────────
Input:
  TopicClassifier   – checks that the query is about insurance claims

Output:
  RelevanceChecker  – checks that the answer addresses the user's query
"""
from __future__ import annotations

import json
import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from config.settings import get_settings
from src.guardrails.models import (
    GuardrailAction,
    GuardrailResult,
    GuardrailViolation,
    ViolationSeverity,
)

logger = logging.getLogger(__name__)

# Shared lightweight LLM (instantiated once per class)
_GUARD_MODEL = "gpt-4o-mini"
_GUARD_TEMPERATURE = 0.0
_GUARD_MAX_TOKENS = 200      # small — we only need a JSON snippet


def _make_llm() -> ChatOpenAI:
    settings = get_settings()
    return ChatOpenAI(
        model=_GUARD_MODEL,
        temperature=_GUARD_TEMPERATURE,
        max_tokens=_GUARD_MAX_TOKENS,
        openai_api_key=settings.openai_api_key,
        request_timeout=10,   # fail fast; guards should not stall the pipeline
    )


# ═══════════════════════════════════════════════════════════════════════════════
# TopicClassifier  (INPUT guardrail)
# ═══════════════════════════════════════════════════════════════════════════════

_TOPIC_SYSTEM = """
You are a topic-classification assistant for an Insurance Claims Intelligence platform.

Determine whether the user's query falls within the system's domain:
  - Insurance claims (auto, health, property, life, travel, liability)
  - Fraud detection, fraud patterns, fraud signals
  - Policy terms, coverage, eligibility, compliance
  - Risk assessment, risk scoring, investigation priority
  - Claimant history, provider analysis
  - Related operational questions (data ingestion, report generation, summaries)

Be PERMISSIVE — allow anything that could reasonably be asked by an insurance
analyst, adjuster, or fraud investigator.

Only classify as off-topic if the query is clearly unrelated (e.g., recipes,
sports scores, creative writing, personal advice unrelated to insurance).

Reply ONLY with a valid JSON object, no markdown fences:
{
  "relevant": true | false,
  "confidence": 0.0 to 1.0,
  "reason": "<one-sentence explanation>"
}
"""


class TopicClassifier:
    """
    Classifies whether the query is relevant to the insurance claims domain.
    Blocks queries that are confidently off-topic (confidence >= threshold).
    Falls open on LLM errors (allows the query through).
    """
    name = "topic_classifier"

    def __init__(self, block_threshold: float = 0.85) -> None:
        """
        Args:
            block_threshold: Minimum confidence of irrelevance required to block.
                             Higher = more permissive.  Default 0.85.
        """
        self.block_threshold = block_threshold
        self._llm = _make_llm()

    def check(self, query: str) -> GuardrailResult:
        try:
            response = self._llm.invoke([
                SystemMessage(content=_TOPIC_SYSTEM),
                HumanMessage(content=f"User query: {query}"),
            ])
            raw = response.content.strip()

            # Strip accidental markdown fences
            if raw.startswith("```"):
                raw = raw.split("```")[1].lstrip("json").strip()

            data: dict[str, Any] = json.loads(raw)
            relevant   = bool(data.get("relevant", True))
            confidence = float(data.get("confidence", 0.5))
            reason     = str(data.get("reason", ""))

        except Exception as exc:
            # Fail open — log and allow through
            logger.warning("TopicClassifier LLM call failed (%s); allowing query.", exc)
            return GuardrailResult(
                passed=True,
                metadata={"topic_classifier": "skipped (llm_error)"},
            )

        if not relevant and confidence >= self.block_threshold:
            return GuardrailResult(
                passed=False, blocked=True,
                violations=[GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.HIGH,
                    action=GuardrailAction.BLOCK,
                    message=(
                        "Query does not appear to be about insurance claims. "
                        "This system is designed for insurance claim analysis only."
                    ),
                    detail=f"confidence={confidence:.2f}, reason={reason}",
                )],
                metadata={"topic_classifier": reason},
            )

        return GuardrailResult(
            passed=True,
            metadata={
                "topic_classifier": reason,
                "topic_confidence": confidence,
                "topic_relevant": relevant,
            },
        )


# ═══════════════════════════════════════════════════════════════════════════════
# RelevanceChecker  (OUTPUT guardrail)
# ═══════════════════════════════════════════════════════════════════════════════

_RELEVANCE_SYSTEM = """
You are a quality-assurance assistant for an Insurance Claims Intelligence platform.

Your job: decide whether the provided AI response meaningfully addresses
the user's query about insurance claims.

A response is considered relevant if it:
  - Directly engages with the subject of the query
  - Provides data, analysis, or actionable conclusions related to the query
  - Acknowledges when data is unavailable rather than hallucinating

A response is NOT relevant if it:
  - Discusses a completely different topic
  - Is a generic boilerplate with no connection to the query
  - Explicitly refuses without reason

Reply ONLY with a valid JSON object, no markdown fences:
{
  "relevant": true | false,
  "complete": true | false,
  "concerns": "<comma-separated list of issues, or empty string>"
}
"""


class RelevanceChecker:
    """
    Checks that the generated answer actually addresses the user's query.
    Issues a WARN violation (never blocks) when the answer is irrelevant.
    Falls open on LLM errors.
    """
    name = "relevance_checker"

    def __init__(self) -> None:
        self._llm = _make_llm()

    def check(self, query: str, answer: str) -> GuardrailResult:
        if not answer or not answer.strip():
            return GuardrailResult(
                passed=False,
                violations=[GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.MEDIUM,
                    action=GuardrailAction.WARN,
                    message="Empty response generated — no answer to evaluate.",
                )],
            )

        prompt = (
            f"User query: {query}\n\n"
            f"AI response (first 800 chars): {answer[:800]}"
        )

        try:
            response = self._llm.invoke([
                SystemMessage(content=_RELEVANCE_SYSTEM),
                HumanMessage(content=prompt),
            ])
            raw = response.content.strip()

            if raw.startswith("```"):
                raw = raw.split("```")[1].lstrip("json").strip()

            data: dict[str, Any] = json.loads(raw)
            relevant  = bool(data.get("relevant", True))
            complete  = bool(data.get("complete", True))
            concerns  = str(data.get("concerns", ""))

        except Exception as exc:
            logger.warning("RelevanceChecker LLM call failed (%s); skipping.", exc)
            return GuardrailResult(
                passed=True,
                metadata={"relevance_checker": "skipped (llm_error)"},
            )

        violations: list[GuardrailViolation] = []

        if not relevant:
            violations.append(GuardrailViolation(
                guardrail=self.name,
                severity=ViolationSeverity.HIGH,
                action=GuardrailAction.WARN,
                message="Response does not appear to address the user's query.",
                detail=concerns or None,
            ))
        elif not complete:
            violations.append(GuardrailViolation(
                guardrail=self.name,
                severity=ViolationSeverity.LOW,
                action=GuardrailAction.WARN,
                message="Response may be incomplete.",
                detail=concerns or None,
            ))

        return GuardrailResult(
            passed=relevant,
            blocked=False,     # RelevanceChecker never blocks
            violations=violations,
            metadata={
                "relevance_checker": {
                    "relevant": relevant,
                    "complete": complete,
                    "concerns": concerns,
                }
            },
        )
