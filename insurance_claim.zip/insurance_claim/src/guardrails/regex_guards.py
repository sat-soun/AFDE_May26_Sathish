"""
Regex-based guardrails — fast, deterministic, zero LLM cost.

Guards implemented
──────────────────
Input:
  LengthValidator      – enforces min/max query length
  PIIDetector          – detects SSN, credit-card, email, phone, IP in queries
  InjectionDetector    – blocks prompt-injection and SQL-injection patterns

Output:
  PIIScrubber          – redacts PII found in generated answer text
  NumericSanityChecker – validates numeric fields in agent structured outputs
"""
from __future__ import annotations

import re
from typing import Any, Optional

from src.guardrails.models import (
    GuardrailAction,
    GuardrailResult,
    GuardrailViolation,
    ViolationSeverity,
)


# ═══════════════════════════════════════════════════════════════════════════════
# PII patterns
# ═══════════════════════════════════════════════════════════════════════════════

_PII: dict[str, re.Pattern] = {
    "ssn": re.compile(
        r"\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"
    ),
    "credit_card": re.compile(
        r"\b(?:"
        r"4[0-9]{12}(?:[0-9]{3,6})?"            # Visa
        r"|5[1-5][0-9]{14}"                       # Mastercard
        r"|3[47][0-9]{13}"                        # Amex
        r"|3(?:0[0-5]|[68][0-9])[0-9]{11}"       # Diners
        r"|6(?:011|5[0-9]{2})[0-9]{12}"          # Discover
        r")\b"
    ),
    "email": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,7}\b"
    ),
    "phone_us": re.compile(
        r"\b(?:\+?1[\s.\-]?)?(?:\([2-9][0-9]{2}\)|[2-9][0-9]{2})"
        r"[\s.\-]?[0-9]{3}[\s.\-]?[0-9]{4}\b"
    ),
    "ip_address": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}"
        r"(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b"
    ),
}

_PII_REDACT_LABELS = {
    "ssn":         "[REDACTED-SSN]",
    "credit_card": "[REDACTED-CC]",
    "email":       "[REDACTED-EMAIL]",
    "phone_us":    "[REDACTED-PHONE]",
    "ip_address":  "[REDACTED-IP]",
}

# ═══════════════════════════════════════════════════════════════════════════════
# Injection patterns
# ═══════════════════════════════════════════════════════════════════════════════

_PROMPT_INJECTION: list[re.Pattern] = [
    # "ignore previous/prior/above/your instructions"
    re.compile(
        r"(?i)\bignore\s+(?:all\s+)?(?:previous|prior|above|your)\s+"
        r"(?:instructions?|context|rules?|constraints?|guidelines?)\b"
    ),
    # "forget your instructions / training"
    re.compile(
        r"(?i)\bforget\s+(?:all|everything|your)\s+"
        r"(?:instructions?|context|rules?|training|guidelines?)\b"
    ),
    # "you are now X" / "pretend to be X" / "act as X" (non-insurance role)
    re.compile(
        r"(?i)\b(?:you\s+are\s+now|pretend\s+(?:to\s+be|you\s+are)|"
        r"act\s+as(?:\s+if\s+you\s+are)?)\s+(?:a|an)\s+(?!insurance|claim|adjuster|analyst)"
    ),
    # known jailbreak keywords
    re.compile(
        r"(?i)\b(?:jailbreak|DAN\s+mode|developer\s+mode|god\s+mode|"
        r"override\s+(?:safety|security|content)\s+(?:filters?|settings?|rules?))\b"
    ),
    # system prompt disclosure attempts
    re.compile(r"(?i)\b(?:repeat|print|show|reveal|output|tell\s+me)\s+(?:your\s+)?system\s+prompt\b"),
    # "disregard" variants
    re.compile(r"(?i)\bdisregard\s+(?:all\s+)?(?:previous|prior|above|your)\s+(?:instructions?|rules?)\b"),
]

_SQL_INJECTION: list[re.Pattern] = [
    re.compile(r"(?i)\b(?:DROP|DELETE|TRUNCATE|ALTER)\s+(?:TABLE|DATABASE|INDEX)\b"),
    re.compile(r"(?i)\bUNION\s+(?:ALL\s+)?SELECT\b"),
    re.compile(r"(?i);\s*(?:DROP|DELETE|UPDATE|INSERT|CREATE|ALTER)\b"),
    re.compile(r"(?i)\b(?:exec|execute|xp_cmdshell)\s*\("),
    re.compile(r"(?i)\b1\s*=\s*1\b.*(?:--|#)"),   # classic tautology + comment
]


# ═══════════════════════════════════════════════════════════════════════════════
# Valid value sets for NumericSanityChecker
# ═══════════════════════════════════════════════════════════════════════════════

_VALID_RISK_TIERS   = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
_VALID_VERDICTS     = {"PASS", "FAIL", "NEEDS_REVIEW"}
_VALID_SEVERITIES   = {"LOW", "MEDIUM", "HIGH"}


# ═══════════════════════════════════════════════════════════════════════════════
# Guards
# ═══════════════════════════════════════════════════════════════════════════════

class LengthValidator:
    """
    Blocks queries that are too short (noise) or too long (potential abuse).
    """
    name = "length_validator"

    def __init__(self, min_chars: int = 5, max_chars: int = 2_000) -> None:
        self.min_chars = min_chars
        self.max_chars = max_chars

    def check(self, text: str) -> GuardrailResult:
        length = len(text.strip())
        if length < self.min_chars:
            return GuardrailResult(
                passed=False, blocked=True,
                violations=[GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.MEDIUM,
                    action=GuardrailAction.BLOCK,
                    message=f"Query too short ({length} chars). Minimum is {self.min_chars}.",
                    detail=f"length={length}",
                )],
            )
        if length > self.max_chars:
            return GuardrailResult(
                passed=False, blocked=True,
                violations=[GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.MEDIUM,
                    action=GuardrailAction.BLOCK,
                    message=f"Query too long ({length} chars). Maximum is {self.max_chars}.",
                    detail=f"length={length}",
                )],
            )
        return GuardrailResult(passed=True)


class PIIDetector:
    """
    Detects PII patterns in the user query.
    Blocks the request to prevent PII from flowing into LLM calls.
    """
    name = "pii_detector"

    def check(self, text: str) -> GuardrailResult:
        violations: list[GuardrailViolation] = []

        for pii_type, pattern in _PII.items():
            matches = pattern.findall(text)
            if matches:
                # Mask the matched values in the detail string
                masked = [m[:3] + "***" if len(m) > 3 else "***" for m in matches[:3]]
                violations.append(GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.HIGH,
                    action=GuardrailAction.BLOCK,
                    message=f"Detected {pii_type.upper()} in query. Remove PII before querying.",
                    detail=f"type={pii_type}, sample_matches={masked}",
                ))

        if violations:
            return GuardrailResult(passed=False, blocked=True, violations=violations)
        return GuardrailResult(passed=True)


class InjectionDetector:
    """
    Blocks prompt-injection and SQL-injection patterns in the user query.
    """
    name = "injection_detector"

    def check(self, text: str) -> GuardrailResult:
        violations: list[GuardrailViolation] = []

        for pattern in _PROMPT_INJECTION:
            m = pattern.search(text)
            if m:
                violations.append(GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.CRITICAL,
                    action=GuardrailAction.BLOCK,
                    message="Prompt-injection pattern detected in query.",
                    detail=f"matched='{m.group(0)[:80]}'",
                ))
                break  # one match is enough to block

        for pattern in _SQL_INJECTION:
            m = pattern.search(text)
            if m:
                violations.append(GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.CRITICAL,
                    action=GuardrailAction.BLOCK,
                    message="SQL-injection pattern detected in query.",
                    detail=f"matched='{m.group(0)[:80]}'",
                ))
                break

        if violations:
            return GuardrailResult(passed=False, blocked=True, violations=violations)
        return GuardrailResult(passed=True)


class PIIScrubber:
    """
    Scans the LLM-generated answer text and redacts PII using regex.
    Always returns a GuardrailResult with ``sanitized_text`` set.
    """
    name = "pii_scrubber"

    def scrub(self, text: str) -> GuardrailResult:
        sanitized = text
        violations: list[GuardrailViolation] = []

        for pii_type, pattern in _PII.items():
            label = _PII_REDACT_LABELS[pii_type]
            replaced, n = pattern.subn(label, sanitized)
            if n:
                sanitized = replaced
                violations.append(GuardrailViolation(
                    guardrail=self.name,
                    severity=ViolationSeverity.HIGH,
                    action=GuardrailAction.REDACT,
                    message=f"Redacted {n} instance(s) of {pii_type.upper()} from response.",
                    detail=f"type={pii_type}, count={n}",
                ))

        return GuardrailResult(
            passed=True,           # scrubbing never blocks — it redacts
            blocked=False,
            violations=violations,
            sanitized_text=sanitized,
        )


class NumericSanityChecker:
    """
    Validates numeric and categorical fields in the structured agent outputs
    (fraud_result, policy_result, risk_score).  Issues WARN violations for
    out-of-range values without blocking the response.
    """
    name = "numeric_sanity_checker"

    def check(
        self,
        fraud_result:   Optional[dict[str, Any]] = None,
        policy_result:  Optional[dict[str, Any]] = None,
        risk_score:     Optional[dict[str, Any]] = None,
    ) -> GuardrailResult:
        violations: list[GuardrailViolation] = []

        # ── Fraud result ───────────────────────────────────────────────
        if fraud_result:
            total = fraud_result.get("total_signals")
            if total is not None and (not isinstance(total, int) or total < 0):
                violations.append(self._warn(
                    f"fraud_result.total_signals={total!r} is invalid (expected non-negative int)"
                ))

            highest = fraud_result.get("highest_severity")
            if highest and str(highest).upper() not in _VALID_SEVERITIES:
                violations.append(self._warn(
                    f"fraud_result.highest_severity={highest!r} not in {_VALID_SEVERITIES}"
                ))

        # ── Policy result ──────────────────────────────────────────────
        if policy_result:
            verdict = policy_result.get("overall_verdict")
            if verdict and str(verdict).upper() not in _VALID_VERDICTS:
                violations.append(self._warn(
                    f"policy_result.overall_verdict={verdict!r} not in {_VALID_VERDICTS}"
                ))

        # ── Risk score ─────────────────────────────────────────────────
        if risk_score:
            prob = risk_score.get("fraud_probability")
            if prob is not None:
                try:
                    prob_f = float(prob)
                    if not (0.0 <= prob_f <= 1.0):
                        violations.append(self._warn(
                            f"risk_score.fraud_probability={prob_f} outside [0, 1]"
                        ))
                except (TypeError, ValueError):
                    violations.append(self._warn(
                        f"risk_score.fraud_probability={prob!r} is not numeric"
                    ))

            tier = risk_score.get("risk_tier")
            if tier and str(tier).upper() not in _VALID_RISK_TIERS:
                violations.append(self._warn(
                    f"risk_score.risk_tier={tier!r} not in {_VALID_RISK_TIERS}"
                ))

            priority = risk_score.get("investigation_priority")
            if priority is not None:
                try:
                    p = int(priority)
                    if not (1 <= p <= 10):
                        violations.append(self._warn(
                            f"risk_score.investigation_priority={p} outside [1, 10]"
                        ))
                except (TypeError, ValueError):
                    violations.append(self._warn(
                        f"risk_score.investigation_priority={priority!r} is not an integer"
                    ))

        return GuardrailResult(
            passed=True,    # sanity warnings never block
            blocked=False,
            violations=violations,
        )

    def _warn(self, message: str) -> GuardrailViolation:
        return GuardrailViolation(
            guardrail=self.name,
            severity=ViolationSeverity.MEDIUM,
            action=GuardrailAction.WARN,
            message=message,
        )
