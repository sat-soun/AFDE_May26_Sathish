"""
Guardrails package — input & output safety layer.

Public API
──────────
  InputGuardrailPipeline   – run before passing query to agents
  OutputGuardrailPipeline  – run before returning answer to client
  PipelineGuardrailResult  – result type returned by both pipelines
  GuardrailViolation       – individual violation record
"""
from src.guardrails.models import (
    GuardrailAction,
    GuardrailResult,
    GuardrailViolation,
    PipelineGuardrailResult,
    ViolationSeverity,
)
from src.guardrails.pipeline import InputGuardrailPipeline, OutputGuardrailPipeline

__all__ = [
    "InputGuardrailPipeline",
    "OutputGuardrailPipeline",
    "PipelineGuardrailResult",
    "GuardrailViolation",
    "GuardrailResult",
    "GuardrailAction",
    "ViolationSeverity",
]
