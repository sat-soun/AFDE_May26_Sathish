"""
Shared data models for the guardrail layer.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ViolationSeverity(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


class GuardrailAction(str, Enum):
    BLOCK  = "block"   # Reject the request / response entirely
    REDACT = "redact"  # Allow through but mask sensitive content
    WARN   = "warn"    # Log and continue; include warning in response


class GuardrailViolation(BaseModel):
    guardrail: str                      # Name of the guard that fired
    severity:  ViolationSeverity
    action:    GuardrailAction
    message:   str                      # Human-readable description
    detail:    Optional[str] = None     # Matched pattern, evidence, etc.


class GuardrailResult(BaseModel):
    """
    Result returned by a single guardrail or a full pipeline run.

    ``passed``         – True if no blocking/critical violations were found.
    ``blocked``        – True if the request/response must be halted.
    ``violations``     – All violations found (including warn-only ones).
    ``sanitized_text`` – Text after redaction (set by PIIScrubber, etc.).
    ``metadata``       – Arbitrary extra context from the guardrail.
    """
    passed:         bool = True
    blocked:        bool = False
    violations:     list[GuardrailViolation] = Field(default_factory=list)
    sanitized_text: Optional[str] = None
    metadata:       dict[str, Any] = Field(default_factory=dict)

    def merge(self, other: "GuardrailResult") -> "GuardrailResult":
        """Combine two results (used when running multiple guards)."""
        return GuardrailResult(
            passed         = self.passed and other.passed,
            blocked        = self.blocked or other.blocked,
            violations     = self.violations + other.violations,
            sanitized_text = other.sanitized_text or self.sanitized_text,
            metadata       = {**self.metadata, **other.metadata},
        )


class PipelineGuardrailResult(BaseModel):
    """Summary of the full input or output guardrail pipeline run."""
    stage:      str                    # "input" | "output"
    passed:     bool
    blocked:    bool
    violations: list[GuardrailViolation] = Field(default_factory=list)
    sanitized_text: Optional[str] = None

    @classmethod
    def from_result(cls, stage: str, result: GuardrailResult) -> "PipelineGuardrailResult":
        return cls(
            stage          = stage,
            passed         = result.passed,
            blocked        = result.blocked,
            violations     = result.violations,
            sanitized_text = result.sanitized_text,
        )
