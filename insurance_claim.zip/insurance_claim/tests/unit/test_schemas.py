"""Unit tests for Pydantic domain models."""

import pytest
from datetime import date
from src.models.schemas import (
    ClaimRecord, ClaimType, ClaimStatus,
    FraudSignal, FraudSignalSeverity, FraudAnalysisResult,
    PolicyCheckItem, PolicyValidationResult, PolicyComplianceVerdict,
    RiskScore, RiskTier,
)


def make_claim(**overrides) -> ClaimRecord:
    defaults = dict(
        claim_id="CLM001",
        policy_id="POL001",
        claimant_id="CUS001",
        claim_type=ClaimType.AUTO,
        claim_date=date(2024, 1, 15),
        claimed_amount=5000.0,
        status=ClaimStatus.OPEN,
        description="Vehicle collision on highway.",
    )
    defaults.update(overrides)
    return ClaimRecord(**defaults)


def test_claim_record_valid():
    claim = make_claim()
    assert claim.claim_id == "CLM001"
    assert claim.claim_type == ClaimType.AUTO


def test_fraud_analysis_result_counts_signals():
    signals = [
        FraudSignal(
            signal_type="duplicate_claim",
            severity=FraudSignalSeverity.HIGH,
            description="Duplicate",
            evidence="Same date and amount",
            confidence=0.9,
        )
    ]
    result = FraudAnalysisResult(claim_id="CLM001", signals=signals)
    assert result.total_signals == 1
    assert result.highest_severity == FraudSignalSeverity.HIGH


def test_policy_validation_overall_verdict_fail():
    checks = [
        PolicyCheckItem(
            check_name="policy_active",
            verdict=PolicyComplianceVerdict.PASS,
            rationale="Policy active.",
        ),
        PolicyCheckItem(
            check_name="covered_peril",
            verdict=PolicyComplianceVerdict.FAIL,
            rationale="Peril not covered.",
        ),
    ]
    result = PolicyValidationResult(claim_id="CLM001", policy_id="POL001", checks=checks)
    assert result.overall_verdict == PolicyComplianceVerdict.FAIL


def test_policy_validation_overall_verdict_pass():
    checks = [
        PolicyCheckItem(
            check_name="policy_active",
            verdict=PolicyComplianceVerdict.PASS,
            rationale="OK.",
        ),
    ]
    result = PolicyValidationResult(claim_id="CLM001", policy_id="POL001", checks=checks)
    assert result.overall_verdict == PolicyComplianceVerdict.PASS
