# Running the Insurance Claims Intelligence System

## Prerequisites

- Python 3.11+
- Node.js 18+
- `.env` file with `OPENAI_API_KEY` (copy `.env.example` → `.env`)

---

## 1 — Backend (FastAPI)

```bash
# From the project root
pip install -r requirements.txt

# (First time only) Ingest the raw CSV data into the vector store
python main.py ingest --csv data/raw/fraud_oracle.csv
python main.py ingest --csv data/raw/train.csv

# Start the API server
uvicorn api.main:app --reload --port 8000
```

API is live at **http://localhost:8000**
- Swagger UI: http://localhost:8000/api/docs
- Health check: http://localhost:8000/api/health

### Key endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/chat/stream` | Full pipeline · SSE streaming |
| POST | `/api/chat` | Full pipeline · blocking |
| POST | `/api/agents/claims-retrieval` | Direct claims retrieval |
| POST | `/api/agents/fraud-analysis` | Direct fraud analysis |
| POST | `/api/agents/policy-validation` | Direct policy validation |
| POST | `/api/agents/risk-scoring` | Direct risk scoring |
| POST | `/api/ingest` | Upload & ingest a CSV |
| POST | `/api/ingest/default` | Ingest all CSVs in data/raw/ |

---

## 2 — Frontend (React)

```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173** in your browser.

The Vite dev server proxies `/api/*` to `http://localhost:8000` automatically — no CORS issues during development.

### Production build

```bash
cd frontend
npm run build        # outputs to frontend/dist/
```

Serve `frontend/dist/` from any static host, or mount it from FastAPI:

```python
# Add to api/main.py
from fastapi.staticfiles import StaticFiles
app.mount("/", StaticFiles(directory="frontend/dist", html=True), name="static")
```

---

## 3 — Quick test (curl)

```bash
# Non-streaming query
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "Show me high-value claims with fraud signals"}'

# Individual agent
curl -X POST http://localhost:8000/api/agents/claims-retrieval \
  -H "Content-Type: application/json" \
  -d '{"query": "auto claims above $50,000"}'

# Ingest default data
curl -X POST http://localhost:8000/api/ingest/default
```
